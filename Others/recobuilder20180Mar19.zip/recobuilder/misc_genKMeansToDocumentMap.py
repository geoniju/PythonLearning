
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

import string
import math
from string import punctuation
import sys
import os
from os.path import basename
import codecs
import pickle
import nltk
import requests
import chardet

import rbGlobals
import common
import commonFile
import CommonConfig
import commonLogger
import commonSimilarity
import commonTopics
import kmeansPredict

if __name__ == '__main__':
	documentToKMeansClusterMap = dict()
	
	filePath = os.path.join("corpus", "kmeans_model.pickle")
	model = commonFile.readPickle(filePath)
	
	filePath = os.path.join("corpus", "kmeans_vectorizer.pickle")
	vectorizer = commonFile.readPickle(filePath)
	
	for filename in os.listdir("input"):
		if filename.endswith(".txt"):
			print("Predicting cluster for '%s'" % filename)
	
			fileText = open(os.path.join("input", filename)).read()
			prediction = kmeansPredict.predict_kmeans_cluster(model, vectorizer, fileText)
			print(prediction)
			documentToKMeansClusterMap[os.path.splitext(filename)[0]] = prediction
	
	filePath = os.path.join("corpus", "document-to-kmeans-cluster-map.pickle")
	commonFile.writePickle(filePath, documentToKMeansClusterMap)
