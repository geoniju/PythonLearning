# based on topic_modelr.py from dsc4 directory

import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

import os, csv, re, glob, nltk
import argparse, textwrap
import numpy as np
import pandas as pd
import sklearn.feature_extraction.text as text
from sklearn import decomposition
from nltk import word_tokenize
from nltk.corpus import stopwords

import rbGlobals

custom_stopwords = ["http", "https", "rt", "url", "www", "cite", "immediate", "release", "remarks", "weekly", "address", "president", "obama", "white", "house", "office", "press", "secretary", "applause", "united", "states", "government", "new", "york", "end", "edt"]

def tokenize_nltk(text):
	"""
	Note: 	This function imports a list of custom stopwords from the user
			If the user does not modify custom stopwords (default=[]),
			there is no substantive update to the stopwords.
	"""
	tokens = word_tokenize(text)
	text = nltk.Text(tokens)
	#stop_words = set(stopwords.words('english'))
	stop_words = set(stopwords.words(rbGlobals.gLanguage))
	stop_words.update(custom_stopwords)
	words = [w.lower() for w in text if w.isalpha() and w.lower() not in stop_words]
	return words


def select_vectorizer(vectorizer_type, req_ngram_range=[1,2]):

	"""
	Select the desired vectorizer for either text or tweet
	@ text_tfidf_std
	@ text_tfidf_custom
	@ text_count_std

	@ tweet_tfidf_std
	@ tweet_tfidf_custom
	"""

	# SPECIFY VECTORIZER ALGORITHM
	#---------------------------------#

	ngram_lengths = req_ngram_range

	if vectorizer_type == "text_tfidf_std":
		# Standard TFIDF Vectorizer (Text)
		##vectorizer = text.TfidfVectorizer(input='filename', analyzer='word', ngram_range=(ngram_lengths), stop_words='english', min_df=2)
		vectorizer = text.TfidfVectorizer(analyzer='word', ngram_range=(ngram_lengths), stop_words=rbGlobals.gLanguage, min_df=2, encoding=rbGlobals.gEncoding)
		return vectorizer
	elif vectorizer_type == "text_tfidf_custom":
		# TFIDF Vectorizer with NLTK Tokenizer (Text)
		##vectorizer = text.TfidfVectorizer(input='filename', analyzer='word', ngram_range=(ngram_lengths), stop_words='english', min_df=2, tokenizer=tokenize_nltk)
		#decode_error='ignore' can be tried/used instead of encoding parameter
		vectorizer = text.TfidfVectorizer(input='content', analyzer='word', ngram_range=(ngram_lengths), stop_words=rbGlobals.gLanguage, min_df=2, tokenizer=tokenize_nltk, encoding=rbGlobals.gEncoding)
		#print("User specified custom stopwords: {} ...".format(str(custom_stopwords)[1:-1]))
		return vectorizer
	elif vectorizer_type == "text_count_std":
		##vectorizer = text.CountVectorizer(input='filename', analyzer='word', ngram_range=(ngram_lengths), stop_words='english', min_df=2)
		vectorizer = text.CountVectorizer(analyzer='word', ngram_range=(ngram_lengths), stop_words=rbGlobals.gLanguage, min_df=2, encoding=rbGlobals.gEncoding)
		return vectorizer
	elif vectorizer_type == "tweet_tfidf_std":
		# Standard TFIDF Vectorizer (Content)
		##vectorizer = text.TfidfVectorizer(input='content', analyzer='word', ngram_range=(ngram_lengths), stop_words='english', min_df=2)
		vectorizer = text.TfidfVectorizer(analyzer='word', ngram_range=(ngram_lengths), stop_words=rbGlobals.gLanguage, min_df=2, encoding=rbGlobals.gEncoding)
		return vectorizer
	elif vectorizer_type == "tweet_tfidf_custom":
		# Standard TFIDF Vectorizer (Content)
		##vectorizer = text.TfidfVectorizer(input='content', analyzer='word', ngram_range=(ngram_lengths), stop_words='english', min_df=2, tokenizer=tokenize_nltk)
		vectorizer = text.TfidfVectorizer(analyzer='word', ngram_range=(ngram_lengths), stop_words=rbGlobals.gLanguage, min_df=2, tokenizer=tokenize_nltk, encoding=rbGlobals.gEncoding)
		#print("User specified custom stopwords: {} ...".format(str(custom_stopwords)[1:-1]))
		return vectorizer
	else:
		#print("error in vectorizer specification...")
		pass


# ----------------------------------------------#
# MAIN TOPIC MODEL FUNCTION
# ----------------------------------------------#

def topicModeler(str, vectorizer_type, topic_clf, n_topics, n_top_terms, req_ngram_range=[1,2]):
	"""
    Topic Modeling Function: See Argparse Documentation for Details
	"""
	
	docString = [ str ]
	
	# Specify Number of Topics, Ngram Structure, and Terms per Topic
	num_topics = n_topics
	num_top_words = n_top_terms
	ngram_lengths = req_ngram_range

	# SPECIFY VECTORIZER ALGORITHM
	vectorizer = select_vectorizer(vectorizer_type, ngram_lengths)

	# Vectorizer Results
	dtm = vectorizer.fit_transform(docString).toarray()
	vocab = np.array(vectorizer.get_feature_names())
	print("Evaluating vocabulary...")
	print("Found {} terms in {} files...".format(dtm.shape[1], dtm.shape[0]))


	#---------------------------------
	# DEFINE and BUILD MODEL
	#---------------------------------

	if topic_clf == "lda":
		#Define Topic Model: LatentDirichletAllocation (LDA)
		clf = decomposition.LatentDirichletAllocation(n_topics=num_topics+1, random_state=3)
	elif topic_clf == "nmf":
		#Define Topic Model: Non-Negative Matrix Factorization (NMF)
		clf = decomposition.NMF(n_components=num_topics+1, random_state=3)
	elif topic_clf == "pca":
		#Define Topic Model: Principal Components Analysis (PCA)
		clf = decomposition.PCA(n_components=num_topics+1)
	else:
		pass


	#Fit Topic Model
	doctopic = clf.fit_transform(dtm)
	topic_words = []
	for topic in clf.components_:
	    word_idx = np.argsort(topic)[::-1][0:num_top_words]
	    topic_words.append([vocab[i] for i in word_idx])


	# Show the Top Topics
	if not os.path.exists("results"):
		os.makedirs("results")
	os.chdir("results")
	results_file = "clf_results_{}_model.csv".format(topic_clf)
	start_csv(results_file)
	#print("writing topic model results in {}...".format(file_path+"/results/"+results_file))
	for t in range(len(topic_words)):
		print("Topic {}: {}".format(t, ', '.join(topic_words[t][:])))
		#with open(results_file, 'a') as f:
			#writer = csv.writer(f)
			#writer.writerow(["Topic {}, {}".format(t, ', '.join(topic_words[t][:]))])




# ----------------------------------------------#
# EXAMPLES RUNNING THE FUNCTION WITHOUT ARGPARSE
# ----------------------------------------------#

#topic_modeler("text_tfidf_custom", "nmf", 15, 10, [2,4], "data/president")
#topic_modeler("text_tfidf_custom", "lda", 15, 10, [2,4], "data/president")
#topic_modeler("text_tfidf_custom", "pca", 15, 10, [2,4], "data/president")
#topic_modeler("tweet_tfidf_std", "lda", 15, 10, [1,4], "data/twitter")
