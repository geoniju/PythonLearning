
import sys
import os
import pickle

def showElement(nerMap, label):
	labelObject = nerMap[label]
	print("----- ", label)
	print(labelObject)
	
def showNERDetailsForDocument(filename):
	fpath = os.path.join("corpus","document_ner", filename, ".pickle")
	
	docName = os.path.splitext(fpath)[0]
	print("docName: ", docName)
	
	nerObject = data = pickle.load(open(fpath, "rb"))
	print(nerObject)
	
	"""
	print(nerObject)
	orgs = nerMap["ORGANIZATION"]
	print("----- organizations")
	print(orgs)
	
	print("----- person")
	persons = nerMap["PERSON"]
	print(persons)
	"""
	showElement(nerObject, "ORGANIZATION")
	showElement(nerObject, "PERSON")
	showElement(nerObject, "LOCATION")
	showElement(nerObject, "O")


def showNERForAllDocuments(input_dir):
	for file in os.listdir(input_dir):
		fpath = os.path.join(input_dir, file)
		if os.path.isdir(fpath):
			showNERDetailsForDocument(fpath)
		
if __name__ == "__main__":
	arguments = sys.argv[1:]
	count = len(arguments)
	print("count: ", count)
	
	if count == 0:
		print("insufficient arguments")
	if count == 1:
		if sys.argv[1] == "-all":
			print("all files")
		else:
			print("unknown argument")
	elif count == 2:
		if sys.argv[1] == "-file":
			showNERDetailsForDocument(sys.argv[2])
		else:
			print("unknown argument")
