"""
Data Science Challenge 4 - Search engine for sales team

Group Name:
	RecoBuilder

Authors:
	1. Bipin Patwardhan, bipin.patwardhan@capgemini.com
	2. Suvarna Fernandes, suvarna.fernandes@capgemini.com
	3. Geo Shanth, geo.shanth@capgemini.com
	4. Philippe Roudil, philippe.roudil@sogeti.com

File:
	create-corpus-standalone.py

Description:
	TO BE ADDED
"""

import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

import string
import math
from string import punctuation
import sys
import os
from os.path import basename
import codecs
import pickle
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
import csv
import chardet

import rbGlobals
import common
import commonFile
import CommonConfig
import commonLogger
from ngrams import *
import topicModelerFile
import kmeansPredict
import createCorpus
from stanfordNERCoreNLP import *

#
# main
#

if __name__ == '__main__':
	commonLogger.info("RecoBuilder - create-corpus-standalone ----- start")
	
	config = CommonConfig.CommonConfig()
	config.load("recobuilder.ini")
	
	language = config.getString("ProgramSettings", "Language", rbGlobals.DEFAULT_LANGUAGE)
	rbGlobals.gStopWords = stopwords.words(language) + list(punctuation)
	cfname = config.getString("ProgramSettings", "ContractionsFile", rbGlobals.DEFAULT_CONTRACTIONS_FILENAME)
	rbGlobals.gContractionMap = commonFile.loadContractions(os.path.join(rbGlobals.DIR_SUPPORT, cfname))
	afname = config.getString("ProgramSettings", "AcronymsFile", rbGlobals.DEFAULT_ACRONYMS_FILENAME)
	rbGlobals.gAcronymMap = commonFile.loadAcronyms(os.path.join(rbGlobals.DIR_SUPPORT, afname))
	mefname = config.getString("ProgramSettings", "MiscExpansionsFile", rbGlobals.DEFAULT_MISC_EXPANSIONS_FILENAME)
	rbGlobals.gMiscExpansionsMap = commonFile.loadMiscExpansions(os.path.join(rbGlobals.DIR_SUPPORT , mefname))
	iolfname = config.getString("ProgramSettings", "IncorrectOrgList", rbGlobals.DEFAULT_INCORRECT_ORGANIZATIONS_FILENAME)
	rbGlobals.gIncorrectOrgSet = commonFile.loadIncorrectOrganizationSet(os.path.join(rbGlobals.DIR_SUPPORT, iolfname))
	
	createCorpus.createCorpus(rbGlobals.DIR_INPUT, rbGlobals.gStopWords, rbGlobals.gContractionMap, rbGlobals.gAcronymMap, rbGlobals.gMiscExpansionsMap, rbGlobals.gIncorrectOrgSet)
	
	commonLogger.info("RecoBuilder - create-corpus-standalone ----- end")

#
# end of create-corpus-standalone.py
#
