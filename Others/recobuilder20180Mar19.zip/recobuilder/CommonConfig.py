"""
Data Science Challenge 4 - Search engine for sales team

Group Name:
	RecoBuilder

Authors:
	1. Bipin Patwardhan, bipin.patwardhan@capgemini.com
	2. Suvarna Fernandes, suvarna.fernandes@capgemini.com
	3. Geo Shanth, geo.shanth@capgemini.com
	4. Philippe Roudil, philippe.roudil@sogeti.com

File:
	commonConfig.py

Description:
	Common configuration functions
"""

from configparser import ConfigParser
from configparser import NoOptionError

class CommonConfig:
	def __init__(self):
		self.config = ConfigParser()
	
	def load(self, fname):
		self.config.read(fname)

	def getString(self, sectionName, keyName, defaultValue):
		try:
			value = self.config.get(sectionName, keyName)
		except NoOptionError:
			value = defaultValue
		return value

	def getInt(self, sectionName, keyName, defaultValue):
		try:
			value = self.config.getint(sectionName, keyName)
		except NoOptionError:
			value = defaultValue
		return value

	def getFloat(self, sectionName, keyName, defaultValue):
		try:
			value = self.config.getfloat(sectionName, keyName)
		except NoOptionError:
			value = defaultValue
		return value
		
	def getBoolean(self, sectionName, keyName, defaultValue):
		try:
			value = self.config.getboolean(sectionName, keyName)
		except NoOptionError:
			value = defaultValue
		return value

#
# end: CommonConfig.py
#
