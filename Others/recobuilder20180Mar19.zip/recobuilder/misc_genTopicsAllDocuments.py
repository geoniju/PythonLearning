
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

import string
import math
from string import punctuation
import sys
import os
from os.path import basename
import codecs
import pickle
import nltk
import requests
import chardet

import rbGlobals
import common
import commonFile
import CommonConfig
import commonLogger
import commonSimilarity
import commonTopics

# THIS IS A REPEAT FROM createCorpus file. NEEDS TO BE REFACTORED
def vectorizeWordsAndSaveToFile(words, filePath):
	commonLogger.detail("vectorizeWordsAndSaveToFile start")
	
	# create a tf-idf vector for the words in the document
	wordStr = common.makeStringFromList(words, " ")
	vector = commonSimilarity.vectorizeAndFitTransform(wordStr)
	# save the tf-idf vector to file
	commonLogger.debug("vectorizeWordsAndSaveToFile: vector file path: " + filePath)
	commonFile.writePickle(filePath, vector)
	
	commonLogger.detail("vectorizeWordsAndSaveToFile end")
#end vectorizeWordsAndSaveToFile

if __name__ == '__main__':
	topicSet = commonTopics.generateTopicsForAllDocumentsInDirectoryUsingLDA(rbGlobals.DIR_INPUT, "*.*", option="CHUNK", topics_to_find=10, words_to_find=20, passes_to_execute=20)
	print(topicSet)
	filePath = commonFile.getTopicsAllDocumentsFilePath()
	commonFile.writePickle(filePath, topicSet)
	topicWords = common.makeListFromSet(topicSet, " ")
	vfilePath = commonFile.getVectorizedTopicsAllDocumentsFilePath()
	vectorizeWordsAndSaveToFile(topicWords, vfilePath)
