# coding: utf-8

"""
Data Science Challenge 4 - Search engine for sales team

Group Name:
	RecoBuilder

Authors:
	1. Bipin Patwardhan, bipin.patwardhan@capgemini.com
	2. Suvarna Fernandes, suvarna.fernandes@capgemini.com
	3. Geo Shanth, geo.shanth@capgemini.com
	4. Philippe Roudil, philippe.roudil@sogeti.com

File:
	commonTopics.py

Description:
	Common functions for topic modeling using LDA.
"""

import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

import nltk
import heapq
import string
import gensim
import itertools
from operator import itemgetter
from nltk import *
from nltk.corpus.reader.plaintext import PlaintextCorpusReader
from scipy.spatial import distance
from gensim.models import TfidfModel
from gensim.models import LsiModel
from gensim.similarities import MatrixSimilarity
import pandas as pd
import sys
import os
import numpy as np

import commonLogger
import rbGlobals

#import tempfile
#TEMP_FOLDER = tempfile.gettempdir()
#print('>>>>> Folder "{}" will be used to save temporary dictionary and corpus.'.format(TEMP_FOLDER))

stemmer = SnowballStemmer(rbGlobals.gLanguage)

def tokenize_and_stem(text):
	# first tokenize by sentence, then by word to ensure that punctuation is caught as it's own token
	tokens = [word for sent in nltk.sent_tokenize(text) for word in nltk.word_tokenize(sent)]
	filtered_tokens = []
	# filter out any tokens not containing letters (e.g., numeric tokens, raw punctuation)
	for token in tokens:
		if re.search('[a-zA-Z]', token):
			filtered_tokens.append(token)
	stems = [stemmer.stem(t) for t in filtered_tokens]
	return stems


def tokenize_only(text):
	# first tokenize by sentence, then by word to ensure that punctuation is caught as it's own token
	tokens = [word.lower() for sent in nltk.sent_tokenize(text) for word in nltk.word_tokenize(sent)]
	filtered_tokens = []
	# filter out any tokens not containing letters (e.g., numeric tokens, raw punctuation)
	for token in tokens:
		if re.search('[a-zA-Z]', token):
			filtered_tokens.append(token)
	return filtered_tokens

def extract_candidate_chunks(text, grammar=r'KT: {(<JJ>* <NN.*>+ <IN>)? <JJ>* <NN.*>+}'):
	# exclude candidates that are stop words or entirely punctuation
	punct = set(string.punctuation)
	stop_words = set(nltk.corpus.stopwords.words('english'))
	# tokenize, POS-tag, and chunk using regular expressions
	chunker = nltk.chunk.regexp.RegexpParser(grammar)
	tagged_sents = nltk.pos_tag_sents(nltk.word_tokenize(sent) for sent in nltk.sent_tokenize(text))
	all_chunks = list(itertools.chain.from_iterable(nltk.chunk.tree2conlltags(chunker.parse(tagged_sent)) for tagged_sent in tagged_sents))
	# join constituent chunk words into a single chunked phrase
	candidates = [' '.join(word for word, pos, chunk in group).lower() for key, group in itertools.groupby(all_chunks, lambda word__pos__chunk: word__pos__chunk[2] != 'O') if key]
	return [cand for cand in candidates if cand not in stop_words and not all(char in punct for char in cand)]

def extract_candidate_words(text, good_tags=set(['JJ','JJR','JJS','NN','NNP','NNS','NNPS'])):
	# exclude candidates that are stop words or entirely punctuation
	punct = set(string.punctuation)
	stop_words = set(nltk.corpus.stopwords.words('english'))
	# tokenize and POS-tag words
	tagged_words = itertools.chain.from_iterable(nltk.pos_tag_sents(nltk.word_tokenize(sent) for sent in nltk.sent_tokenize(text)))
	# filter on certain POS tags and lowercase all words
	candidates = [word.lower() for word, tag in tagged_words if tag in good_tags and word.lower() not in stop_words and not all(char in punct for char in word)]
	return candidates


def generateTopicSetForDocumentUsingLDA(input_dir, fname, option="CHUNK", topics_to_find=1, words_to_find=20, passes_to_execute=20):
	commonLogger.detail("generateTopicsForDocument start")
	
	#list_texts = PlaintextCorpusReader(input_dir, fname, encoding="latin-1")
	list_texts = PlaintextCorpusReader(input_dir, fname, encoding=rbGlobals.gEncoding)

	fileids = list_texts.fileids()

	if option == "CHUNK":
		commonLogger.detail(">>>>> using chunk option")
		boc_texts = [
			extract_candidate_chunks(list_texts.raw(fileid)) for fileid in list_texts.fileids()
		]
	if option == "WORDS":
		commonLogger.detail(">>>>> using words option")
		boc_texts = [
			extract_candidate_words(list_texts.raw(fileid)) for fileid in list_texts.fileids()
		]
	
	commonLogger.detail(">>>>> making dictionary and corpus")
	# make gensim dictionary and corpus
	dict_sentence = gensim.corpora.Dictionary(boc_texts)
	corpus = [dict_sentence.doc2bow(boc_text) for boc_text in boc_texts]

	commonLogger.detail(">>>>> saving dictionary")
	#dict_sentence.save(os.path.join(corpus_dir_name, OPTION + '_dict_gram01.dict'))

	commonLogger.detail(">>>>> creating tfidf model")
	# transform corpus with tf-idf model
	tfidf = gensim.models.TfidfModel(corpus)
	corpus_tfidf = tfidf[corpus]

	# save tfidf model
	#tfidf.save(os.path.join(corpus_dir_name, OPTION + '_model.tfidf'))

	# load tdidf model
	#tfidf = TfidfModel.load(os.path.join(corpus_dir_name, OPTION + '_model.tfidf'))

	topicSet = set()
	try:
		#print(">>>>> lda model")
		ldaModel = gensim.models.ldamodel.LdaModel(corpus, num_topics=topics_to_find, id2word = dict_sentence, passes=passes_to_execute)
		#print (ldaModel)
		##print(">>>>>>>>>>>>>>> topics ")
		##topics = [ldaModel[c] for c in corpus]
		##print(topics)
		
		#print(">>>>> print lda topics")
		##print(ldaModel.print_topics(num_topics=10, num_words=10))
		#print(ldaModel.print_topics(num_topics=topics_to_find, num_words=words_to_find))
		commonLogger.detail(">>>>> print topic index and words in topic")
		
		for i in  ldaModel.show_topics(num_words=words_to_find):
			#commonLogger.debug(str(i[0]) + ":" + str(i[1]))
			weightsAndTopicsList = i[1].split("+")
			for wtl in weightsAndTopicsList:
				"""
				w, topic = wtl.split("*")
				#print(topic, topic.replace("\"", "").strip())
				topicSet.add(topic.replace("\"", "").strip())
				"""
				words = wtl.split("*")
				i = 1
				newWord = ""
				while i < len(words):
					newWord = newWord + " " + words[i]
					i = i + 1
				#commonLogger.debug("word to be added to topic set: " + newWord)
				topicSet.add(newWord)
				#print("topic set: ", topicSet)
		#print(topicSet)
	except ValueError:
		commonLogger.warning("Unable to generate topics for " + fname)
	
	return topicSet
#end generateTopicsForDocumentUsingLDA

def generateTopicsForAllDocumentsInDirectoryUsingLDA(input_dir, filetype=".*\.txt", option="CHUNK", topics_to_find=10, words_to_find=20, passes_to_execute=20):
	commonLogger.detail("generateTopicsForAllDocumentsInDirectoryUsingLDA start")
	
	#list_texts = PlaintextCorpusReader(input_dir + "\\", filetype, encoding=rbGlobals.gEncoding)
	#list_texts = PlaintextCorpusReader("input", ".*\.txt", encoding=rbGlobals.gEncoding)
	list_texts = PlaintextCorpusReader(input_dir, ".*\.txt", encoding=rbGlobals.gEncoding)
	
	#print(list_texts)

	fileids = list_texts.fileids()
	
	#print(fileids)

	if option == "CHUNK":
		commonLogger.detail(">>>>> using chunk option")
		boc_texts = [
			extract_candidate_chunks(list_texts.raw(fileid)) for fileid in list_texts.fileids()
		]
	if option == "WORDS":
		commonLogger.detail(">>>>> using words option")
		boc_texts = [
			extract_candidate_words(list_texts.raw(fileid)) for fileid in list_texts.fileids()
		]
	
	commonLogger.detail(">>>>> making dictionary and corpus")
	# make gensim dictionary and corpus
	dict_sentence = gensim.corpora.Dictionary(boc_texts)
	corpus = [dict_sentence.doc2bow(boc_text) for boc_text in boc_texts]

	commonLogger.detail(">>>>> saving dictionary")
	#dict_sentence.save(os.path.join(corpus_dir_name, OPTION + '_dict_gram01.dict'))

	commonLogger.detail(">>>>> creating tfidf model")
	# transform corpus with tf-idf model
	tfidf = gensim.models.TfidfModel(corpus)
	corpus_tfidf = tfidf[corpus]

	# save tfidf model
	#tfidf.save(os.path.join(corpus_dir_name, OPTION + '_model.tfidf'))

	# load tdidf model
	#tfidf = TfidfModel.load(os.path.join(corpus_dir_name, OPTION + '_model.tfidf'))

	#print(">>>>> lda model")
	ldaModel = gensim.models.ldamodel.LdaModel(corpus, num_topics=topics_to_find, id2word = dict_sentence, passes=passes_to_execute)
	#print (ldaModel)
	##print(">>>>>>>>>>>>>>> topics ")
	##topics = [ldaModel[c] for c in corpus]
	##print(topics)

	#print(">>>>> print lda topics")
	#print(ldaModel.print_topics(num_topics=10, num_words=10))
	#print(ldaModel.print_topics(num_topics=topics_to_find, num_words=words_to_find))
	commonLogger.detail(">>>>> print topic index and words in topic")
	topicSet = set()
	for i in  ldaModel.show_topics(num_words=words_to_find):
		#commonLogger.debug(str(i[0]) + ":" + str(i[1]))
		weightsAndTopicsList = i[1].split("+")
		for wtl in weightsAndTopicsList:
			"""
			w, topic = wtl.split("*")
			#print(topic, topic.replace("\"", "").strip())
			topicSet.add(topic.replace("\"", "").strip())
			"""
			words = wtl.split("*")
			i = 1
			newWord = ""
			while i < len(words):
				newWord = newWord + " " + words[i]
				i = i + 1
			#commonLogger.debug("word to be added to topic set: " + newWord)
			topicSet.add(newWord)
			#print("topic set: ", topicSet)
	#print(topicSet)
	
	return topicSet
#end generateTopicsForAllDocumentsInDirectoryUsingLDA

#
# end
#
