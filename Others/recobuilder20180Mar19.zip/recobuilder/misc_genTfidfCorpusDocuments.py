
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import pandas as pd
import sys
import os
import codecs
import pickle
import csv
import chardet
from string import punctuation
from nltk.stem.porter import PorterStemmer
from nltk.stem.lancaster import LancasterStemmer
from nltk.stem import SnowballStemmer

import CommonConfig
import rbGlobals
import common
import commonFile
import commonLogger
import commonSimilarity
import commonTopics
import commonNER
import ngrams
import topicModelerFile
import kmeansPredict
from stanfordNERCoreNLP import *

def vectorizeWordsAndSaveToFile(words, filePath):
	commonLogger.detail("vectorizeWordsAndSaveToFile start")
	
	# create a tf-idf vector for the words in the document
	wordStr = common.makeStringFromList(words, " ")
	vector = commonSimilarity.vectorizeAndFitTransform(wordStr)
	# save the tf-idf vector to file
	commonLogger.debug("vectorizeWordsAndSaveToFile: vector file path: " + filePath)
	commonFile.writePickle(filePath, vector)
	
	commonLogger.detail("vectorizeWordsAndSaveToFile end")
#end vectorizeWordsAndSaveToFile

def createDocumentListSet(filepath):
	list = commonFile.readFileIntoList(filepath)
	fileSet = set()
	for l in list:
		if l[:1] != "#":
			fileSet.add(l)
		else:
			common.detail("skipping file ", l)
	return fileSet
#end createDocumentListSet

def genTFIDFForCorpusDocument(input_dir, stopWords, contractionMap, acronymMap, miscExpansionsMap, incorrectOrgSet):
	commonLogger.detail("genTFIDFForCorpusDocument start")
	
	# read each file in the input directory and add it to the corpus
	for file in os.listdir(input_dir):
		bFileAdded = False
		
		file_path = os.path.join(input_dir, file)
		#commonLogger.detail("file: " + file + ", file_path " + file_path)
		if os.path.isdir(file_path):
			commonLogger.detail(file_path + " is a directory. skipping it")
			# skip directories
			continue
		
		try:
			commonLogger.info("Processing file '%s'" % file_path)
			#fh = codecs.open(os.path.join(input_path, file), "r", "utf-8")
			#fh = codecs.open(os.path.join(input_path, file), "r", "cp1252") # using this as utf-8 was giving some error - bipin, 11 jan 2017
			fh = codecs.open(file_path, "r")
			text = fh.read()
			text = text.strip()
			fh.close()
			
			if text is None or text == '':
				commonLogger.detail("Document " + file_path + " does not seem to contain data. Skipping the document")
				continue
			
			# perform basic text processing on each input
			words = common.basicTextProcessingCorpusDocument(text, stopWords, contractionMap, acronymMap, miscExpansionsMap, incorrectOrgSet)
			
			"""
			if rbGlobals.gBasicTfidf == True:
				fpath = commonFile.getWordFilePath(os.path.splitext(file)[0])
				if not os.path.isdir(fpath):
					commonLogger.debug("creating tfidf of words")
					# create a tf-idf vector for the words in the document
					vectorizeWordsAndSaveToFile(words, fpath)
					bFileAdded = True
				else:
					commonLogger.debug("word tdidf exists. skipping creation")
			"""
			
			# initialize the word stemmers
			words_StemPorter = common.stemWordsPorter(words)
			count_StemPorter = common.wordCount(words_StemPorter)
			tempFilePath = commonFile.getStemmerPorterWordFilePath(os.path.splitext(file)[0])
			vectorizeWordsAndSaveToFile(words_StemPorter, tempFilePath)
			
			words_StemLancaster = common.stemWordsLancaster(words)
			tempFilePath = commonFile.getStemmerLancasterWordFilePath(os.path.splitext(file)[0])
			vectorizeWordsAndSaveToFile(words_StemLancaster, tempFilePath)
			
			words_StemSnowball = common.stemWordsSnowball(words)
			tempFilePath = commonFile.getStemmerSnowballWordFilePath(os.path.splitext(file)[0])
			vectorizeWordsAndSaveToFile(words_StemSnowball, tempFilePath)
			
			"""
			if rbGlobals.gLemmatizationTfidf == True:
				fpath = commonFile.getLemmatizedWordFilePath(os.path.splitext(file)[0])
				if not os.path.isdir(fpath):
					# lemmatization of words
					commonLogger.debug("lemmatizing words and creating tfidf")
					lemmatizedWords = common.lemmatizeWords(words)
					# create a tf-idf vector for the lemmatized words in the document
					vectorizeWordsAndSaveToFile(lemmatizedWords, fpath)
					bFileAdded = True
				else:
					commonLogger.debug("lemmatized word tdidf exists. skipping creation")
			
			if rbGlobals.gNGramTfidf == True:
				fpath = commonFile.getNGramsFilePath(os.path.splitext(file)[0])
				if not os.path.isdir(fpath):
					commonLogger.debug("finding ngrams words and creating tfidf")
					# generate frequent ngrams and save them to file
					#ngrams.getMostFrequentNGgrams(file_path, num=10, min_length=2, max_length=4)
					frequent_ngrams = ngrams.getMostFrequentNGgrams(file_path)
					ngrams_text = ngrams.makeListFromNGrams(frequent_ngrams)
					# create a tf-idf vector for the ngrams in the document
					vectorizeWordsAndSaveToFile(ngrams_text, fpath)
					print("ngrams saved")
					bFileAdded = True
				else:
					commonLogger.debug("ngram word tdidf exists. skipping creation")
			
			print("ngams computed finding topics")
			if rbGlobals.gTopicCreation == True:
				fpath = commonFile.getTopicsFilePath(os.path.splitext(file)[0])
				if not os.path.isdir(fpath):
					# identify topics
					commonLogger.debug("Performing topic modeling")
					topicSet = commonTopics.generateTopicSetForDocumentUsingLDA(rbGlobals.DIR_INPUT, file)
					topicWords = common.makeListFromSet(topicSet, " ")
					vectorizeWordsAndSaveToFile(topicWords, fpath)
					bFileAdded = True
				else:
					commonLogger.debug("topic modeling tfidf exists. skipping creation")
			
			if rbGlobals.gNERIdentification == True:
				fpath = commonFile.getNERFilePath(os.path.splitext(file)[0])
				if not os.path.isdir(fpath):
					commonLogger.debug("Performing NER")
					# perform NER
					nerMap = commonNER.performNEROnDocument(file_path)
					commonFile.saveNERMapForFile(fpath, nerMap)
					commonNER.fetchAndSaveOrganizationWebPage(nerMap, incorrectOrgSet)
					bFileAdded = True
				else:
					commonLogger.debug("ner exists. skipping creation")
			"""
		except FileNotFoundError:
			commonLogger.error("Error processing file " + file_path)
	# end for
#end genTFIDFForCorpusDocument

if __name__ == '__main__':
	commonLogger.info(" ----- start")

	# read data from the configuration file
	config = CommonConfig.CommonConfig()
	config.load("recobuilder.ini")
	
	rbGlobals.gLanguage = config.getString("ProgramSettings", "Language", rbGlobals.DEFAULT_LANGUAGE)
	#commonLogger.detail("contraction map path: " + rbGlobals.gLanguage)
	
	cfname = config.getString("ProgramSettings", "ContractionsFile", rbGlobals.DEFAULT_CONTRACTIONS_FILENAME)
	rbGlobals.gContractionMap = commonFile.loadContractions(cfname)
	#commonLogger.detail("contraction map path: " + rbGlobals.gContractionMap)
	
	afname = config.getString("ProgramSettings", "AcronymsFile", rbGlobals.DEFAULT_ACRONYMS_FILENAME)
	rbGlobals.gAcronymMap = commonFile.loadAcronyms(afname)
	#commonLogger.detail("acronym map path: " + rbGlobals.gAcronymMap)
	
	mefname = config.getString("ProgramSettings", "MiscExpansionsFile", rbGlobals.DEFAULT_MISC_EXPANSIONS_FILENAME)
	rbGlobals.gMiscExpansionsMap = commonFile.loadMiscExpansions(mefname)
	#commonLogger.detail("misc expansions map path: " + rbGlobals.gMiscExpansionsMap)
	
	iolfname = config.getString("ProgramSettings", "IncorrectOrganizationsFile", rbGlobals.DEFAULT_INCORRECT_ORGANIZATIONS_FILENAME)
	rbGlobals.gIncorrectOrgSet = commonFile.loadIncorrectOrganizationSet(iolfname)
	#commonLogger.detail("incorrect org set path: " + rbGlobals.gIncorrectOrgSet)
	
	rbGlobals.gCreationMode = config.getString("CorpusCreation", "CreationMode", rbGlobals.CREATION_MODE_UPDATE)
	#commonLogger.detail("creation mode: ", rbGlobals.gCreationMode)
	
	rbGlobals.gTopicCreation = config.getBoolean("CorpusCreation", "TopicCreation", rbGlobals.DEFAULT_TOPIC_CREATION)
	#commonLogger.detail("topic creation: " + rbGlobals.gTopicCreation)
	
	rbGlobals.gNERIdentification = config.getBoolean("CorpusCreation", "NERIdentification", rbGlobals.DEFAULT_NER_IDENTIFICATION)
	#commonLogger.detail("ner identification: " + rbGlobals.gNERIdentification)
	
	rbGlobals.gNEROrgDownload = config.getBoolean("CorpusCreation", "NEROrgDownload", rbGlobals.DEFAULT_NER_ORG_DOWNLOAD)
	#commonLogger.detail("ner org download: " + rbGlobals.gNEROrgDownload)
	
	rbGlobals.gNERIncorrectOrgIdentification = config.getBoolean("CorpusCreation", "NERIncorrectOrgIdentification", rbGlobals.DEFAULT_NER_INCORRECT_ORG_IDENTIFICATION)
	#commonLogger.detail("ner incorrect org identification: " + rbGlobals.gNERIncorrectOrgIdentification)
	
	rbGlobals.gNERSkipOrgCheck = config.getBoolean("CorpusCreation", "NERSkipIncorrectOrgCheck", rbGlobals.DEFAULT_NER_SKIP_INCORRECT_ORG_CHECK)
	#commonLogger.detail("ner ner skip org check: " + rbGlobals.gNERSkipOrgCheck)
	
	rbGlobals.gKMeansClustering = config.getBoolean("CorpusCreation", "KMeansClustering", rbGlobals.DEFAULT_KMEANS_CLUSTERING)
	#commonLogger.detail("ner kmeans clustering: " + rbGlobals.gKMeansClustering)
	
	rbGlobals.gNGramTfidf = config.getBoolean("CorpusCreation", "NGramTfidf", rbGlobals.DEFAULT_NGRAM_TFIDF)
	#commonLogger.detail("ngram tfidf: " + rbGlobals.gNGramTfidf)
	
	rbGlobals.gLemmatizationTfidf = config.getBoolean("CorpusCreation", "LemmatizationTfidf", rbGlobals.DEFAULT_LEMMATIZATION_TFIDF)
	#commonLogger.detail("lemmatization tfidf: " + rbGlobals.gLemmatizationTfidf)
	
	rbGlobals.gBasicTfidf = config.getBoolean("CorpusCreation", "BasicTfidf", rbGlobals.DEFAULT_BASIC_TFIDF)
	#commonLogger.detail("basic tfidf: " + rbGlobals.gWordLemmatization)
	
	rbGlobals.gNumTopics = config.getInt("TopicCreation", "NumTopics", rbGlobals.DEFAULT_NUM_TOPICS)
	#commonLogger.detail("topic creation num topics: " + rbGlobals.gNumTopics)
	
	rbGlobals.gNumPasses = config.getInt("TopicCreation", "NumPasses", rbGlobals.DEFAULT_NUM_PASSES)
	#commonLogger.detail("topic creation num passes: " + rbGlobals.gNumPasses)
	
	rbGlobals.gNumWords = config.getInt("TopicCreation", "NumWords", rbGlobals.DEFAULT_NUM_WORDS)
	#commonLogger.detail("topic creation  num words: " + rbGlobals.gNumWords)
	
	rbGlobals.gKMeansNumClusters = config.getInt("KMeansClustering", "NumClusters", rbGlobals.DEFAULT_KMEANS_NUM_CLUSTERS)
	#commonLogger.detail("kmeans num clusters: " + rbGlobals.gNumKMeansNumClusters)
	
	rbGlobals.gKMeansNumIterations = config.getInt("KMeansClustering", "NumIterations", rbGlobals.DEFAULT_KMEANS_NUM_ITERATIONS)
	#commonLogger.detail("kmeans num iterations: " + rbGlobals.gNumKMeansNumIterations)
	
	rbGlobals.gDocumentListAddToCorpus = config.getString("CorpusCreation", "DocumentListAddToCorpus", rbGlobals.DEFAULT_PATH_DOCUMENT_LIST_TO_ADD_TO_CORPUS)
	#commonLogger.detail("document file to add to corpus: " + rbGlobals.gDocumentListAddToCorpus)
	
	# initialize stop words
	rbGlobals.gStopWords = stopwords.words(rbGlobals.gLanguage) + list(punctuation)
	
	rbGlobals.gDocumentsInCorpusFilePath = commonFile.readPickle(commonFile.getDocumentsInCorpusFilePath())
	rbGlobals.gDocumentsInCorpusBasename = commonFile.readPickle(commonFile.getDocumentsInCorpusBasenameFilePath())
	
	genTFIDFForCorpusDocument(rbGlobals.DIR_INPUT, rbGlobals.gStopWords, rbGlobals.gContractionMap, rbGlobals.gAcronymMap, rbGlobals.gMiscExpansionsMap, rbGlobals.gIncorrectOrgSet)
