import textClassify

dc = textClassify.loadDClasses("input")
textClassify.search(dc, "data mining")
#sim = textClassify.searchDocument("A Large Telecom Company_201103_BIM.txt", "data mining")
#print(sim)
