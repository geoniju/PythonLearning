"""
Data Science Challenge 4 - Search engine for sales team

Group Name:
	RecoBuilder

Authors:
	1. Bipin Patwardhan, bipin.patwardhan@capgemini.com
	2. Suvarna Fernandes, suvarna.fernandes@capgemini.com
	3. Geo Shanth, geo.shanth@capgemini.com
	4. Philippe Roudil, philippe.roudil@service.capgemini.com
	
File:
	commonSimilarity.py

Description:
	Common functions related to similarity
"""

import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

import operator
import os
from collections import OrderedDict
import math
import string
from string import punctuation
import unicodedata
from bs4 import BeautifulSoup
import requests
import pickle
import sys
import csv
import chardet
import codecs
import re, collections
from autocorrect import spell
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk.collocations import BigramCollocationFinder
from nltk.metrics import BigramAssocMeasures
from nltk.stem.porter import PorterStemmer
from nltk.stem import LancasterStemmer
from nltk.stem import SnowballStemmer
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer
import gensim.matutils

import rbGlobals
import common
import commonLogger
import commonFile
import stanfordNERCoreNLP
from kmeansPredict import *

"""
def computeCosineSimilarity(vector1, vector2):
	dot_product = sum(p*q for p,q in zip(vector1, vector2))
	magnitude = math.sqrt(sum([val**2 for val in vector1])) * math.sqrt(sum([val**2 for val in vector2]))
	if not magnitude:
		return 0
	return dot_product/magnitude
#end computeCosineSimilarity
"""

def computeCosineSimilarity(vector1, vector2):
	#sim = gensim.matutils.cossim(vector1, vector2)
	sim = gensim.matutils.cossim(dict(enumerate(vector1)), dict(enumerate(vector2)))
	return sim
#end computeCosineSimilarity

def vectorizeAndFitTransform(str):
	sklearn_representation = None
	try:
		doclist = [ str ]
		sklearn_tfidf = TfidfVectorizer(norm='l2',min_df=0, use_idf=True, smooth_idf=False, sublinear_tf=True, tokenizer=common.tokenize)
		sklearn_representation = sklearn_tfidf.fit_transform(doclist)
	except ValueError:
		sklearn_representation = None
	return sklearn_representation
#end vectorizeAndFitTransform

def findSimilarityTwoStrings(string1, string2):
	commonLogger.detail("findSimilarityTwoStrings start")
	
	sim = 0.0
	# perform tf=idf on string 1

	doclist1 = [ string1 ]
	sklearn_tfidf = TfidfVectorizer(norm='l2',min_df=0, use_idf=True, smooth_idf=False, sublinear_tf=True, tokenizer=common.tokenize)
	sklearn_representation_doc1 = sklearn_tfidf.fit_transform(doclist1)

	#sklearn_representation_doc1 = vectorizeAndFitTransform(string1)
	
	# perform tf=idf on string 2

	doclist2 = [ string2 ]
	sklearn_tfidf_str = TfidfVectorizer(norm='l2',min_df=0, use_idf=True, smooth_idf=False, sublinear_tf=True, tokenizer=common.tokenize)
	sklearn_representation_doc2 = sklearn_tfidf_str.fit_transform(doclist2)

	#sklearn_representation_doc2 = vectorizeAndFitTransform(string2)
	
	for scount, d1 in enumerate(sklearn_representation_doc1.toarray()):
		for count, d2 in enumerate(sklearn_representation_doc2.toarray()):
			try:
				sim = computeCosineSimilarity(d1, d2)
				#commonLogger.debug("Similarity of '" + string1 + "' and '" + string2 + "' is '" + str(sim) + "'")
				#print("Similarity of '" + string1 + "' and '" + string2 + "' is '" + str(sim) + "'")
			except TypeError:
				sim = 0.0
			
	commonLogger.detail("findSimilarityTwoStrings end")
	return sim
#end findSimilarityTwoStrings

def findSimilarityDocumentAndString(docName, docString, searchString):
	commonLogger.detail("findSimilarityDocumentAndString start")
	
	sim = 0.0
	# perform tf-idf on document
	sklearn_representation_doc = vectorizeAndFitTransform(docString)
	
	# perform tf-idf on search string
	sklearn_representation_str = vectorizeAndFitTransform(searchString)
	
	for scount, s1 in enumerate(sklearn_representation_str.toarray()):
		for count, d2 in enumerate(sklearn_representation_doc.toarray()):
			try:
				sim = computeCosineSimilarity(s1, d2)
				#commonLogger.debug("Similarity with '" + docName + "' is '" + str(sim) + "'")
			except TypeError:
				sim = 0.0
			
	commonLogger.detail("findSimilarityDocumentAndString end")
	return sim
#end findSimilarityDocumentAndString

def findSimilarityTwoDocumentVectors(doc1Name, doc1Vector, doc2Name, doc2Vector):
	commonLogger.detail("findSimilarityTwoDocumentVectors start")
	
	sim = 0.0
	for scount, d1 in enumerate(doc1Vector.toarray()):
		for count, d2 in enumerate(doc2Vector.toarray()):
			try:
				sim = computeCosineSimilarity(d1, d2)
				#commonLogger.debug("Similarity between '" + doc1Name + "' and '" + doc2Name + "' is '" + str(sim) + "'")
			except TypeError:
				sim = 0.0
	
	commonLogger.detail("findSimilarityTwoDocumentVectors end")
	return sim
#end findSimilarityTwoDocumentVectors

def findSimilarityDocumentVectorAndString(docName, docVector, searchString):
	commonLogger.detail("findSimilarityDocumentVectorAndString start")
	
	searchVector = vectorizeAndFitTransform(searchString)
	
	sim = 0.0
	for scount, s1 in enumerate(searchVector.toarray()):
		for count, d2 in enumerate(docVector.toarray()):
			try:
				sim = computeCosineSimilarity(s1, d2)
				#commonLogger.debug("Similarity with '" + docName + "' is '" + str(sim) + "'")
			except TypeError:
				sim = 0.0
	
	commonLogger.detail("findSimilarityDocumentVectorAndString end")
	return sim
#end findSimilarityDocumentVectorAndString

# perform similarity search between documents in the corpus
def performSimilarityWithinCorpusDocumentsPrev(df):
	commonLogger.detail("performCorpusDocumentSimilarityPrev start")
	
	docComparedSet = set()
	gb = new_df.groupby(['File'])
	for ok, outer in gb:
		ovector = commonFile.readPickle(os.path.join(rbGlobals.DIR_TFIDF_WORDS, str(ok) + "." + rbGlobals.EXT_TFIDF_WORDS))
		for ik, inner in gb:
			commonLogger.debug(ok + "," + ik)
			if ok != ik:
				tempStr = ok + "_" + ik
				tempStr2 = ik + "_" + ok
				if tempStr not in docComparedSet:
					docComparedSet.add(tempStr)
					docComparedSet.add(tempStr2)
					commonLogger.detail("need to compare " + ok + " and " + ik)
					ivector = pickle.load(open(os.path.join(rbGlobals.DIR_TFIDF_WORDS, str(ik) + "." + rbGlobals.EXT_TFIDF_WORDS, "rb")))
					findSimilarityTwoDocumentVectors(str(ok), ovector, str(ik), ivector)
				else:
					commonLogger.detail(ok + " and " + ik + " have already been compared for similarity")
			else:
				commonLogger.detail("skipping due to same key name")
	
	commonLogger.detail("performCorpusDocumentSimilarityPrev end")
#end performCorpusDocumentSimilarityPrev

def performWordSimilarityWithinCorpusDocuments():
	commonLogger.detail("performWordSimilarityWithinCorpusDocuments start")
	
	rbGlobals.gDocumentsInCorpusBasename = commonFile.readPickle(os.path.join(rbGlobals.DIR_CORPUS, rbGlobals.DOCUMENTS_IN_CORPUS_BASENAME + "." + rbGlobals.EXT_PICKLE))
	
	if len(rbGlobals.gDocDocWordSimilarityMap) == 0:
		rbGlobals.gDocDocWordSimilarityMap = dict()
	
	for ok in rbGlobals.gDocumentsInCorpusBasename:
		ovector = commonFile.readPickle(os.path.join(rbGlobals.DIR_TFIDF_WORDS, str(ok) + "." + rbGlobals.EXT_PICKLE))
		for ik in rbGlobals.gDocumentsInCorpusBasename:
			if ok != ik:
				if ok not in rbGlobals.gDocDocWordSimilarityMap.keys():
					rbGlobals.gDocDocWordSimilarityMap[ok] = dict()
				
				if ik not in rbGlobals.gDocDocWordSimilarityMap.keys():
					rbGlobals.gDocDocWordSimilarityMap[ik] = dict()

				if ik not in rbGlobals.gDocDocWordSimilarityMap[ok].keys():
					ivector = pickle.load(open(os.path.join(rbGlobals.DIR_TFIDF_WORDS, str(ik) + "." + rbGlobals.EXT_PICKLE), "rb"))
					sim = findSimilarityTwoDocumentVectors(str(ok), ovector, str(ik), ivector)
					rbGlobals.gDocDocWordSimilarityMap[ok][ik] = sim
					rbGlobals.gDocDocWordSimilarityMap[ik][ok] = sim
				else:
					commonLogger.detail(ok + " and " + ik + " have already been compared for similarity")
			else:
				commonLogger.detail("skipping due to same key name")
	
	commonFile.writePickle(commonFile.getDocDocWordSimilarityFilePath(), rbGlobals.gDocDocWordSimilarityMap)

	commonLogger.detail("performWordSimilarityWithinCorpusDocuments end")
	return rbGlobals.gDocDocWordSimilarityMap
#end performWordSimilarityWithinCorpusDocuments

def performPorterStemmedWordSimilarityWithinCorpusDocuments():
	#commonLogger.detail("performPorterStemmedWordSimilarityWithinCorpusDocuments start")
	print("performPorterStemmedWordSimilarityWithinCorpusDocuments start")
	
	rbGlobals.gDocumentsInCorpusBasename = commonFile.readPickle(os.path.join(rbGlobals.DIR_CORPUS, rbGlobals.DOCUMENTS_IN_CORPUS_BASENAME + "." + rbGlobals.EXT_PICKLE))
	
	if len(rbGlobals.gDocDocPorterStemmedWordSimilarityMap) == 0:
		rbGlobals.gDocDocPorterStemmedWordSimilarityMap = dict()
	
	for ok in rbGlobals.gDocumentsInCorpusBasename:
		ovector = commonFile.readPickle(os.path.join(rbGlobals.DIR_TFIDF_STEM_PORTER, str(ok) + "." + rbGlobals.EXT_PICKLE))
		for ik in rbGlobals.gDocumentsInCorpusBasename:
			if ok != ik:
				if ok not in rbGlobals.gDocDocPorterStemmedWordSimilarityMap.keys():
					rbGlobals.gDocDocPorterStemmedWordSimilarityMap[ok] = dict()
				
				if ik not in rbGlobals.gDocDocPorterStemmedWordSimilarityMap.keys():
					rbGlobals.gDocDocPorterStemmedWordSimilarityMap[ik] = dict()

				if ik not in rbGlobals.gDocDocPorterStemmedWordSimilarityMap[ok].keys():
					ivector = pickle.load(open(os.path.join(rbGlobals.DIR_TFIDF_STEM_PORTER, str(ik) + "." + rbGlobals.EXT_PICKLE), "rb"))
					sim = findSimilarityTwoDocumentVectors(str(ok), ovector, str(ik), ivector)
					rbGlobals.gDocDocPorterStemmedWordSimilarityMap[ok][ik] = sim
					rbGlobals.gDocDocPorterStemmedWordSimilarityMap[ik][ok] = sim
					print("adding similarity for ", ok, " and ", ik)
				else:
					commonLogger.detail(ok + " and " + ik + " have already been compared for similarity")
			else:
				commonLogger.detail("skipping due to same key name")
	
	commonFile.writePickle(commonFile.getDocDocPorterStemmedWordSimilarityFilePath(), rbGlobals.gDocDocPorterStemmedWordSimilarityMap)

	commonLogger.detail("performPorterStemmedWordSimilarityWithinCorpusDocuments end")
	return rbGlobals.gDocDocWordSimilarityMap
#end performPorterStemmedWordSimilarityWithinCorpusDocuments

def performLemmatizedWordSimilarityWithinCorpusDocuments():
	commonLogger.detail("performLemmatizedWordSimilarityWithinCorpusDocuments start")
	
	rbGlobals.gDocumentsInCorpusBasename = commonFile.readPickle(os.path.join(rbGlobals.DIR_CORPUS, rbGlobals.DOCUMENTS_IN_CORPUS_BASENAME + "." + rbGlobals.EXT_PICKLE))
	
	if len(rbGlobals.gDocDocLemmatizedWordSimilarityMap) == 0:
		rbGlobals.gDocDocLemmatizedWordSimilarityMap = dict()
	
	for ok in rbGlobals.gDocumentsInCorpusBasename:
		ovector = commonFile.readPickle(os.path.join(rbGlobals.DIR_TFIDF_LEMMATIZED, str(ok) + "." + rbGlobals.EXT_PICKLE))
		for ik in rbGlobals.gDocumentsInCorpusBasename:
			if ok != ik:
				if ok not in rbGlobals.gDocDocLemmatizedWordSimilarityMap.keys():
					rbGlobals.gDocDocLemmatizedWordSimilarityMap[ok] = dict()
				
				if ik not in rbGlobals.gDocDocLemmatizedWordSimilarityMap.keys():
					rbGlobals.gDocDocLemmatizedWordSimilarityMap[ik] = dict()

				if ik not in rbGlobals.gDocDocLemmatizedWordSimilarityMap[ok].keys():
					ivector = pickle.load(open(os.path.join(rbGlobals.DIR_TFIDF_LEMMATIZED, str(ik) + "." + rbGlobals.EXT_PICKLE), "rb"))
					sim = findSimilarityTwoDocumentVectors(str(ok), ovector, str(ik), ivector)
					rbGlobals.gDocDocLemmatizedWordSimilarityMap[ok][ik] = sim
					rbGlobals.gDocDocLemmatizedWordSimilarityMap[ik][ok] = sim
				else:
					commonLogger.detail(ok + " and " + ik + " have already been compared for similarity")
			else:
				commonLogger.detail("skipping due to same key name")
	
	commonFile.writePickle(commonFile.getDocDocLemmatizedWordSimilarityFilePath(), rbGlobals.gDocDocLemmatizedWordSimilarityMap)

	commonLogger.detail("performLemmatizedWordSimilarityWithinCorpusDocuments end")
	return rbGlobals.gDocDocLemmatizedWordSimilarityMap
#end performLemmatizedWordSimilarityWithinCorpusDocuments

def performTopicSimilarityWithinCorpusDocuments():
	commonLogger.detail("performTopicSimilarityWithinCorpusDocuments start")
	
	rbGlobals.gDocumentsInCorpusBasename = commonFile.readPickle(os.path.join(rbGlobals.DIR_CORPUS, rbGlobals.DOCUMENTS_IN_CORPUS_BASENAME + "." + rbGlobals.EXT_PICKLE))
	
	if len(rbGlobals.gDocDocTopicSimilarityMap) == 0:
		rbGlobals.gDocDocTopicSimilarityMap = dict()
	
	for ok in rbGlobals.gDocumentsInCorpusBasename:
		ovector = commonFile.readPickle(os.path.join(rbGlobals.DIR_TFIDF_TOPICS, str(ok) + "." + rbGlobals.EXT_PICKLE))
		for ik in rbGlobals.gDocumentsInCorpusBasename:
			if ok != ik:
				if ok not in rbGlobals.gDocDocTopicSimilarityMap.keys():
					rbGlobals.gDocDocTopicSimilarityMap[ok] = dict()
				
				if ik not in rbGlobals.gDocDocTopicSimilarityMap.keys():
					rbGlobals.gDocDocTopicSimilarityMap[ik] = dict()

				if ik not in rbGlobals.gDocDocTopicSimilarityMap[ok].keys():
					ivector = pickle.load(open(os.path.join(rbGlobals.DIR_TFIDF_TOPICS, str(ik) + "." + rbGlobals.EXT_PICKLE), "rb"))
					sim = findSimilarityTwoDocumentVectors(str(ok), ovector, str(ik), ivector)
					rbGlobals.gDocDocTopicSimilarityMap[ok][ik] = sim
					rbGlobals.gDocDocTopicSimilarityMap[ik][ok] = sim
				else:
					commonLogger.detail(ok + " and " + ik + " have already been compared for similarity")
			else:
				commonLogger.detail("skipping due to same key name")
	
	commonFile.writePickle(commonFile.getDocDocTopicSimilarityFilePath(), rbGlobals.gDocDocTopicSimilarityMap)
	
	commonLogger.detail("performTopicSimilarityWithinCorpusDocuments end")
	return rbGlobals.gDocDocTopicSimilarityMap
#end performTopicSimilarityWithinCorpusDocuments

def performNGramSimilarityWithinCorpusDocuments():
	commonLogger.detail("performNGramSimilarityWithinCorpusDocuments start")
	
	rbGlobals.gDocumentsInCorpusBasename = commonFile.readPickle(os.path.join(rbGlobals.DIR_CORPUS, rbGlobals.DOCUMENTS_IN_CORPUS_BASENAME + "." + rbGlobals.EXT_PICKLE))
	
	if len(rbGlobals.gDocDocNGramSimilarityMap) == 0:
		rbGlobals.gDocDocNGramSimilarityMap = dict()
	
	for ok in rbGlobals.gDocumentsInCorpusBasename:
		ovector = commonFile.readPickle(os.path.join(rbGlobals.DIR_TFIDF_NGRAMS, str(ok) + "." + rbGlobals.EXT_PICKLE))
		for ik in rbGlobals.gDocumentsInCorpusBasename:
			if ok != ik:
				if ok not in rbGlobals.gDocDocNGramSimilarityMap.keys():
					rbGlobals.gDocDocNGramSimilarityMap[ok] = dict()
				
				if ik not in rbGlobals.gDocDocNGramSimilarityMap.keys():
					rbGlobals.gDocDocNGramSimilarityMap[ik] = dict()

				if ik not in rbGlobals.gDocDocNGramSimilarityMap[ok].keys():
					ivector = pickle.load(open(os.path.join(rbGlobals.DIR_TFIDF_NGRAMS, str(ik) + "." + rbGlobals.EXT_PICKLE), "rb"))
					sim = findSimilarityTwoDocumentVectors(str(ok), ovector, str(ik), ivector)
					rbGlobals.gDocDocNGramSimilarityMap[ok][ik] = sim
					rbGlobals.gDocDocNGramSimilarityMap[ik][ok] = sim
				else:
					commonLogger.detail(ok + " and " + ik + " have already been compared for similarity")
			else:
				commonLogger.detail("skipping due to same key name")
	
	commonFile.writePickle(commonFile.getDocDocNGramSimilarityFilePath(), rbGlobals.gDocDocPorterStemmedWordSimilarityMap)
	
	commonLogger.detail("performNGramSimilarityWithinCorpusDocuments end")
	return rbGlobals.gDocDocWordSimilarityMap
#end performNGramSimilarityWithinCorpusDocuments

def findSetSimilarity(docSet, searchSet):
	searchSetSize = len(searchSet)
	docSetSize = len(docSet)
	interSet = searchSet.intersection(docSet)
	matchPercentage = len(interSet)/searchSetSize
	
	return matchPercentage
#end findSetSimilarity

#
# end of commonSimilarity.py
#
