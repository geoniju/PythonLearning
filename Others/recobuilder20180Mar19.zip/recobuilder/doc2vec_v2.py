# based on https://analyticsindiamag.com/nlp-case-study-identify/

import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

import os
import pickle
import sys
import nltk
from nltk.corpus import stopwords
from nltk.probability import FreqDist
import math
import operator
import gensim
from gensim.models.doc2vec import TaggedDocument
#from collections import OrderedDict

def preprocessing(raw):
	wordlist = nltk.word_tokenize(raw)
	text = [w.lower() for w in wordlist if w not in stopwords_en]
	return text

def applyFrequencyCountMethod(word_set, text):
	freqd_text = FreqDist(text)
	text_count_dict = dict.fromkeys(word_set, 0)
	for word in text1:
		text_count_dict[word] = freqd_text[word]
	return text_count_dict

def applyTFIDFMethod(word_set, text):
	freqd_text = FreqDist(text)
	text_length = len(text)
	text_count_dict = dict.fromkeys(word_set, 0)
	for word in text:
		text_count_dict[word] = freqd_text[word]/text_length
	return text_count_dict

def applyTFIDFCalculations(word_set, text, textall_idf_dict):
	text_tfidf_dict = dict.fromkeys(word_set, 0)
	for word in text:
		try:
			text_tfidf_dict[word] = (text_tfidf_dict[word])*(textall_idf_dict[word])
		except KeyError:
			pass
	return text_tfidf_dict

def buildAndTrainModel(input_dir):
	fileNameList = []
	fileText = dict()
	word_set = set()
	
	for file in os.listdir("input"):
		if os.path.isdir(os.path.join("input", file)):
			continue
		#print("Processing ", file)
		name = os.path.splitext(file)[0]
		fileNameList.append(name)
		f = open(os.path.join("input", file), "r", encoding="latin-1")
		text = preprocessing(f.read())
		fileText[name] = text
		word_set.union(text)
	
	textCountDict = dict()
	for f in fileNameList:
		# frequency count method
		#textCountDict[f] = applyFrequencyCountMethod(word_set, fileText[f])
		# TF-IDF method
		#print("applyTFIDFMethod on ", f)
		textCountDict[f] = applyTFIDFMethod(word_set, fileText[f])
	
	#print("IDF calculations")
	# IDF calculations
	idfDict = dict.fromkeys(word_set, 0)
	numDocuments = len(fileNameList)
	for word in idfDict.keys():
		for f in fileNameList:
			if word in fileText[f]:
				idfDict[word] += 1

	for word, val in idfDict.items():
		idfDict[word] = 1 + math.log(numDocuments/float(val))

	#print("TF-IDF calculations")
	# TF-IDF calculations
	for f in fileNameList:
		textCountDict[f] = applyTFIDFCalculations(word_set, fileText[f], idfDict)

	#print("word embedding method")
	# word embedding method
	taggeddocs = []
	docs = dict()
	for f in fileNameList:
		docs[f] = TaggedDocument(words=fileText[f], tags=[f])
		taggeddocs.append(docs[f])

	#print("build the model")
	# build the model
	model = gensim.models.Doc2Vec(taggeddocs, dm=0, alpha=0.025, size=20, min_alpha=0.025, min_count=0)

	#print("model training")
	# training
	for epoch in range(80):
		#if epoch % 20 == 0:
			#print("Now training epoch %s" % epoch)
		model.train(taggeddocs, total_examples=model.corpus_count, epochs=model.iter)
		model.alpha -= 0.02 # decrease the learning rate
		model.min_alpha = model.alpha # fix the learning rate, no decay

	pickle.dump(fileNameList, open(os.path.join("corpus", "doc2vec", "fileNameList.pickle"), "wb"))
	pickle.dump(fileText, open(os.path.join("corpus", "doc2vec", "fileText.pickle"), "wb"))
	pickle.dump(word_set, open(os.path.join("corpus", "doc2vec", "word_set.pickle"), "wb"))
	pickle.dump(model, open(os.path.join("corpus", "doc2vec", "model.pickle"), "wb"))

def computeSimilarity():
	fileNameList = pickle.load(open(os.path.join("corpus", "doc2vec", "fileNameList.pickle"), "rb"))
	fileText = pickle.load(open(os.path.join("corpus", "doc2vec", "fileText.pickle"), "rb"))
	word_set = pickle.load(open(os.path.join("corpus", "doc2vec", "word_set.pickle"), "rb"))
	model = pickle.load(open(os.path.join("corpus", "doc2vec", "model.pickle"), "rb"))
	
	#print("distance computation")
	# distance computation
	"""
	# compute cosine distance
	v1 = list(text1_tfidf_dict.values())
	v2 = list(text2_tfidf_dict.values())
	v3 = list(text3_tfidf_dict.values())
	v4 = list(text4_tfidf_dict.values())

	similarity = 1 - nltk.cluster.cosine_distance(v1, v2)
	print("Similarity index cosine distance doc1 and doc2: {:4.2f} %".format(similarity*100))
	"""

	doc2vecSimilarity = dict()
	for f1 in fileNameList:
		doc2vecSimilarity[f1] = dict()
		for f2 in fileNameList:
			if f1 != f2:
				try:
					if f1 not in doc2vecSimilarity[f1] and f1 not in doc2vecSimilarity[f2]:
						similarity = model.n_similarity(fileText[f1], fileText[f2])
						#print("model Similarity index ", f1, " and ", f2, ": {:4.2f} %".format(similarity2*100))
						#print(f1, ",", f2, ",{:4.2f}".format(similarity*100))
						doc2vecSimilarity[f1][f2] = similarity
				except KeyError:
					pass
	pickle.dump(doc2vecSimilarity, open(os.path.join("corpus", "doc2vec", "similarity.pickle"), "wb"))

def computeSimilarityForStringInitial(searchStr):
	fileNameList = pickle.load(open(os.path.join("corpus", "doc2vec", "fileNameList.pickle"), "rb"))
	fileText = pickle.load(open(os.path.join("corpus", "doc2vec", "fileText.pickle"), "rb"))
	word_set = pickle.load(open(os.path.join("corpus", "doc2vec", "word_set.pickle"), "rb"))
	model = pickle.load(open(os.path.join("corpus", "doc2vec", "model.pickle"), "rb"))
	
	#print("distance computation")
	# distance computation
	"""
	# compute cosine distance
	v1 = list(text1_tfidf_dict.values())
	v2 = list(text2_tfidf_dict.values())
	v3 = list(text3_tfidf_dict.values())
	v4 = list(text4_tfidf_dict.values())

	similarity = 1 - nltk.cluster.cosine_distance(v1, v2)
	print("Similarity index cosine distance doc1 and doc2: {:4.2f} %".format(similarity*100))
	"""

	doc2vecSearchStringSimilarity = dict()
	for f in fileNameList:
		#print(f)
		try:
			similarity = model.n_similarity(fileText[f], searchStr)
			print(f, ",", similarity)
			doc2vecSearchStringSimilarity[f] = similarity
		except KeyError:
			print(f, "error")
			pass
	return doc2vecSearchStringSimilarity

def computeSimilarityForString(searchStr):
	fileNameList = pickle.load(open(os.path.join("corpus", "doc2vec", "fileNameList.pickle"), "rb"))
	fileText = pickle.load(open(os.path.join("corpus", "doc2vec", "fileText.pickle"), "rb"))
	word_set = pickle.load(open(os.path.join("corpus", "doc2vec", "word_set.pickle"), "rb"))
	model = pickle.load(open(os.path.join("corpus", "doc2vec", "model.pickle"), "rb"))
	
	tokens = searchStr.split()
	
	new_vector = model.infer_vector(tokens)
	sims = model.docvecs.most_similar([new_vector]) #gives you top 10 document tags and their cosine similarity
	
	return sims

def similarityWithSearchString(searchStr):
	similarity = computeSimilarityForString(searchStr)
	print("Similarity with search string: ", searchStr)
	print(similarity)

def displaySimilarity():
	doc2vecSimilarity = pickle.load(open(os.path.join("corpus", "doc2vec", "similarity.pickle"), "rb"))
	
	linearDict = dict()
	for key in sorted(doc2vecSimilarity):
		sorted_data = sorted(doc2vecSimilarity[key].items(), key=operator.itemgetter(1), reverse=True)
		for k2, value in sorted_data:
			try:
				#print(key, ",", k2, ",", doc2vecSimilarity[key][k2])
				#print(key, ",", k2, ",", value)
				newKey = key + ":" + k2
				linearDict[newKey] = value
			except KeyError:
				pass
		#print(key, ",", sorted_data)
	
	#print(linearDict)
	linear_sorted_data = sorted(linearDict.items(), key=operator.itemgetter(1), reverse=True)
	#print(linear_sorted_data)
	for k, value in linear_sorted_data:
		try:
			print(k, ",", value)
		except KeyError:
			print(k, ",", 0.0)
	
stopwords_en = stopwords.words("english")

def computeModel(input_dir):
	#print("buildAndTrainModel")
	buildAndTrainModel(input_dir)
	#print("computeSimilarity")
	computeSimilarity()

def displayModel():
	#print("displaySimilarity")
	displaySimilarity()

if __name__ == "__main__":
	computeModel()
	
	similarityWithSearchString("text analytics")
	similarityWithSearchString("business analytics")
	similarityWithSearchString("data warehouse")

# end
