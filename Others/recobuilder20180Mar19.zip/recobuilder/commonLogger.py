"""
Data Science Challenge 4 - Search engine for sales team

Group Name:
	RecoBuilder

Authors:
	1. Bipin Patwardhan, bipin.patwardhan@capgemini.com
	2. Suvarna Fernandes, suvarna.fernandes@capgemini.com
	3. Geo Shanth, geo.shanth@capgemini.com
	4. Philippe Roudil, philippe.roudil@service.capgemini.com
	
File:
	commonLogger.py

Description:
	common logging functions defined. Ideally should used standard logger
"""

import rbGlobals

# define constants
ALL=0
DETAIL=1
DEBUG=2
INFO=3
WARNING=4
ERROR=5
FATAL=6
OFF=7

# default message level
#level = DETAIL
#level = DEBUG
level = INFO

#
# common message functions
#

def detail(str, indent=0):
	if level != OFF:
		if level <= DETAIL or level == ALL:
			i = 0
			tabs = ""
			#while i < indet:
			#	tabs = tabs + "\t"
			#	i++
			print(tabs + "DETAIL: " + str)
#end detail

def debug(str):
	if level != OFF:
		if level <= DEBUG or level == ALL:
			print("DEBUG: " + str)
#end debug

def warning(str):
	if level != OFF:
		if level <= WARNING or level == ALL:
			print("WARNING: " + str)
#end warning

def info(str):
	if level != OFF:
		if level <= INFO or level == ALL:
			print("INFO: " + str)
#end info

def error(str):
	if level != OFF:
		if level <= ERROR or level == ALL:
			print("ERROR: " + str)
#end error

def fatal(str):
	if level != OFF:
		if level <= FATAL or level == ALL:
			print("FATAL: " + str)
#end fatal

#
# end of commonLogger.py
#
