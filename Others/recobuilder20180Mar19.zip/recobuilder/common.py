"""
Data Science Challenge 4 - Search engine for sales team

Group Name:
	RecoBuilder

Authors:
	1. Bipin Patwardhan, bipin.patwardhan@capgemini.com
	2. Suvarna Fernandes, suvarna.fernandes@capgemini.com
	3. Geo Shanth, geo.shanth@capgemini.com
	4. Philippe Roudil, philippe.roudil@service.capgemini.com
	
File:
	common.py

Description:
	TO BE ADDED
"""

import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

import operator
import os
from collections import OrderedDict
import math
import string
from string import punctuation
import unicodedata
from bs4 import BeautifulSoup
import requests
import pickle
import sys
import csv
import chardet
import codecs
import re, collections
from autocorrect import spell
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk.collocations import BigramCollocationFinder
from nltk.metrics import BigramAssocMeasures
from nltk.stem.porter import PorterStemmer
from nltk.stem import LancasterStemmer
from nltk.stem import SnowballStemmer
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer

import rbGlobals
import commonLogger
#import commonFile
#from kmeansPredict import *
#import stanfordNERCoreNLP


# Get all words from the corpus
def tokens(text):
	return re.findall('[a-z]+', text.lower())
#end tokens

def tokenizeString(str):
	tokens = word_tokenize(str)
	return tokens
#end tokenizeString

def tokenize(text):
	words = word_tokenize(text)
	words = [w.lower() for w in words]
	return [w for w in words if w not in rbGlobals.gStopWords and not w.isdigit()]
#end tokenize

def stringFromTokens(tokens, separator):
	return separator.join(tokens)
	#return " ".join(tokens)
#end stringFromTokens

def makeStringFromList(list, separator):
	return separator.join(list)
#end makeStringFromList

def decode(text, encoding):
	#text = text.decode("utf8")
	return text.decode(encoding)
#end decode

def tokensLowercase(tokens):
	words = [w.lower() for w in tokens]
	return words
#end toLowercase

# count words
def wordCount(filtered_tokens):
	count = nltk.defaultdict(int)
	for word in filtered_tokens:
		count[word] += 1
	return count
#end wordCount

def makeStringFromSet(wordSet, separator):
	str = []
	for w in wordSet:
		str.append(" ") + w
	return str
#end makeStringFromSet

def makeListFromSet(wordSet, separator):
	wordList = []
	for w in wordSet:
		wordList.append(w)
	return wordList
#end makeListFromSet


def removeStopWords(pStopWords, words):
	return [w for w in words if w not in pStopWords and not w.isdigit()]
#end removeStopWords

# https://stackoverflow.com/questions/265960/best-way-to-strip-punctuation-from-a-string-in-python
# python 3 impl
def removePunctuation(str):
	table = str.maketrans({key: None for key in string.punctuation})
	return str.translate(table)
#end removePunctuation

# https://stackoverflow.com/questions/265960/best-way-to-strip-punctuation-from-a-string-in-python
def removeSomePunctuation(str):
	remove_punct_map = dict.fromkeys(map(ord, string.punctuation))
	return str.translate(remove_punct_map)
#end removeSomePunctuation

# https://stackoverflow.com/questions/265960/best-way-to-strip-punctuation-from-a-string-in-python
# remove unicode punctuation also
def removeAllPunctuation(str):
	remove_punct_map = dict.fromkeys(i for i in range(sys.maxunicode) if unicodedata.category(chr(i)).startswith('P'))
	return str.translate(remove_punct_map)
#end removeAllPunctuation

# https://stackoverflow.com/questions/11066400/remove-punctuation-from-unicode-formatted-strings/11066687#11066687
def removeAllPunctuation2(str):
	tbl = dict.fromkeys(i for i in xrange(sys.maxunicode) if unicodedata.category(unichr(i)).startswith('P'))
	return str.translate(tbl)
#end removeallPunctuation2

# https://stackoverflow.com/questions/11066400/remove-punctuation-from-unicode-formatted-strings/11066687#11066687
#def removePunctuationRegex(str):
#	return re.sub(ur"\p{P}+", "", str)

def removeCharactersAfterTokenization(tokens):
	pattern = re.compile('[{}]'.format(re.escape(string.punctuation)))
	filtered_tokens = filter(None, [pattern.sub('', token) for token in tokens])
	return filtered_tokens
#end removeCharactersAfterTokenization

def removeRepeatedCharacters(tokens):
	repeat_pattern = re.compile(r'(\w*)(\w)\2(\w*)')
	match_substitution = r'\1\2\3'
	
	def replace(old_word):
		if wordnet.synsets(old_word):
			return old_word
		
		new_word = repeat_pattern.sub(match_substitution, old_word)
		return replace(new_word) if new_word != old_word else new_word
	#end replace
		
	correct_tokens = [replace(word) for word in tokens]
	return correct_tokens
#end removeRepeatedCharacters

# Contractions are shortened version of words or syllables
def expandContractions(contraction_map, sentence):
	contractions_pattern = re.compile('({})'.format('|'.join(contraction_map.keys())), flags=re.IGNORECASE|re.DOTALL)
	
	def expandMatch(contraction):
		match = contraction.group(0)
		first_char = match[0]
		expanded_contraction = contraction_map.get(match) if contraction_map.get(match) else contraction_map.get(match.lower())
		expanded_contraction = first_char+expanded_contraction[1:]
		return expanded_contraction
	#end expandMatch
		
	expanded_sentence = contractions_pattern.sub(expandMatch, sentence)
	return expanded_sentence
#end expandContractions
	
# text analytics with python page 175
def expandContractions2(contraction_map, text):
	contractions_pattern = re.compile('({})'.format('|'.join(contraction_map.keys())), flags=re.IGNORECASE|re.DOTALL)
	
	def expandMatch2(contraction):
		match = contraction.group(0)
		first_char = match[0]
		expanded_contraction = contraction_map.get(match) if contraction_map.get(match) else contraction_map.get(match.lower())
		expanded_contraction = first_char+expanded_contraction[1:]
		return expanded_contraction
	#end expandMatch2
		
	expanded_text = contractions_pattern.sub(expandMatch2, text)
	expanded_text = re.sub("'", "", expanded_text)
	return expanded_text
#end expandContractions2

def expandAcronyms(acronym_map, sentence):
	acronyms_pattern = re.compile('({})'.format('|'.join(acronym_map.keys())), flags=re.IGNORECASE|re.DOTALL)
	
	def expandAcronymMatch(acronym):
		match = acronym.group(0)
		first_char = match[0]
		expanded_acronym = acronym_map.get(match) if acronym_map.get(match) else acronym_map.get(match.lower())
		expanded_acronym = first_char+expanded_acronym[1:]
		return expanded_acronym
	#end expandAcronymMatch
		
	expanded_sentence = acronym_pattern.sub(expandAcronymMatch, sentence)
	return expanded_sentence
#end expandAcronyms

def replaceAcronymsInString(acronymDictionary, tokens):
	for key in sorted(acronymDictionary, key=lambda x:len(x), reverse=True):
		str = str.replace(key, acronymDictionary[key])
	return str
#end replaceAcronymsInString

def replaceAcronyms(miscExpansionsDictionary, tokens):
	words = []
	for t in tokens:
		for key in sorted(miscExpansionsDictionary, key=lambda x:len(x), reverse=True):
			w = t.replace(key, miscExpansionsDictionary[key])
			words.append(w)
	return words
#end replaceAcronyms

def edits0(word):
	# Return all strings that are zero edits away from the input word (i.e., the word itself).
	return {word}
#end edits0

def edits1(word):
	# Return all strings that are one edit away from the input word.
	alphabet = 'abcdefghijklmnopqrstuvwxyz'
	
	def splits( word):
		# Return a list of all possible (first, rest) pairs that the input word is made of.
		return [(word[:i], word[i:]) for i in range(len(word)+1)]
	#end splits
		
	pairs = splits(word)
	deletes = [a+b[1:] for (a, b) in pairs if b]
	transposes = [a+b[1]+b[0]+b[2:] for (a, b) in pairs if len(b) > 1]
	replaces = [a+c+b[1:] for (a, b) in pairs for c in alphabet if b]
	inserts = [a+c+b for (a, b) in pairs for c in alphabet]
	return set(deletes + transposes + replaces + inserts)
#end edits1
	
def edits2(word):
	#Return all strings that are two edits away from the input word.
	return {e2 for e1 in edits1(word) for e2 in edits1(e1)}
#end edits2
	
def known(words):
	# Return the subset of words that are actually in our gWordCounts dictionary.
	return {w for w in words if w in rbGlobals.gWordCounts}
#end known
		
# word correction
def correctWord(word, wordCounts):
	# Get the best correct spelling for the input word
	# Priority is for edit distance 0, then 1, then 2
	# else defaults to the input word itself.
	candidates = (known(edits0(word)) or known(edits1(word)) or known(edits2(word)) or [word])
	return max(candidates, key=wordCounts.get)
#end correctWord

def correctMatch(match):
	# Spell-correct word in match, and preserve proper upper/lower/title case.
	word = match.group()
	
	def caseOf(text):
		# Return the case-function appropriate for text: upper, lower, title, or just str.:
		return (str.upper if text.isupper() else
			str.lower if text.islower() else
			str.title if text.istitle() else
			str)
	#end caseOf
			
	return caseOf(word)(correctWord(word.lower(), rbGlobals.gWordCounts))
#end correctMatch

def correctTextGeneric(text):
	# Correct all the words within a text, returning the corrected text.
	return re.sub('[a-zA-Z]+', correctMatch, text)
#end correctTextGeneric

def correctTokens(tokens):
	# Correct all the tokens in a list, returning the correct list
	#return re.sub('[a-zA-Z]+', correctMatch, text)
	words = []
	for w in tokens:
		words.append(re.sub('[a-zA-Z]+', correctMatch, w))
	return words
#end correctTokens
	
def spellCheckTokens(tokens):
	words = []
	for w in tokens:
		words.append(spell(w))
	return words
#end spellCheckTokens

#
# word stemming
#

def stemWordsPorter(words):
	stemmed = []
	for item in words:
		stemmed.append(rbGlobals.gPorterStemmer.stem(item))
	return stemmed
#end stemWordsPorter
	
def stemWordsLancaster(words):
	stemmed = []
	for item in words:
		stemmed.append(rbGlobals.gLancasterStemmer.stem(item))
	return stemmed
#end stemWordsLancaster
	
def stemWordsSnowball(words):
	stemmed = []
	for item in words:
		stemmed.append(rbGlobals.gSnowballStemmer.stem(item))
	return stemmed
#end stemWordsSnowball

#
# word lemmatization
#

def lemmatizeWords(words):
	lemmatized = []
	for item in words:
		lemmatized.append(rbGlobals.gWordnetLemmatizer.lemmatize(item))
	return lemmatized
#end lemmatizeWords

#
# text classification
#
def bagOfWords(words):
	return dict([(word, True) for word in words])
#end bagOfWords

def bagOfWordsNotInSet(words, badwords):
	return bagOfWords(set(words) - set(badwords))
#end bag_of_words_not_in_set

def bagOfNonStopwords(words, stopfile='english'):
	badwords = stopwords.words(stopfile)
	return bagOfWordsNotInSet(words, badwords)
#end bag_of_non_stopwords

def bagOfBigramsWords(words, score_fn=BigramAssocMeasures.chi_sq, n=200):
	bigram_finder = BigramCollocationFinder.from_words(words)
	bigrams = bigram_finder.nbest(score_fn, n)
	return bagOfWords(words + bigrams)
#end bag_of_bigrams_words


#
# high-level functions
#
def basicTextProcessingCorpusDocument(text, stopWords, contractionMap, acronymMap, miscExpansionsMap, incorrectOrgSet):
	commonLogger.detail("basicTextProcessingCorpusDocument start")
	
	commonLogger.detail("Conveting text to lower case")
	text_lower = text.lower()
	#commonLogger.detail(text_lower)
	
	commonLogger.detail("expanding contractions")
	text = expandContractions(contractionMap, text_lower)
	
	commonLogger.detail("remove punctuations")
	#text = removePunctuation(text)
	text = removeAllPunctuation(text)
	#commonLogger.detail(text)
	
	commonLogger.detail("converting to words")
	#words = tokenizeString(text)
	words = word_tokenize(text)
	#commonLogger.detail(str(words))
	
	commonLogger.detail("removing stop words")
	#words = removeStopWords(stopWords, words)
	words = [w for w in words if w not in stopWords and not w.isdigit()]
	#commonLogger.detail(str(words))
	
	#commonLogger.detail("expanding acronyms")
	#words = replaceAcronyms(acronymMap, words)
	
	#commonLogger.detail("removing repeated characters")
	#words = removeRepeatedCharacters(words)
	#commonLogger.detail(str(words))
	
	#commonLogger.detail("correcting words using correctTokens")
	#words = correctTokens(words)
	#commonLogger.detail(str(words))
	
	##commonLogger.detail("correcting words using spellcheck")
	##words = spellCheckTokens(words)
	#commonLogger.detail(str(words))
	
	commonLogger.detail("basicTextProcessingCorpusDocument end")
	return words
#end basicTextProcessingCorpusDocument

def basicTextProcessingSearchString(text, stopWords, contractionMap, acronymMap, miscExpansionsMap, incorrectOrgSet):
	commonLogger.detail("basicTextProcessingSearchString start")
	
	commonLogger.detail("Conveting text to lower case")
	text_lower = text.lower()
	#commonLogger.detail(text_lower)
	
	#commonLogger.detail("expanding contractions")
	#text = expandContractions(contractionMap, text_lower)
	
	#commonLogger.detail("remove punctuations")
	text = removePunctuation(text)
	#text = removeAllPunctuation(text)
	#commonLogger.detail(text)
	
	commonLogger.detail("converting to words")
	#words = tokenizeString(text)
	words = word_tokenize(text)
	#commonLogger.detail(str(words))
	
	commonLogger.detail("removing stop words")
	#words = removeStopWords(stopWords, words)
	words = [w for w in words if w not in stopWords and not w.isdigit()]
	#commonLogger.detail(str(words))
	
	#commonLogger.detail("expanding acronyms")
	#words = replaceAcronyms(words, acronymMap)
	
	#commonLogger.detail("removing repeated characters")
	#words = removeRepeatedCharacters(words)
	#commonLogger.detail(str(words))
	
	#commonLogger.detail("correcting words using correctTokens")
	#words = correctTokens(words)
	#commonLogger.detail(str(words))
	
	##commonLogger.detail("correcting words using spellcheck")
	##words = spellCheckTokens(words)
	#commonLogger.detail(str(words))
	
	commonLogger.detail("basicTextProcessingSearchString end")
	return words
#end basicTextProcessingSearchString

def basicTextProcessingNERDocument(text, stopWords, contractionMap, acronymMap, miscExpansionsMap, incorrectOrgSet):
	commonLogger.detail("basicTextProcessingNERDocument start")
	
	commonLogger.detail("Conveting text to lower case")
	text_lower = text.lower()
	#commonLogger.detail(text_lower)
	
	commonLogger.detail("expanding contractions")
	text = expandContractions(contractionMap, text_lower)
	
	commonLogger.detail("remove punctuations")
	#text = removePunctuation(text)
	text = removeAllPunctuation(text)
	#commonLogger.detail(text)
	
	commonLogger.detail("converting to words")
	#words = tokenizeString(text)
	words = word_tokenize(text)
	#commonLogger.detail(str(words))
	
	commonLogger.detail("removing stop words")
	#words = removeStopWords(stopWords, words)
	words = [w for w in words if w not in stopWords and not w.isdigit()]
	#commonLogger.detail(str(words))
	
	#commonLogger.detail("expanding acronyms")
	#words = replaceAcronyms(words, acronymMap)
	
	#commonLogger.detail("removing repeated characters")
	#words = removeRepeatedCharacters(words)
	#commonLogger.detail(str(words))
	
	#commonLogger.detail("correcting words using correctTokens")
	#words = correctTokens(words)
	#commonLogger.detail(str(words))
	
	##commonLogger.detail("correcting words using spellcheck")
	##words = spellCheckTokens(words)
	#commonLogger.detail(str(words))
	
	commonLogger.detail("basicTextProcessingNERDocument end")
	return words
#end basicTextProcessingNERDocument

def getIncorrectOrganizationSet(fname):
	list = readFileIntoList(fname)
	orgSet = set()
	for l in list:
		orgSet.add(l)
	return orgSet
#end getIncorrectOrganizationSet

def sortDictionaryOnKeyAscending(data):
	sorted_data = sorted(data.items(), key=operator.itemgetter(0))
#end sortDictionaryOnKeyAscending

def sortDictionaryOnKeyDescending(data):
	sorted_data = sorted(data.items(), key=operator.itemgetter(0), reverse=True)
#end sortDictionaryOnKeyDescending

def sortDictionaryOnValueAscending(data):
	sorted_data = sorted(data.items(), key=operator.itemgetter(1))
	return sorted_data
#end sortDictionaryOnValueAscending

def sortDictionaryOnValueDescending(data):
	sorted_data = sorted(data.items(), key=operator.itemgetter(1), reverse=True)
	return sorted_data
#end sortDictionaryOnValueDescending

def getTopDataSet(data, count):
	topData = []
	if count == -1: # iterate over all elements in the list
		count = len(data)
	
	if count > len(data):
		count = len(data)

	i = 0
	while i < count:
		topData.append(data[i])
		i = i + 1
	return topData
#end topResults

"""
https://snippets.aktagon.com/snippets/619-how-to-generate-n-grams-with-python-and-nltk
How to generate n-grams with Python and NLTK

import nltk
from nltk.util import ngrams

def word_grams(words, min=1, max=4):
    s = []
    for n in range(min, max):
        for ngram in ngrams(words, n):
            s.append(' '.join(str(i) for i in ngram))
    return s

print word_grams('one two three four'.split(' '))
"""

#
# end of common.py
#
