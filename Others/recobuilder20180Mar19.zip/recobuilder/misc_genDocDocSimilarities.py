
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import pandas as pd
import sys
import os
import codecs
import pickle
import csv
import chardet

import rbGlobals
import common
import commonFile
import commonLogger
import commonSimilarity
import commonTopics
import commonNER
import ngrams
import topicModelerFile

if __name__ == "__main__":
	print("Generating document to document word similarity")
	commonSimilarity.performWordSimilarityWithinCorpusDocuments()
	
	print("Generating document to document porter stemmer word similarity")
	commonSimilarity.performPorterStemmedWordSimilarityWithinCorpusDocuments()
	
	print("Generating document to document lemmatized word similarity")
	commonSimilarity.performLemmatizedWordSimilarityWithinCorpusDocuments()
	
	print("Generating document to document ngram similarity")
	commonSimilarity.performNGramSimilarityWithinCorpusDocuments()
	
	print("Generating document to document topic similarity")
	commonSimilarity.performTopicSimilarityWithinCorpusDocuments()
