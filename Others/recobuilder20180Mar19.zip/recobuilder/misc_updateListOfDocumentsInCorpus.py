
import os
import pickle

def temp(str):
	print("hello world " + str)

gDocumentsInCorpusFilePath = []
gDocumentsInCorpusBasename = []

for filename in os.listdir("corpus\\tfidf_words"):
	if filename.endswith(".pickle"):
		print("Adding '%s' to the corpus document list" % filename)
		temp("Adding '%s' to the corpus document list" % filename)
		gDocumentsInCorpusFilePath.append(filename)
		gDocumentsInCorpusBasename.append(os.path.splitext(filename)[0])

fname1 = os.path.join("corpus", "documentsInCorpusFilePath2.pickle")
pickle.dump(gDocumentsInCorpusFilePath, open(fname1, "wb"))
fname2 = os.path.join("corpus", "documentsInCorpusBasename2.pickle")
pickle.dump(gDocumentsInCorpusBasename, open(fname2, "wb"))
