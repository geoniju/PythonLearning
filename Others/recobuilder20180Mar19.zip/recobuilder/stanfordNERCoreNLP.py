# this code refers to the Stanford CoreNLP server which needs to be executed using the following command
# rem https://cindyxiaoxiaoli.wordpress.com/2017/04/10/how-to-use-stanford-corenlp-in-python/
# java -mx4g -cp "*" edu.stanford.nlp.pipeline.StanfordCoreNLPServer -port 9000 -timeout 15000

import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

from nltk.tag.stanford import CoreNLPPOSTagger, CoreNLPNERTagger
from itertools import groupby
from nltk import pos_tag
from nltk.chunk import conlltags2tree
from nltk.tree import Tree
from collections import defaultdict

import commonLogger

def printTuplesInList(data):
	for (k, v) in data:
		print(k, " : ", v)

def collectTuplesByFirstElement(data):
	d = defaultdict(list)
	for k, v in data:
		d[k].append(v)    
	print(sorted(d.items()))

def collectTuplesBySecondElement(data):
	d = defaultdict(list)
	for k, v in data:
		d[v].append(k)
	print(sorted(d.items()))

def tagTheText(text):
	commonLogger.debug("CoreNLP NER Tagger - tagTheText - start")
	stpos, stner = CoreNLPPOSTagger(), CoreNLPNERTagger()

	tags = stner.tag(text.split())
	#print(tags)
	
	#print("print tuples in list")
	#printTuplesInList(tags)
	#print("collect tuples by first element")
	#collectTuplesByFirstElement(tags)
	#print("collect tuples by second element")
	#collectTuplesBySecondElement(tags)

	# Extract list of Persons and Organizations using Stanford NER Tagger in NLTK
	# https://stackoverflow.com/questions/30664677/extract-list-of-persons-and-organizations-using-stanford-ner-tagger-in-nltk

	#IOB/BIO means Inside, Outside, Beginning (IOB), or sometimes aka Beginning, Inside, Outside (BIO)
	#The Stanford NE tagger returns IOB/BIO style tags, e.g.

	"""
	print("group by >>---------------------------------------------------------")
	for tag, chunk in groupby(tags, lambda x:x[1]):
		if tag != "O":
			print("%-12s"%tag, " ".join(w for w, t in chunk))
	"""
	
	#tagMap = dict()
	consolidategTagMap = dict()
	#print("tag map >>---------------------------------------------------------")
	"""
	for tag, chunk in groupby(tags, lambda x:x[1]):
		if tag != "O":
			#if tag not in tagMap:
				#tagMap[tag] = []
			if tag not in consolidategTagMap:
				#consolidategTagMap[tag] = []
				consolidategTagMap[tag] = set()
			
			for w, t in chunk:
				#tagMap[tag].append(w)
				#consolidategTagMap[tag].append(w)
				consolidategTagMap[tag].add(w)
	"""
	for tag, chunk in groupby(tags, lambda x:x[1]):
		#if tag not in tagMap:
			#tagMap[tag] = []
		if tag not in consolidategTagMap:
			#consolidategTagMap[tag] = []
			consolidategTagMap[tag] = set()
		
		for w, t in chunk:
			#tagMap[tag].append(w)
			#consolidategTagMap[tag].append(w)
			consolidategTagMap[tag].add(w)
	
	#for tk in tagMap.keys():
	#	print("tk: ", tk, ", list: ", tagMap[tk])
	
	##ne_tagged_sent = [('Rami', 'PERSON'), ('Eid', 'PERSON'), ('is', 'O'), ('studying', 'O'), ('at', 'O'), ('Stony', 'ORGANIZATION'), ('Brook', 'ORGANIZATION'), ('University', 'ORGANIZATION'), ('in', 'O'), ('NY', 'LOCATION')]
	##named_entities = get_continuous_chunks(ne_tagged_sent)
	named_entities = get_continuous_chunks(tags)
	# convert list of list of tagged element pairs into list of elements. tags are omitted
	named_entities_str = [" ".join([token for token, tag in ne]) for ne in named_entities]
	# convert list of list of tagged element pairs into list of tagged element pairs
	named_entities_str_tag = [(" ".join([token for token, tag in ne]), ne[0][1]) for ne in named_entities]

	#print("named_entities >>------------------------------------------")
	#print(named_entities)
	#print("named_entities_str >>-------------------------------------------------")
	#print(named_entities_str)
	#print("named_entities_str_tag >>---------------------------------------------------------")
	#print(named_entities_str_tag)
	#print("named_entities_str_tag map >>---------------------------------------------------------")
	
	#tagMap2 = dict()
	for d, k in named_entities_str_tag:
		#if k not in tagMap2:
			#tagMap2[k] = []
		if k not in consolidategTagMap:
			#consolidategTagMap[k] = []
			consolidategTagMap[k] = set()
				
		#tagMap2[k].append(d)
		#consolidategTagMap[k].append(d)
		consolidategTagMap[k].add(d)
	
	#for tk in tagMap2.keys():
	#	print("key: ", tk, ", list: ", tagMap2[tk])
	
	#ne_tagged_sent = [('Rami', 'PERSON'), ('Eid', 'PERSON'), ('is', 'O'), ('studying', 'O'), ('at', 'O'), ('Stony', 'ORGANIZATION'), ('Brook', 'ORGANIZATION'), ('University', 'ORGANIZATION'), ('in', 'O'), ('NY', 'LOCATION')]
	#ne_tree = stanfordNE2tree(ne_tagged_sent)

	ne_tree = stanfordNE2tree(tags)
	#print("ne_tree >>---------------------------------------------------------")
	#print(ne_tree)

	ne_in_sent = []
	for subtree in ne_tree:
		if type(subtree) == Tree: # If subtree is a noun chunk, i.e. NE != "O"
			ne_label = subtree.label()
			ne_string = " ".join([token for token, pos in subtree.leaves()])
			ne_in_sent.append((ne_string, ne_label))
	#print("ne_in_sent >>---------------------------------------------------------")
	#print(ne_in_sent)
	#print(">>---------------------------------------------------------")
	
	for d, k in ne_in_sent:
		if k not in consolidategTagMap:
			#consolidategTagMap[k] = []
			consolidategTagMap[k] = set()
				
		#consolidategTagMap[k].append(d)
		consolidategTagMap[k].add(d)
	
	#print("consolidated tag map >> --------------------------------------------------")
	#for tk in consolidategTagMap.keys():
	#	print("key: ", tk, ", list: ", consolidategTagMap[tk])
	
	commonLogger.debug("CoreNLP NER Tagger - tagTheText - end")
	return consolidategTagMap
#end tagTheText


def get_continuous_chunks(tagged_sent):
	continuous_chunk = []
	current_chunk = []

	for token, tag in tagged_sent:
		if tag != "O":
			current_chunk.append((token, tag))
		else:
			if current_chunk: # if the current chunk is not empty
				continuous_chunk.append(current_chunk)
				current_chunk = []
	# Flush the final current_chunk into the continuous_chunk, if any.
	if current_chunk:
		continuous_chunk.append(current_chunk)
	return continuous_chunk

# As @alexis suggested, it's better to convert the stanford NE output into NLTK trees:

def stanfordNE2BIO(tagged_sent):
	bio_tagged_sent = []
	prev_tag = "O"
	for token, tag in tagged_sent:
		if tag == "O": #O
			bio_tagged_sent.append((token, tag))
			prev_tag = tag
			continue
		if tag != "O" and prev_tag == "O": # Begin NE
			bio_tagged_sent.append((token, "B-"+tag))
			prev_tag = tag
		elif prev_tag != "O" and prev_tag == tag: # Inside NE
			bio_tagged_sent.append((token, "I-"+tag))
			prev_tag = tag
		elif prev_tag != "O" and prev_tag != tag: # Adjacent NE
			bio_tagged_sent.append((token, "B-"+tag))
			prev_tag = tag
	return bio_tagged_sent

def stanfordNE2tree(ne_tagged_sent):
	bio_tagged_sent = stanfordNE2BIO(ne_tagged_sent)
	sent_tokens, sent_ne_tags = zip(*bio_tagged_sent)
	sent_pos_tags = [pos for token, pos in pos_tag(sent_tokens)]

	sent_conlltags = [(token, pos, ne) for token, pos, ne in zip(sent_tokens, sent_pos_tags, sent_ne_tags)]
	ne_tree = conlltags2tree(sent_conlltags)
	return ne_tree

#
# end of script
#
