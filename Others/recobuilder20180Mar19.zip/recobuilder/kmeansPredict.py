# https://pythonprogramminglanguage.com/kmeans-text-clustering/

import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score

import common
import commonLogger
import rbGlobals
 
def cluster_documents(documents, num_clusters=5, num_iter=100):
	#vectorizer = TfidfVectorizer(stop_words='english')
	vectorizer = TfidfVectorizer(stop_words=rbGlobals.gLanguage)
	X = vectorizer.fit_transform(documents)

	true_k = num_clusters
	model = KMeans(n_clusters=true_k, init='k-means++', max_iter=num_iter, n_init=1)
	model.fit(X)
	
	return model, vectorizer

def print_kmeans_model(model, vectorizer, num_clusters=5, num_terms=10):
	print("Top terms per cluster:")
	order_centroids = model.cluster_centers_.argsort()[:, ::-1]
	terms = vectorizer.get_feature_names()
	for i in range(num_clusters):
		print("Cluster %d:" % i),
		for ind in order_centroids[i, :num_terms]:
			print(' %s' % terms[ind]),
		print()
		
def print_kmeans_model_all(model, vectorizer, num_clusters=-1, num_terms=-1):
	print("Top terms per cluster:")
	order_centroids = model.cluster_centers_.argsort()[:, ::-1]
	terms = vectorizer.get_feature_names()
	if num_clusters < 0:
		num_clusters = len(order_centroids)
	for i in range(num_clusters):
		print("Cluster %d:" % i),
		if ( num_terms < 0 ):
			num_terms = len(terms)
			print("num terms: ", terms)
		for ind in order_centroids[i, :num_terms]:
			print(' %s' % terms[ind]),
		print()

def predict_kmeans_cluster(model, vectorizer, str):
	#print("Prediction")
 
	doc = [ str ]
	Y = vectorizer.transform(doc)
	prediction = model.predict(Y)
	#print(prediction)
	return prediction

def getListOfDocumentsInTheSameClusterForSearchString(model, vectorizer, documentsInCorpusBasename, documentToKMeansClusterMap, text, numDocuments):
	primaryPrediction = predict_kmeans_cluster(model, vectorizer, text)
	
	#print("*************************************")
	#print(documentsInCorpusBasename)
	#print("*************************************")
	#print(documentToKMeansClusterMap)
	#print("*************************************")
	
	count = 0
	documentsInSameCluster = []
	for d in documentsInCorpusBasename:
		if count < numDocuments:
			try:
				predictionDocument = documentToKMeansClusterMap[d]
				if primaryPrediction[0] == predictionDocument[0]:
					documentsInSameCluster.append(d)
					count = count + 1
			except KeyError:
				commonLogger.warning("Cluster map for " + d + " NOT found")
		else:
			break

	return documentsInSameCluster
#end getListOfDocumentsInTheSameClusterForSearchString

def getListOfDocumentsInTheSameCluster(model, vectorizer, documentsInCorpusBasename, documentToKMeansClusterMap, docName, numDocuments):
	primaryDocumentPrediction = documentToKMeansClusterMap[docName]
	
	count = 0
	documentsInSameCluster = []
	for d in documentsInCorpusBasename:
		if count < numDocuments:
			try:
				predictionDocument = documentToKMeansClusterMap[d]
				if primaryDocumentPrediction[0] == predictionDocument[0]:
					if d != docName:
						documentsInSameCluster.append(d)
						count = count + 1
			except KeyError:
				commonLogger.warning("Cluster map for " + d + " NOT found")
		else:
			break

	return documentsInSameCluster
#end getListOfDocumentsInTheSameClusterForSearchString
