# define global variables used in the application

import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

import os
from nltk.corpus import stopwords
from string import punctuation
import collections
from nltk.stem.porter import PorterStemmer
from nltk.stem import LancasterStemmer
from nltk.stem import SnowballStemmer
from nltk.stem import WordNetLemmatizer

import common

#
# define commonly used constants
#

#DIR_SEPARATOR = "\\"
DIR_INPUT = "input"
DIR_OUTPUT = "output"
DIR_CORPUS = "corpus"
EXT_CORPUS = "pickle"
DIR_SUPPORT = "support"
DIR_ORG = "org"
#DIR_ORG_WIKIPEDIA = DIR_ORG + DIR_SEPARATOR + "wikipedia"
DIR_ORG_WIKIPEDIA = os.path.join(DIR_ORG, "wikipedia")
#DIR_ORG_GOOGLE = DIR_ORG + DIR_SEPARATOR + "google"
DIR_ORG_GOOGLE = os.path.join(DIR_ORG, "google")
#DIR_ORG_DUCKDUCKGO = DIR_ORG + DIR_SEPARATOR + "duckduckgo"
DIR_ORG_DUCKDUCKGO = os.path.join(DIR_ORG, "duckduckgo")
#DIR_TFIDFVECTOR = DIR_CORPUS + "\\" + "tfidfvector"
#EXT_TFIDFVECTOR = "pickle"

EXT_PICKLE = "pickle"

DIR_TFIDF_WORDS = os.path.join(DIR_CORPUS, "tfidf_words")
DIR_TFIDF_LEMMATIZED = os.path.join(DIR_CORPUS, "tfidf_lemmatized")
DIR_TFIDF_NGRAMS = os.path.join(DIR_CORPUS, "tfidf_ngrams")
DIR_TFIDF_STEM_PORTER = os.path.join(DIR_CORPUS, "tfidf_stem_porter")
DIR_TFIDF_STEM_LANCASTER = os.path.join(DIR_CORPUS, "tfidf_stem_lancaster")
DIR_TFIDF_STEM_SNOWBALL = os.path.join(DIR_CORPUS, "tfidf_stem_snowball")
DIR_NER = os.path.join(DIR_CORPUS, "document_ner")
DIR_TFIDF_TOPICS = os.path.join(DIR_CORPUS, "tfidf_topics")
DIR_WORD_SET = os.path.join(DIR_CORPUS, "word_set")

DOC2VEC = "doc2vec"

DOCUMENTS_IN_CORPUS_FILE_PATH = "documentsInCorpusFilePath"
DOCUMENTS_IN_CORPUS_BASENAME = "documentsInCorpusBasename"

DEFAULT_CONTRACTIONS_FILENAME = "contractions.csv"
DEFAULT_ACRONYMS_FILENAME = "acronyms.csv"
DEFAULT_MISC_EXPANSIONS_FILENAME = "misc-expansions.csv"
DEFAULT_INCORRECT_ORGANIZATIONS_FILENAME = "incorrect-organizations.txt"
DEFAULT_PATH_DOCUMENT_LIST_TO_ADD_TO_CORPUS="document-list-add-to-corpus.txt"


KEY_NER_ORG = "ORGANIZATION"
KEY_NER_PERSON = "PERSON"
KEY_NER_LOCATION = "LOCATION"

#
# global variables
#

DEFAULT_ENCODING = "latin-1"
gEncoding = DEFAULT_ENCODING
DEFAULT_LANGUAGE = "english"
gLanguage = DEFAULT_LANGUAGE
gStopWords = stopwords.words(gLanguage) + list(punctuation)

gWords = common.tokens(open(os.path.join(DIR_SUPPORT, "big.txt")).read())

gWordCounts = collections.Counter(gWords)
gPorterStemmer = PorterStemmer()
gLancasterStemmer = LancasterStemmer()

gSnowballStemmer = SnowballStemmer(gLanguage)
#gSnowballStemmer = SnowballStemmer("german")

gWordnetLemmatizer = WordNetLemmatizer()
gCustomStopwords = []
gContractionMap = dict()
gAcronymMap = dict()
gMiscExpansionsMap = dict()
gDocumentsForClustering = []
gIncorrectOrgSet = set()
gNERToDocumentMap = dict()
gDocDocWordSimilarityMap = dict()
gDocDocPorterStemmedWordSimilarityMap = dict()
gDocDocLemmatizedWordSimilarityMap = dict()
gDocDocTopicSimilarityMap = dict()
gDocDocNGramSimilarityMap = dict()
gDocumentToKMeansClusterMap = dict()

CREATION_MODE_UPDATE = "Update"
CREATION_MODE_APPEND = "Append"
CREATION_MODE_FROM_LIST = "FromList"
gCreationListFilePath = "creationList.txt"

gCreationMode = CREATION_MODE_APPEND

DEFAULT_TOPIC_CREATION = True
gTopicCreation = DEFAULT_TOPIC_CREATION

DEFAULT_NER_IDENTIFICATION = True
gNERIdentification = DEFAULT_NER_IDENTIFICATION

DEFAULT_NER_ORG_DOWNLOAD = True
gNEROrgDownload = DEFAULT_NER_ORG_DOWNLOAD

DEFAULT_NER_INCORRECT_ORG_IDENTIFICATION = True
gNERIncorrectOrgIdentification = DEFAULT_NER_INCORRECT_ORG_IDENTIFICATION

DEFAULT_USE_THREADING = False
gUseThreading = DEFAULT_USE_THREADING

DEFAULT_NER_SKIP_INCORRECT_ORG_CHECK = False
gNERSkipIncorrectOrgCheck = DEFAULT_NER_SKIP_INCORRECT_ORG_CHECK

DEFAULT_KMEANS_CLUSTERING = True
gKMeansClustering = DEFAULT_KMEANS_CLUSTERING

DEFAULT_NGRAM_TFIDF = True
gNGramTfidf = DEFAULT_NGRAM_TFIDF

DEFAULT_LEMMATIZATION_TFIDF = True
gLemmatizationTfidf = DEFAULT_LEMMATIZATION_TFIDF

DEFAULT_BASIC_TFIDF = True
gBasicTfidf = DEFAULT_BASIC_TFIDF

DEFAULT_WORDSET_TFIDF = True
gWordSetTfidf = DEFAULT_WORDSET_TFIDF

DEFAULT_PORTER_STEMMING_TFIDF = True
gPorterStemmingTfidf = DEFAULT_PORTER_STEMMING_TFIDF

DEFAULT_LANCASTER_STEMMING_TFIDF = True
gLancasterStemmingTfidf = DEFAULT_LANCASTER_STEMMING_TFIDF

DEFAULT_SNOWBALL_STEMMING_TFIDF = True
gSnowballStemmingTfidf = DEFAULT_SNOWBALL_STEMMING_TFIDF

DEFAULT_NAME_NER_TO_DOCUMENT_MAP_FILE="ner-to-document-map.pickle"
gNERToDocumentMapFilepath = DEFAULT_NAME_NER_TO_DOCUMENT_MAP_FILE

DEFAULT_KMEANS_NUM_CLUSTERS = 5
gNumKMeansNumClusters = DEFAULT_KMEANS_NUM_CLUSTERS

DEFAULT_FIND_TOPICS_FOR_ALL_DOCUMENTS = True
gFindTopicsForAllDocuments = DEFAULT_FIND_TOPICS_FOR_ALL_DOCUMENTS

DEFAULT_GENERATE_DOC_DOC_SIMILARITY_MAPS = True
gGenerateDocDocSimilarityMaps = DEFAULT_GENERATE_DOC_DOC_SIMILARITY_MAPS

DEFAULT_GENERATE_DOC2VEC_MODEL = True
gGenerateDoc2VecModel = DEFAULT_GENERATE_DOC2VEC_MODEL

DEFAULT_GENERATE_TEXT_CLASSIFY_MODEL = True
gGenerateTextClassifyModel = DEFAULT_GENERATE_TEXT_CLASSIFY_MODEL

DEFAULT_KMEANS_NUM_ITERATIONS = 100
gNumKMeansNumIterations = DEFAULT_KMEANS_NUM_ITERATIONS

DEFAULT_NUM_TOPICS = 5
gNumTopics = DEFAULT_NUM_TOPICS

DEFAULT_NUM_PASSES = 20
gNumPasses = DEFAULT_NUM_PASSES

DEFAULT_NUM_WORDS = 10
gNumWords = DEFAULT_NUM_WORDS

DEFAULT_CORPUS_CREATION_FLAG = True
gCorpusCreationFlag = DEFAULT_CORPUS_CREATION_FLAG

DEFAULT_SEARCH_FLAG = True
gSearchFlag = DEFAULT_SEARCH_FLAG

gDocumentsInCorpusFilePath = []
gDocumentsIncorpusBasename = []
gDocumenListAddToCorpus = os.path.join(DIR_SUPPORT, DEFAULT_PATH_DOCUMENT_LIST_TO_ADD_TO_CORPUS)
gBasenameToActualFilenameMap = dict()

DEFAULT_NUM_RESULTS = 5
gNumResults = DEFAULT_NUM_RESULTS

DEFAULT_FIND_RELATED_DOCUMENTS = True
gFindRelatedDocuments = DEFAULT_FIND_RELATED_DOCUMENTS

DEFAULT_NUM_RELATED_DOCUMENTS = 3
gNumRelatedDocuments = DEFAULT_NUM_RELATED_DOCUMENTS

DEFAULT_FIND_DOCUMENTS_FROM_SAME_CLUSTER = True
gFindDocumentsFromSameCluster = DEFAULT_FIND_DOCUMENTS_FROM_SAME_CLUSTER

DEFAULT_FIND_DOCUMENTS_FROM_SAME_CLUSTER = True
gFindDocumentsFromSameCluster = DEFAULT_FIND_DOCUMENTS_FROM_SAME_CLUSTER

DEFAULT_NUM_DOCUMENTS_FROM_SAME_CLUSTER = 3
gNumDocumentsFromSameCluster = DEFAULT_NUM_DOCUMENTS_FROM_SAME_CLUSTER

DEFAULT_FIND_DOCUMENTS_WITH_SAME_PERSON = True
gFindDocumentsWithSamePerson = DEFAULT_FIND_DOCUMENTS_WITH_SAME_PERSON

DEFAULT_NUM_DOCUMENTS_WITH_SAME_PERSON = 3
gNumDocumentsWithSamePerson = DEFAULT_NUM_DOCUMENTS_WITH_SAME_PERSON

DEFAULT_FIND_DOCUMENTS_WITH_SAME_LOCATION = True
gFindDocumentsWithSameLocation = DEFAULT_FIND_DOCUMENTS_WITH_SAME_LOCATION

DEFAULT_NUM_DOCUMENTS_WITH_SAME_LOCATION = 3
gNumDocumentsWithSameLocation = DEFAULT_NUM_DOCUMENTS_WITH_SAME_LOCATION

DEFAULT_WEIGHT_SIMILARITY_WORD = 0.40
gSimilarityWeightWord = DEFAULT_WEIGHT_SIMILARITY_WORD
DEFAULT_WEIGHT_SIMILARITY_STEMMED_WORD = 0.30
gSimilarityWeightStemmedWord = DEFAULT_WEIGHT_SIMILARITY_STEMMED_WORD
DEFAULT_WEIGHT_SIMILARITY_LEMMATIZED_WORD = 0.30
gSimilarityWeightLemmatizedWord =  DEFAULT_WEIGHT_SIMILARITY_LEMMATIZED_WORD
DEFAULT_WEIGHT_SIMILARITY_TOPICS = 0.0
gSimilarityWeightTopics = DEFAULT_WEIGHT_SIMILARITY_TOPICS
DEFAULT_WEIGHT_SIMILARITY_NER = 0.0
gSimilarityWeightNER = DEFAULT_WEIGHT_SIMILARITY_NER
DEFAULT_WEIGHT_SIMILARITY_NGRAMS = 0.0
gSimilarityWeightNGrams = DEFAULT_WEIGHT_SIMILARITY_NGRAMS

DEFAULT_WEIGHT_SIMILARITY_SET = 0.4
gSimilarityWeightSet = DEFAULT_WEIGHT_SIMILARITY_SET
DEFAULT_WEIGHT_SIMILARITY_DOC2VEC = 0.2
gSimilarityWeightDoc2Vec = DEFAULT_WEIGHT_SIMILARITY_DOC2VEC
DEFAULT_WEIGHT_SIMILARITY_TFIDF = 0.2
gSimilarityWeightTFIDF = DEFAULT_WEIGHT_SIMILARITY_TFIDF
DEFAULT_WEIGHT_SIMILARITY_TEXT_CLASSIFY = 0.2
gSimilarityWeightTextClassify = DEFAULT_WEIGHT_SIMILARITY_TEXT_CLASSIFY

#
# end
#
