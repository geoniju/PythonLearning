"""
Data Science Challenge 4 - Search engine for sales team

Group Name:
	RecoBuilder

Authors:
	1. Bipin Patwardhan, bipin.patwardhan@capgemini.com
	2. Suvarna Fernandes, suvarna.fernandes@capgemini.com
	3. Geo Shanth, geo.shanth@capgemini.com
	4. Philippe Roudil, philippe.roudil@sogeti.com

File:
	createCorpus.py

Description:
	TO BE ADDED
"""

import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import pandas as pd
import sys
import os
import codecs
import pickle
import csv
import chardet

import rbGlobals
import common
import commonFile
import commonLogger
import commonSimilarity
import commonTopics
import commonNER
import ngrams
import topicModelerFile
import kmeansPredict
from stanfordNERCoreNLP import *

def updateDocumentList(input_dir):
	gDocumentsInCorpusBasename = []
	gDocumentsInCorpusFilePath = []
	
	# read each file in the input directory and add it to the corpus
	for file in os.listdir(input_dir):
		bFileAdded = False
		
		file_path = os.path.join(input_dir, file)
		if os.path.isdir(file_path):
			continue
		
		try:
			print("including '" + file_path + "'")
			gDocumentsInCorpusFilePath.append(file)
			gDocumentsInCorpusBasename.append(os.path.splitext(file)[0])
		except FileNotFoundError:
			commonLogger.error("Error processing file " + file_path)
	# end for
	
	pickle.dump(gDocumentsInCorpusFilePath, open("corpus/documentsInCorpusFilePath.pickle", "wb"))
	pickle.dump(gDocumentsInCorpusBasename, open("corpus/documentsInCorpusBasename.pickle", "wb"))
	
#end updateDocumentList

updateDocumentList("input")

#
# end of createCorpus.py
#
