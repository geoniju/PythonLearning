"""
Data Science Challenge 4 - Search engine for sales team

Group Name:
	RecoBuilder

Authors:
	1. Bipin Patwardhan, bipin.patwardhan@capgemini.com
	2. Suvarna Fernandes, suvarna.fernandes@capgemini.com
	3. Geo Shanth, geo.shanth@capgemini.com
	4. Philippe Roudil, philippe.roudil@service.capgemini.com
	
File:
	commonFile.py

Description:
	commonly used file related operations
"""

import os
import pickle
import string
import sys
import csv

import rbGlobals
import common

def getWordSetFilePath(docName):
	return os.path.join(rbGlobals.DIR_WORD_SET, docName + "." + rbGlobals.EXT_PICKLE)

def getWordFilePath(docName):
	return os.path.join(rbGlobals.DIR_TFIDF_WORDS, docName + "." + rbGlobals.EXT_PICKLE)

def getLemmatizedWordFilePath(docName):
	return os.path.join(rbGlobals.DIR_TFIDF_LEMMATIZED, docName + "." + rbGlobals.EXT_PICKLE)

def getStemmerPorterWordFilePath(docName):
	return os.path.join(rbGlobals.DIR_TFIDF_STEM_PORTER, docName + "." + rbGlobals.EXT_PICKLE)

def getStemmerLancasterWordFilePath(docName):
	return os.path.join(rbGlobals.DIR_TFIDF_STEM_LANCASTER, docName + "." + rbGlobals.EXT_PICKLE)

def getStemmerSnowballWordFilePath(docName):
	return os.path.join(rbGlobals.DIR_TFIDF_STEM_SNOWBALL, docName + "." + rbGlobals.EXT_PICKLE)

def getNGramsFilePath(docName):
	return os.path.join(rbGlobals.DIR_TFIDF_NGRAMS, docName + "." + rbGlobals.EXT_PICKLE)

def getTopicsFilePath(docName):
	return os.path.join(rbGlobals.DIR_TFIDF_TOPICS, docName + "." + rbGlobals.EXT_PICKLE)

def getNERFilePath(docName):
	return os.path.join(rbGlobals.DIR_NER, docName + "." + rbGlobals.EXT_PICKLE)

def getWikipediaFilePath(org):
	return os.path.join(rbGlobals.DIR_ORG_WIKIPEDIA, org + "." + rbGlobals.EXT_PICKLE)

def getTopicsAllDocumentsFilePath():
	return os.path.join(rbGlobals.DIR_CORPUS, "topics-set-all-documents." + rbGlobals.EXT_PICKLE)

def getVectorizedTopicsAllDocumentsFilePath():
	return os.path.join(rbGlobals.DIR_CORPUS, "topics-set-all-documents-vectorized." + rbGlobals.EXT_PICKLE)

def getDocumentsInCorpusFilePath():
	return os.path.join(rbGlobals.DIR_CORPUS, rbGlobals.DOCUMENTS_IN_CORPUS_FILE_PATH + "." + rbGlobals.EXT_PICKLE)

def getDocumentsInCorpusBasenameFilePath():
	return os.path.join(rbGlobals.DIR_CORPUS, rbGlobals.DOCUMENTS_IN_CORPUS_BASENAME + "." + rbGlobals.EXT_PICKLE)

def getDocDocWordSimilarityFilePath():
	return os.path.join(rbGlobals.DIR_CORPUS, "doc-doc-word-similarity." + rbGlobals.EXT_PICKLE)

def getDocDocPorterStemmedWordSimilarityFilePath():
	return os.path.join(rbGlobals.DIR_CORPUS, "doc-doc-porter-stem-word-similarity." + rbGlobals.EXT_PICKLE)

def getDocDocLemmatizedWordSimilarityFilePath():
	return os.path.join(rbGlobals.DIR_CORPUS, "doc-doc-lemmatized-word-similarity." + rbGlobals.EXT_PICKLE)

def getDocDocTopicSimilarityFilePath():
	return os.path.join(rbGlobals.DIR_CORPUS, "doc-doc-topic-similarity." + rbGlobals.EXT_PICKLE)

def getDocDocNGramSimilarityFilePath():
	return os.path.join(rbGlobals.DIR_CORPUS, "doc-doc-ngram-similarity." + rbGlobals.EXT_PICKLE)

def getNERToDocumentMapFilePath():
	return os.path.join(rbGlobals.DIR_CORPUS, rbGlobals.gNERToDocumentMapFilepath)

def getKMeansModelFilePath():
	return os.path.join(rbGlobals.DIR_CORPUS, "kmeans_model." + rbGlobals.EXT_PICKLE)

def getKMeansVectorizerFilePath():
	return os.path.join(rbGlobals.DIR_CORPUS, "kmeans_vectorizer." + rbGlobals.EXT_PICKLE)

def getDocumentToKMeansClusterFilePath():
	return os.path.join(rbGlobals.DIR_CORPUS, "document-to-kmeans-cluster-map." + rbGlobals.EXT_PICKLE)

def getBasename(fpath):
	#print("fpath ", fpath)
	#print("splittext ", os.path.splitext(fpath)[0])
	#print("basename ", os.path.basename(fpath))
	#print("basename.split ", os.path.basename(fpath).split(".")[0])
	return os.path.basename(fpath).split(".")[0]

def readFileRaw(fname, encode="latin-1"):
	return open(fname, encoding=encode).read()
#end readFileRaw

def readFileAndTokenize(fname):
	raw = open(fname).read()
	tokens = word_tokenize(raw)
	return tokens
#end readFileAndTokenize

def readFileAsLines(fname):
	f = open(fname, 'r')
	x = f.readlines()
	return x
#end readFileAsLines

# You can always safely read in binary mode and decode it in utf8 with ignore mode.
def readFileBinaryModeIgnoreUTF8(filename):
	with open(filename, 'rb') as f:
		lines = [l.decode('utf8', 'ignore') for l in f.readlines()]
	return lines
#end readFileBinaryModeIgnoreUTF8

def readFileIgnoreUTF8(filename):
	with open(filename, 'r') as f:
		lines = [l.decode('utf8', 'ignore') for l in f.readlines()]
	return lines
#end readFileIgnoreUTF8

def readFileIntoList(filename):
	with open(filename, "r") as f:
		lines = f.read().splitlines()
	return lines
#end readFileIntoList

def readFileIntoListPythonic1(filename):
	#Sample 1 - elucidating each step but not memory efficient
	lines = []
	with open(filename) as file:
		for line in file:
			line = line.strip() #or some other preprocessing
			lines.append(line) #storing everything in memory!
	return lines
#end readFileIntoListPythonic1

def readFileIntoListPythonic2(filename):
	#Sample 2 - a more pythonic and idiomatic way but still not memory efficient
	with open(filename) as file:
		lines = [line.strip() for line in file]
	return lines
#end readFileIntoListPythonic2

def readFileIntoListPythonic3(filename):
	#Sample 3 - a more pythonic way with efficient memory usage. Proper usage of with and file iterators. 
	with open("C:\name\MyDocuments\numbers") as file:
		for line in file:
			line = line.strip() #preprocess line
			#doSomethingWithThisLine(line) #take action on line instead of storing in a list. more memory efficient at the cost of execution speed
#end readFileIntoListPythonic3

def readFileIntoListOneLine(filepath):
	data = [line.strip() for line in open(filepath, 'r')]
	return data
#end readFileIntoListOneLine

def readFileIntoSetOneLine(filepath):
	list = readFileIntoList(filepath)
	fileSet = set()
	for l in list:
		fileSet.add(l)
	return fileSet
#end readFileIntoSetOneLine

def loadContractions(filename):
	reader = csv.reader(open(filename, 'r'))
	cDict = {}
	for row in reader:
		k, v = row
		cDict[k] = v
	
	return cDict
#end loadContractions

def loadAcronyms(filename):
	reader = csv.reader(open(filename, 'r'))
	aDict = {}
	for row in reader:
		k, v = row
		aDict[k] = v
	
	return aDict
#end loadAcronyms

def loadMiscExpansions(filename):
	reader = csv.reader(open(filename, 'r'))
	meDict = {}
	for row in reader:
		k, v = row
		meDict[k] = v
	
	return meDict
#end loadMiscExpansions

def loadIncorrectOrganizationSet(fname):
	list = readFileIntoList(fname)
	orgSet = set()
	for l in list:
		orgSet.add(l)
	return orgSet
#end loadIncorrectOrganizationSet

def saveNERMapForFile(fpath, nerMap):
	pickle.dump(nerMap, open(fpath, "wb"))
#end saveNERMapForFile

def loadNERMapForFile(fpath):
	nerMap = pickle.load(open(fpath, "rb"))
	return nerMap
#end loadNERMapForFile

def writePickle(fpath, data):
	pickle.dump(data, open(fpath, "wb"))
#end writePickle

def readPickle(fpath):
	try:
		data = pickle.load(open(fpath, "rb"))
	except FileNotFoundError:
		data = []
	return data
#end readPickle

def writeFile(fpath, data):
	f = open(fpath, "w")
	f.write(data)
	f.close()
#end writeFile

def checkFileExists(fname):
	if os.path.isfile(fname):
		return True
	return False
#end checkFileExists

def mapOrgNameToFilename(str):
	str = str.replace(":", "-").replace("\\", "-").replace("/", "-").replace("?", "-").replace("*", "-")
	return str


"""
# https://stackoverflow.com/questions/1698596/how-can-i-traverse-a-file-system-with-a-generator

import os
for root, dirs, files in os.walk(path):
    for name in files:
        print os.path.join(root, name)

def grab_files(directory):
    for name in os.listdir(directory):
        full_path = os.path.join(directory, name)
        if os.path.isdir(full_path):
            for entry in grab_files(full_path):
                yield entry
        elif os.path.isfile(full_path):
            yield full_path
        else:
            print('Unidentified name %s. It could be a symbolic link' % full_path)

Starting with Python 3.4, you can use the Pathlib module:
This is essential the object-oriented version of sjthebats answer. Note that the Path.glob ** pattern returns only directories!
-- by gerrit
def alliter(p):
   ....:     yield p
   ....:     for sub in p.iterdir():
   ....:         if sub.is_dir():
   ....:             yield from alliter(sub)
   ....:         else:
   ....:             yield sub
   ....:             

In [49]: g = alliter(pathlib.Path("."))                                                                                                                                                              

In [50]: [next(g) for _ in range(10)]
Out[50]: 
[PosixPath('.'),
 PosixPath('.pypirc'),
 PosixPath('.python_history'),
 PosixPath('lshw'),
 PosixPath('.gstreamer-0.10'),
 PosixPath('.gstreamer-0.10/registry.x86_64.bin'),
 PosixPath('.gconf'),
 PosixPath('.gconf/apps'),
 PosixPath('.gconf/apps/gnome-terminal'),
 PosixPath('.gconf/apps/gnome-terminal/%gconf.xml')]

--by yota
from pathlib import Path

def walk(pth=Path('.'), pattern='*', only_file=True) :
    # list all files in pth matching a given pattern, can also list dirs if only_file is False
    if pth.match(pattern) and not (only_file and pth.is_dir()) :
        yield pth
    for sub in pth.iterdir():
        if sub.is_dir():
            yield from walk(sub, pattern, only_file)
        else:
            if sub.match(pattern) :
                yield sub
"""

#
# end of commonFile.py
#
