"""
Data Science Challenge 4 - Search engine for sales team

Group Name:
	RecoBuilder

Authors:
	1. Bipin Patwardhan, bipin.patwardhan@capgemini.com
	2. Suvarna Fernandes, suvarna.fernandes@capgemini.com
	3. Geo Shanth, geo.shanth@capgemini.com
	4. Philippe Roudil, philippe.roudil@service.capgemini.com
	
File:
	commonNER.py

Description:
	Common functions related to NER
"""

import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

import operator
import os
from collections import OrderedDict
import math
import string
from string import punctuation
import unicodedata
from bs4 import BeautifulSoup
import requests
import pickle
import sys
import csv
import chardet
import codecs
import re, collections
from autocorrect import spell
import nltk
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk.collocations import BigramCollocationFinder
from nltk.metrics import BigramAssocMeasures
from nltk.stem.porter import PorterStemmer
from nltk.stem import LancasterStemmer
from nltk.stem import SnowballStemmer
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer

import rbGlobals
import common
import commonFile
import commonLogger
from kmeansPredict import *
import stanfordNERCoreNLP

def fetchAndSaveOrganizationWebPage(nerMap, orgSet):
	commonLogger.detail("fetchAndSaveOrganizationWebPage start")
	
	orgs = nerMap.get(rbGlobals.KEY_NER_ORG, None)
	try:
		for org in orgs:
			if org in orgSet:
				commonLogger.warning("###### '" + org + "' is not a valid organization. skipping it")
			else:
				commonLogger.debug("fetching page for " + org)
				orgDisk = commonFile.mapOrgNameToFilename(org)
				fname = os.path.join(rbGlobals.DIR_ORG_WIKIPEDIA, orgDisk + "." + rbGlobals.EXT_PICKLE)
				if os.path.isfile(fname):
					continue
				
				pageText = fetchPageFromWikipedia(org)
				if pageText != "PAGE_NOT_FOUND":
					commonLogger.debug("saving page text to pickle")
					try:
						commonFile.writePickle(fname, pageText)
					except OSError:
						commonLogger.error("error saving org data file: " + org)
	except KeyError:
		pass
	commonLogger.detail("fetchAndSaveOrganizationWebPage end")
#end fetchAndSaveOrganizationWebPage

def performNERAllDocuments(input_dir, output_dir):
	commonLogger.detail("performNERAllDocuments start")
	
	commonLogger.debug("Performing NER on document in " + input_dir)
	
	for file in os.listdir(input_dir):
		file_path = os.path.join(input_dir, file)
		if os.path.isfile(file_path):
			commonLogger.detail("ner on file: " + file_path)
			fh = codecs.open(file_path, "r")
			text = fh.read()
			fh.close()
			
			taggedElementMap = stanfordNERCoreNLP.tagTheText(text)
			saveNERMapForFile(os.path.splitext(file)[0], taggedElementMap)
	
	commonLogger.detail("performNERAllDocuments end")
#end performNER

def performNEROnDocument(fname):
	commonLogger.detail("performNEROnDocument start")
	
	commonLogger.debug("Performing NER on " + fname)
	
	fh = codecs.open(fname, "r")
	text = fh.read()
	fh.close()
	
	taggedElementMap = stanfordNERCoreNLP.tagTheText(text)
	
	commonLogger.detail("performNEROnDocument end")
	return taggedElementMap
#end performNEROnDocument

def performNEROnText(text):
	commonLogger.detail("performNEROnText start")
	
	commonLogger.detail("Performing NER on " + text)
	
	taggedElementMap = stanfordNERCoreNLP.tagTheText(text)
	
	commonLogger.detail("performNEROnText end")
	return taggedElementMap
#end performNEROnText

def checkInvalidPage(text):
	invalidPageIndicators = [ "Wiktionary", " does not exist"]
#end checkInvalidPage

def fetchPageFromWikipedia(org):
	commonLogger.detail("fetchPageFromWikipedia start")
	
	sorg = org.replace(" ", "+")
	#r  = requests.get("https://www.wikipedia.org/wiki/" + sorg)
	r  = requests.get("https://www.wikipedia.org/search-redirect.php?family=wikipedia&language=en&search=" + org)
	soup = BeautifulSoup(r.text, 'html.parser')
	text = soup.get_text()
	
	#print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
	#print(text)
	#print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
	testString = org + " may mean:"
	#print(testString)
	if text.find(testString) != -1:
		# means we have reached disambiguation page on wikipedia
		div = soup.find_all('div', class_='mw-content-ltr')
		#print(div[0].get_text())
		links = div[0].find_all('a', class_='mw-redirect')
		#print(links[0].get_text() + ", " + links[0].attrs['title'] + ", " + links[0].attrs['href'])
		pageLink = links[0].attrs['href']
		
		# fetch the page contents
		r  = requests.get("https://www.wikipedia.org/" + pageLink)
		soup = BeautifulSoup(r.text, 'html.parser')
		pageText = soup.get_text()
	else:
		pageText = text
	
	checkString = 'The page "' + org + '" does not exist'
	if pageText.find(checkString) != -1:
		pageText = "PAGE_NOT_FOUND"
	
	#print("*******************************************")
	#print(pageText)
	#print("*******************************************")
	
	commonLogger.detail("fetchPageFromWikipedia end")
	
	return pageText
#end fetchPageFromWikipedia

def fetchPageFromGoogle(org):
	commonLogger.detail("fetchPageFromGoogle start")
	
	sorg = org.replace(" ", "+")
	r  = requests.get("http://www.google.com/search?q=" + sorg, verify=False)
	soup = BeautifulSoup(r.text, 'html.parser')
	text = soup.get_text()
	
	#print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
	#print(text)
	#print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
	div = soup.find_all('div', class_='_Nid')
	#print(div[0].get_text())
	h3 = div[0].find_all('h3', class_='r')
	links = h3[0].find_all('a')
	pageLink = links[0].attrs['href']
	print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
	print(pageLink)
	print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
	r  = requests.get(pageLink)
	soup = BeautifulSoup(r.text, 'html.parser')
	pageText = soup.get_text()
	print("*******************************************")
	print(pageText)
	print("*******************************************")
	
	commonLogger.detail("fetchPageFromGoogle end")
	return pageText
#end fetchPageFromGoogle

def fetchPageFromDuckDuckGo(org):
	commonLogger.detail("fetchPageFromDuckDuckGo start")
	
	sorg = org.replace(" ", "+")
	r  = requests.get("https://duckduckgo.com/?q=" + sorg + "&ia=news", verify=False)
	soup = BeautifulSoup(r.text, 'html.parser')
	text = soup.get_text()
	
	#print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
	#print(text)
	#print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
	
	div = soup.find_all('div', class_='module_title')
	#print(div[0].get_text())
	links = div[0].find_all('a')
	pageLink = links[0].attrs['href']
	print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
	print(pageLink)
	print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
	titleText = links[0].attrs['title']
	print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
	print(titleText)
	print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
	innerText = links[0].get_text()
	print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
	print(innerText)
	print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
	r  = requests.get(pageLink)
	soup = BeautifulSoup(r.text, 'html.parser')
	pageText = soup.get_text()
	print("*******************************************")
	print(pageText)
	print("*******************************************")
	
	commonLogger.detail("fetchPageFromDuckDuckGo end")
	return pageText
#end fetchPageFromDuckDuckGo

def generateNERToDocumentMapping():
	commonLogger.detail("generateNERToDocumentMapping start")
	
	try:
		rbGlobals.gNERToDocumentMap = commonFile.readPickle(commonFile.getNERToDocumentMapFilePath())
		
		if len(rbGlobals.gNERToDocumentMap) == 0:
			rbGlobals.gNERToDocumentMap = dict()
		
		try:
			for fname in rbGlobals.gDocumentsInCorpusBasename:
				commonLogger.debug("Checking NER similarity for " + fname)
				ner = commonFile.readPickle(commonFile.getNERFilePath(fname))
				documentOrgs = ner[rbGlobals.KEY_NER_ORG]
				for org in documentOrgs:
					if org not in rbGlobals.gNERToDocumentMap.keys():
						rbGlobals.gNERToDocumentMap[org] = []
					rbGlobals.gNERToDocumentMap[org].append(fname)
		except KeyError:
			pass
		
		commonFile.writePickle(commonFile.getNERToDocumentMapFilePath(), rbGlobals.gNERToDocumentMap)
	except FileNotFoundError:
		rbGlobals.gNERToDocumentMap = dict()
	
	commonLogger.detail("generateNERToDocumentMapping end")
#end generateNERToDocumentMap

#
# end of commonNER.py
#
