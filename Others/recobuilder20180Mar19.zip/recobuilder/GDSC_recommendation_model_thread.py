"""
Data Science Challenge 4 - Search engine for sales team

Group Name:
	RecoBuilder

Authors:
	1. Bipin Patwardhan, bipin.patwardhan@capgemini.com
	2. Suvarna Fernandes, suvarna.fernandes@capgemini.com
	3. Geo Shanth, geo.shanth@capgemini.com
	4. Philippe Roudil, philippe.roudil@sogeti.com

File:
	GDSC_recommendation_model.py

Description:
	TO BE ADDED
"""

import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

from configparser import ConfigParser
from configparser import NoOptionError
import string
import math
from string import punctuation
import sys
import os
from os.path import basename
import codecs
import pickle
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from bs4 import BeautifulSoup
import requests
import csv
import chardet
import threading

import rbGlobals
import common
import commonFile
from ngrams import *
import topicModelerFile
import kmeansPredict
import createCorpus
import stanfordNERCoreNLP
import CommonConfig
import commonLogger
import commonSimilarity
import commonTopics
import commonNER
import doc2vec_v2
import textClassify

#import misc_gen_word_set_corpus_documents

def getSimilarityResultsForSearchString(groupBy, searchStr):
	commonLogger.detail("getSimilarityResultsForSearchString start")
	similarityResults = dict()
	for k, gp in groupBy:
		#commonLogger.debug('key=' + str(k))
		vector = commonFile.readPickle(commonFile.getWordFilePath(str(k)))
		similarity = commonSimilarity.findSimilarityDocumentVectorAndString(str(k), vector, searchStr)
		similarityResults[str(k)] = similarity
	commonLogger.detail("getSimilarityResultsForSearchString end")
	return similarityResults
#end getSimilarityResultsForSearchString

def getSimilarityResultsForSearchStringWithNERobject(groupBy, searchStr):
	commonLogger.detail("getSimilarityResultsForSearchStringWithNERobject start")
	similarityResults = dict()
	for docName in rbGlobals.gDocumentsInCorpusBasename:
		commonLogger.debug("Checking NER similarity for " + docName)
		ner = commonFile.readPickle(commonFile.getNERFilePath(docName))
		documentOrgs = ner[rbGlobals.KEY_NER_ORG]
		print("documentOrgs = ", documentOrgs)
		for org in documentOrgs:
			#commonLogger.debug("ner object: " + org)
			if org in rbGlobals.gIncorrectOrgSet:
				#commonLogger.detail("ner object is not a correct org")
				continue
			orgPath = commonFile.mapOrgNameToFilename(org)
			filePath = commonFile.getWikipediaFilePath(orgNew)
			commonLogger.debug("ner object path "  + filePath)
			if commonFile.checkFileExists(filePath) == False:
				commonLogger.warning("NER OBJECT FILE FOR " + org + " SHOULD BE PRESENT BUT IS NOT PRESENT. CORPUS NEEDS TO BE UPDATED")
				continue
		
			pageText = commonFile.readPickle(filePath)
			words = common.basicTextProcessingNERDocument(pageText, rbGlobals.gStopWords, rbGlobals.gContractionMap, rbGlobals.gAcronymMap, rbGlobals.gMiscExpansionsMap, rbGlobals.gIncorrectOrgSet)
			#vector = commonSimilarity.vectorizeAndFitTransform(common.makeStringFromList(words, " "))
			vector = commonSimilarity.vectorizeAndFitTransform(" ".join(words))
			
			sim = commonSimilarity.findSimilarityDocumentVectorAndString(org, vector, searchStr)
			
			if docName not in similarityResults.keys():
				similarityResults[docName] = dict()
			
			similarityResults[docName][org] = sim
			#commonLogger.debug("Similarity of '" + common.stringFromTokens(searchWords, " ") + "' + with '" + org + "' is " + str(sim))
	commonLogger.detail("getSimilarityResultsForSearchStringWithNERobject end")
	return similarityResults
#end getSimilarityResultsForSearchStringWithNERobject

def getSimilarityResultsForSearchStringWithOtherDocumentsUsingNERobject(groupBy, searchStr):
	commonLogger.detail("getSimilarityResultsForSearchStringWithOtherDocumentsUsingNERobject start")
	similarityResults = dict()
	
	for docName in rbGlobals.gDocumentsInCorpusBasename:
		commonLogger.debug("finding NER objects for " + docName)
		ner = commonFile.readPickle(commonFile.getNETFilePath(docName))
		documentOrgs = ner[rbGlobals.KEY_NER_ORG]
		for org in documentOrgs:
			commonLogger.debug("ner object: " + org)
			if org in rbGlobals.gIncorrectOrgSet:
				#commonLogger.detail("ner object is not a correct org")
				continue
			wikiname = getWikipediaFilePath(org)
			commonLogger.debug("ner object "  + wikiname)
			if commonFile.checkFileExists(wikiname) == False:
				commonLogger.warning("NER OBJECT FILE FOR " + org + " SHOULD BE PRESENT BUT IS NOT PRESENT. CORPUS NEEDS TO BE UPDATED")
				continue
		
			pageText = commonFile.readPickle(wikiname)
			words = common.basicTextProcessingNERDocument(pageText, rbGlobals.gStopWords, rbGlobals.gContractionMap, rbGlobals.gAcronymMap, rbGlobals.gMiscExpansionsMap, rbGlobals.gIncorrectOrgSet)
			#vector = commonSimilarity.vectorizeAndFitTransform(common.makeStringFromList(words, " "))
			vector = commonSimilarity.vectorizeAndFitTransform(" ".join(words))
			sim = commonSimilarity.findSimilarityDocumentVectorAndString(org, vector, searchStr)
			commonLogger.debug("similarity of search string with text in " + org + "is " + str(sim))
			
			if sim > 0.25:
				nerToDocumentMapList = rbGlobals.gNERToDocumentMap[org]
				for docName in nerToDocumentMapList:
					commonLogger.debug("document from ner to document map: " + docName)
					documentWordsTFIDF = commonFile.readPickle(commonFile.getWordFilePath(docName))
					documentLemmatizedWordsTFIDF = commonFile.readPickle(commonFile.getLemmatizedWordFilePath(docName))
					documentTopicsTFIDF = commonFile.readPickle(commonFile.getTopicsFilePath(docName))
				
					simWords = commonSimilarity.findSimilarityDocumentVectorAndString(org, documentWordsTFIDF, searchStr)
					simLemmatized = commonSimilarity.findSimilarityDocumentVectorAndString(org, documentLemmatizedWordsTFIDF, searchStr)
					simTopics = commonSimilarity.findSimilarityDocumentVectorAndString(org, documentTopicsTFIDF, searchStr)
			
			similarityResults[docName][org] = sim
			#commonLogger.debug("Similarity of '" + common.stringFromTokens(searchWords, " ") + "' + with '" + org + "' is " + str(sim))
	commonLogger.detail("getSimilarityResultsForSearchStringWithNERobject end")
	return similarityResults
#end getSimilarityResultsForSearchStringWithOtherDocumentsUsingNERobject

def findSimilarityOfSearchStringWithWords(searchStr):
	similarityResults = dict()
	for docName in rbGlobals.gDocumentsInCorpusBasename:
		fname = commonFile.getWordFilePath(docName)
		if commonFile.checkFileExists(fname) == True:
			wordsTfidf = commonFile.readPickle(fname)
			similarity = commonSimilarity.findSimilarityDocumentVectorAndString(docName, wordsTfidf, searchStr)
			similarityResults[docName] = similarity
		else:
			#commonLogger.warning("TF-IDF vector for " + docName + " was not found in corpus. Setting similarity to 0.0")
			similarityResults[docName] = 0.0
	#print(similarityResults)
	
	return similarityResults
# end findSimilarityOfSearchStringWithWords

def findSetSimilarityOfDocumentWithSearchString(searchSet):
	similarityResults = dict()
	for docName in rbGlobals.gDocumentsInCorpusBasename:
		fname = os.path.join("corpus", "word_set", docName + ".pickle")
		if commonFile.checkFileExists(fname) == True:
			wordSet = commonFile.readPickle(fname)
			similarity = commonSimilarity.findSetSimilarity(wordSet, searchSet)
			similarityResults[docName] = similarity
		else:
			#commonLogger.warning("TF-IDF vector for " + docName + " was not found in corpus. Setting similarity to 0.0")
			similarityResults[docName] = 0.0
	
	return similarityResults
# end findSimilarityOfDocumentWithSearchString

def findSimilarityOfSearchStringWithPorterStemmedWords(searchWords):
	similarityResults = dict()
	searchStemmed = common.stemWordsPorter(searchWords)
	#searchStr = common.makeStringFromList(searchStemmed, " ")
	searchStr = " ".join(searchStemmed)
	for docName in rbGlobals.gDocumentsInCorpusBasename:
		fname = commonFile.getStemmerPorterWordFilePath(docName)
		if commonFile.checkFileExists(fname) == True:
			porterStemmedWordsTfidf = commonFile.readPickle(fname)
			similarity = commonSimilarity.findSimilarityDocumentVectorAndString(docName, porterStemmedWordsTfidf, searchStr)
			similarityResults[docName] = similarity
		else:
			#commonLogger.warning("TF-IDF vector for " + docName + " was not found in corpus. Setting similarity to 0.0")
			similarityResults[docName] = 0.0
	
	return similarityResults
# end findSimilarityOfSearchStringWithPorterStemmedWords

def findSimilarityOfSearchStringWithLemmatizedWords(searchStr):
	similarityResults = dict()
	for docName in rbGlobals.gDocumentsInCorpusBasename:
		fname = commonFile.getLemmatizedWordFilePath(docName)
		if commonFile.checkFileExists(fname) == True:
			lemmatizedWordsTfidf = commonFile.readPickle(fname)
			similarity = commonSimilarity.findSimilarityDocumentVectorAndString(docName, lemmatizedWordsTfidf, searchStr)
			similarityResults[docName] = similarity
		else:
			#commonLogger.warning("TF-IDF vector for " + docName + " was not found in corpus. Setting similarity to 0.0")
			similarityResults[docName] = 0.0
	
	return similarityResults
# end findSimilarityOfSearchStringWithLemmatizedWords

def findSimilarityOfSearchStringWithDocumentTopics(searchStr):
	similarityResults = dict()
	for docName in rbGlobals.gDocumentsInCorpusBasename:
		fname = commonFile.getTopicsFilePath(docName)
		#print("loading topics tfidf for ", fname)
		if commonFile.checkFileExists(fname) == True:
			topicsTfidf = commonFile.readPickle(fname)
			similarity = commonSimilarity.findSimilarityDocumentVectorAndString(docName, topicsTfidf, searchStr)
			#print("similarity is ", similarity)
			similarityResults[docName] = similarity
		else:
			#commonLogger.warning("TF-IDF vector for " + docName + " was not found in corpus. Setting similarity to 0.0")
			similarityResults[docName] = 0.0
	
	return similarityResults
# end findSimilarityOfSearchStringWithDocumentTopics

def findSimilarityOfSearchStringWithDocumentNER(searchStr):
	similarityResults = dict()
	count = 0
	for docName in rbGlobals.gDocumentsInCorpusBasename:
		similarityResults[docName] = dict()
		try:
			#print("docName: ", docName)
			nerPath = commonFile.getNERFilePath(docName)
			#print(nerPath)
			nerMap = commonFile.loadNERMapForFile(nerPath)
			#print(nerMap)
			orgs = nerMap[rbGlobals.KEY_NER_ORG]
			#print(orgs)
			for org in orgs:
				if org not in rbGlobals.gIncorrectOrgSet:
					#print("org: ", org)
					fpath = commonFile.getWikipediaFilePath(org)
					try:
						text = commonFile.readFileRaw(fpath, encode=rbGlobals.gEncoding)
						similarity = commonSimilarity.findSimilarityTwoStrings(text, searchStr)
						#print("similarity with ", org , " is ", similarity)
						similarityResults[docName][org] = similarity
					except FileNotFoundError:
						similarityResults[docName][org] = 0.0
		except KeyError:
			#print("org not found for %s" % docName)
			similarityResults[docName][org] = 0.0
	
	return similarityResults
# end findSimilarityOfSearchStringWithDocumentTopics

def findSimilarityOfSearchStringWithNGrams(searchStr):
	similarityResults = dict()
	for docName in rbGlobals.gDocumentsInCorpusBasename:
		fname = commonFile.getNGramsFilePath(docName)
		commonLogger.detail("loading ngrams tfidf for " + fname)
		if commonFile.checkFileExists(fname) == True:
			ngramsTfidf = commonFile.readPickle(fname)
			similarity = commonSimilarity.findSimilarityDocumentVectorAndString(docName, ngramsTfidf, searchStr)
			similarityResults[docName] = similarity
		else:
			similarityResults[docName] = 0.0
	
	return similarityResults
# end findSimilarityOfSearchStringWithNGrams

"""
def combineWordSimilarityAndLemmatizedWordSimilarity(similarityWithWords, similarityWithLemmatizedWords):
	commonLogger.detail("combineWordSimilarityAndLemmatizedWordSimilarity start")
	combined = dict()
	for k in similarityWithWords:
		sw = similarityWithWords[k]
		slw = similarityWithLemmatizedWords[k]
		sim = (sw * 0.5) + (slw * 0.5)
		combined[k] = sim
	
	commonLogger.detail("combineWordSimilarityAndLemmatizedWordSimilarity end")
	return combined
#end combineWordSimilarityAndLemmatizedWordSimilarity
"""

def displayDocumentsRelatedByWords(name):
	print("\tDocuments related by words")
	try:
		relatedDocBasedOnWord = rbGlobals.gDocDocWordSimilarityMap[name]
		reverseSortedrelatedDocBasedOnWord = common.sortDictionaryOnValueDescending(relatedDocBasedOnWord)
		#wordTopData = common.getTopDataSet(reverseSortedrelatedDocBasedOnWord, -1)
		wordTopData = common.getTopDataSet(reverseSortedrelatedDocBasedOnWord, 3)
		for wname, wvalue in wordTopData:
			print("\t\t" + wname + " - " + str(wvalue))
	except KeyError:
		print("\t\tError fetching documents related by words")
	
	print("\tDocuments related by lemmatized words")
	try:
		relatedDocBasedOnLemmatizedWord = rbGlobals.gDocDocLemmatizedWordSimilarityMap[name]
		reverseSortedrelatedDocBasedOnLemmatizedWord = common.sortDictionaryOnValueDescending(relatedDocBasedOnLemmatizedWord)
		#lemmatizedWordTopData = common.getTopDataSet(reverseSortedrelatedDocBasedOnLemmatizedWord, -1)
		lemmatizedWordTopData = common.getTopDataSet(reverseSortedrelatedDocBasedOnLemmatizedWord, 3)
		for lwname, lwvalue in lemmatizedWordTopData:
			print("\t\t" + lwname + " - " + str(lwvalue))
	except KeyError:
		print("\t\tError fetching documents related by lemmatized words")
		
	print("\tDocuments related by topic")
	try:
		relatedDocBasedOnTopic = rbGlobals.gDocDocTopicSimilarityMap[name]
		reverseSortedrelatedDocBasedOnTopic = common.sortDictionaryOnValueDescending(relatedDocBasedOnTopic)
		#topicTopData = common.getTopDataSet(reverseSortedrelatedDocBasedOnTopic, -1)
		topicTopData = common.getTopDataSet(reverseSortedrelatedDocBasedOnTopic, 3)
		for tname, tvalue in topicTopData:
			print("\t\t" + tname + " - " + str(tvalue))
	except KeyError:
		print("\t\tError fetching documents related by topics")
#end displayDocumentsRelatedByWords

def displayDocumentsRelatedByWordsCombined(name):
	try:
		combined = dict()
		relatedDocBasedOnWord = rbGlobals.gDocDocWordSimilarityMap[name]
		reverseSortedrelatedDocBasedOnWord = common.sortDictionaryOnValueDescending(relatedDocBasedOnWord)
		for name, value in reverseSortedrelatedDocBasedOnWord:
			try:
				combined[name] = value * 0.50
			except KeyError:
				combined[name] = 0
		
		"""
		porter stemming similarity can be added
		"""

		relatedDocBasedOnLemmatizedWord = rbGlobals.gDocDocLemmatizedWordSimilarityMap[name]
		reverseSortedrelatedDocBasedOnWord = common.sortDictionaryOnValueDescending(relatedDocBasedOnWord)
		for name, value in reverseSortedrelatedDocBasedOnWord:
			try:
				combined[name] = combined[name] + value * 0.50
			except KeyError:
				combined[name] = value * 0.50
		
		"""
		relatedDocBasedOnTopic = rbGlobals.gDocDocTopicSimilarityMap[name]
		reverseSortedrelatedDocBasedOnTopic = common.sortDictionaryOnValueDescending(relatedDocBasedOnTopic)
		for name, value in reverseSortedrelatedDocBasedOnTopic:
			try:
				#combined[name] = combined[name] + value * 0.20
				combined[name] = combined[name] + value * gSimilarityTopics
			except KeyError:
				#combined[name] = value * 0.20
				combined[name] = value * gSimilarityTopics
		"""
		
		"""
		ngram similarity can be added
		"""
		
		reverseSortedCombined = common.sortDictionaryOnValueDescending(combined)
		wordTopData = common.getTopDataSet(reverseSortedCombined, rbGlobals.gNumRelatedDocuments)
		for wname, wvalue in wordTopData:
			print("\t\t" + wname + " - " + str(wvalue))
	except KeyError:
		print("\t\tError fetching documents related by words")
#end displayDocumentsRelatedByWordsCombined

def getLocationsInNERDocument(name):
	locations = []
	try:
		nerPath = commonFile.getNERFilePath(name)
		nerMap = commonFile.loadNERMapForFile(nerPath)
		locations = nerMap[rbGlobals.KEY_NER_LOCATION]
	except KeyError:
		locations = []
	return locations
#end getLocationsInNERDocument

def displayDocumentsSharingTheSameLocation(name, numLocations):
	documentsWithSameLocation = []
	count = 0
	try:
		nerPath = commonFile.getNERFilePath(name)
		nerMap = commonFile.loadNERMapForFile(nerPath)
		mainLocations = nerMap[rbGlobals.KEY_NER_LOCATION]
		for loc in mainLocations:
			if count < numLocations:
				for subDoc in rbGlobals.gDocumentsInCorpusBasename:
					if subDoc!= name:
						subLocations = getLocationsInNERDocument(subDoc)
						for loc2 in subLocations:
							if loc == loc2:
								if count < numLocations:
									documentsWithSameLocation.append(subDoc)
									count = count + 1
								else:
									break
			else:
				break
	except KeyError:
		documentsWithSameLocation = []
	return documentsWithSameLocation
#end displayDocumentsSharingTheSameLocation

def getPersonsInNERDocument(name):
	persons = []
	try:
		nerPath = commonFile.getNERFilePath(name)
		nerMap = commonFile.loadNERMapForFile(nerPath)
		persons = nerMap[rbGlobals.KEY_NER_PERSON]
	except KeyError:
		persons = []
	return persons
#end getPersonsInNERDocument

def displayDocumentsSharingTheSamePeople(name, numPeople):
	documentsWithSamePeople = []
	count = 0
	try:
		nerPath = commonFile.getNERFilePath(name)
		nerMap = commonFile.loadNERMapForFile(nerPath)
		mainPersons = nerMap[rbGlobals.KEY_NER_PERSON]
		for per in mainPersons:
			if count < numPeople:
				for subDoc in rbGlobals.gDocumentsInCorpusBasename:
					if subDoc!= name:
						subPersons = getLocationsInNERDocument(subDoc)
						for per2 in subPersons:
							if per == per2:
								if count < numPeople:
									documentsWithSamePeople.append(subDoc)
									count = count + 1
								else:
									break;
			else:
				break
	except KeyError:
		documentsWithSamePeople = []
	return documentsWithSamePeople
#end displayDocumentsSharingTheSamePeople

def computeDoc2VecSimilarityForString(searchStr):
	fileNameList = pickle.load(open(os.path.join(rbGlobals.DIR_CORPUS, rbGlobals.DOC2VEC, "fileNameList.pickle"), "rb"))
	fileText = pickle.load(open(os.path.join(rbGlobals.DIR_CORPUS, rbGlobals.DOC2VEC, "fileText.pickle"), "rb"))
	word_set = pickle.load(open(os.path.join(rbGlobals.DIR_CORPUS, rbGlobals.DOC2VEC, "word_set.pickle"), "rb"))
	model = pickle.load(open(os.path.join(rbGlobals.DIR_CORPUS, rbGlobals.DOC2VEC, "model.pickle"), "rb"))
	
	tokens = searchStr.split()
	
	new_vector = model.infer_vector(tokens)
	sims = model.docvecs.most_similar([new_vector], topn=model.docvecs.count) #gives you top XXX document tags and their cosine similarity
	
	simDict = dict()
	for key, value in sims:
		simDict[key] = value
	
	return simDict
#end computeDoc2VecSimilarityForString

class ThreadSimilarityWithSet(threading.Thread):
	def __init__(self, documentsInCorpusBasename, similarityWithSet, searchSet):
		self.documentsInCorpusBasename = documentsInCorpusBasename
		self.similarityWithSet = similarityWithSet
		self.searchSet = searchSet
		super(ThreadSimilarityWithSet, self).__init__()
	
	def run(self):
		for docName in self.documentsInCorpusBasename:
			fnameSet = commonFile.getWordSetFilePath(docName)
			if commonFile.checkFileExists(fnameSet) == True:
				wordSet = commonFile.readPickle(fnameSet)
				similarity = commonSimilarity.findSetSimilarity(wordSet, self.searchSet)
				self.similarityWithSet[docName] = similarity
			else:
				self.similarityWithSet[docName] = 0.0
#end ThreadSimilarityWithSet

class ThreadSimilarityWithDoc2Vec(threading.Thread):
	def __init__(self, documentsInCorpusBasename, similarityWithDoc2Vec, doc2vecSimilarity):
		self.documentsInCorpusBasename = documentsInCorpusBasename
		self.similarityWithDoc2Vec = similarityWithDoc2Vec
		self.doc2vecSimilarity = doc2vecSimilarity
		super(ThreadSimilarityWithDoc2Vec, self).__init__()
	
	def run(self):
		for docName in self.documentsInCorpusBasename:
			if docName in self.doc2vecSimilarity:
				self.similarityWithDoc2Vec[docName] = self.doc2vecSimilarity[docName]
			else:
				self.similarityWithDoc2Vec[docName] = 0.0
#end ThreadSimilarityWithDoc2Vec

class ThreadSimilarityWithTextClassify(threading.Thread):
	def __init__(self, documentsInCorpusBasename, similarityWithTextClassify, searchStr):
		self.documentsInCorpusBasename = documentsInCorpusBasename
		self.similarityWithTextClassify = similarityWithTextClassify
		self.searchStr = searchStr
		super(ThreadSimilarityWithTextClassify, self).__init__()
	
	def run(self):
		for docName in self.documentsInCorpusBasename:
			try:
				self.similarityWithTextClassify[docName] = textClassify.search2(docName, self.searchStr)
			except KeyError:
				self.similarityWithTextClassify[docName] = 0.0
#end ThreadSimilarityWithTextClassify

class ThreadSimilarityWithWord(threading.Thread):
	def __init__(self, documentsInCorpusBasename, similarityWithWord, searchStr):
		self.documentsInCorpusBasename = documentsInCorpusBasename
		self.similarityWithWord = similarityWithWord
		self.searchStr = searchStr
		super(ThreadSimilarityWithWord, self).__init__()
	
	def run(self):
		for docName in self.documentsInCorpusBasename:
			# find similarity with words
			fnameWord = commonFile.getWordFilePath(docName)
			if commonFile.checkFileExists(fnameWord) == True:
				wordsTfidf = commonFile.readPickle(fnameWord)
				similarity = commonSimilarity.findSimilarityDocumentVectorAndString(docName, wordsTfidf, self.searchStr)
				self.similarityWithWord[docName] = similarity
			else:
				self.similarityWithWord[docName] = 0.0
#end ThreadSimilarityWithWord

class ThreadSimilarityWithPorterStemmedWord(threading.Thread):
	def __init__(self, documentsInCorpusBasename, similarityWithPorterStemmedWord, stemPorterSearchWords):
		self.documentsInCorpusBasename = documentsInCorpusBasename
		self.similarityWithPorterStemmedWord = similarityWithPorterStemmedWord
		self.stemPorterSearchWords = stemPorterSearchWords
		super(ThreadSimilarityWithPorterStemmedWord, self).__init__()
	
	def run(self):
		for docName in self.documentsInCorpusBasename:
			# get similarity for porter stemmed words
			fnamePorterStem = commonFile.getStemmerPorterWordFilePath(docName)
			if commonFile.checkFileExists(fnamePorterStem) == True:
				porterStemmedWordsTfidf = commonFile.readPickle(fnamePorterStem)
				porterStemSearchStr = " ".join(self.stemPorterSearchWords)
				similarity = commonSimilarity.findSimilarityDocumentVectorAndString(docName, porterStemmedWordsTfidf, porterStemSearchStr)
				self.similarityWithPorterStemmedWord[docName] = similarity
			else:
				self.similarityWithPorterStemmedWord[docName] = 0.0
#end ThreadSimilarityWithPorterStemmedWord

class ThreadSimilarityWithLemmatizedWord(threading.Thread):
	def __init__(self, documentsInCorpusBasename, similarityWithLemmatizedWord, lemmatizedSearchWords):
		self.documentsInCorpusBasename = documentsInCorpusBasename
		self.similarityWithLemmatizedWord = similarityWithLemmatizedWord
		self.lemmatizedSearchWords = lemmatizedSearchWords
		super(ThreadSimilarityWithLemmatizedWord, self).__init__()
	
	def run(self):
		for docName in self.documentsInCorpusBasename:
			# find similarity of search string with each document lemmatized words
			fnameLemmatized = commonFile.getLemmatizedWordFilePath(docName)
			if commonFile.checkFileExists(fnameLemmatized) == True:
				lemmatizedWordsTfidf = commonFile.readPickle(fnameLemmatized)
				#lemmatizedSearchStr = common.makeStringFromList(rbGlobals.lemmatizedSearchWords, " ")
				lemmatizedSearchStr = " ".join(self.lemmatizedSearchWords)
				similarity = commonSimilarity.findSimilarityDocumentVectorAndString(docName, lemmatizedWordsTfidf, lemmatizedSearchStr)
				self.similarityWithLemmatizedWord[docName] = similarity
			else:
				self.similarityWithLemmatizedWord[docName] = 0.0
#end ThreadSimilarityWithLemmatizedWord

class ThreadSimilarityWithTopic(threading.Thread):
	def __init__(self, documentsInCorpusBasename, similarityWithTopic, searchStr):
		self.documentsInCorpusBasename = documentsInCorpusBasename
		self. similarityWithTopic = similarityWithTopic
		self.searchStr = searchStr
		super(ThreadSimilarityWithTopic, self).__init__()
	
	def run(self):
		for docName in self.documentsInCorpusBasename:
			# find similarity of search string with topics in each document
			fnameTopics = commonFile.getTopicsFilePath(docName)
			if commonFile.checkFileExists(fnameTopics) == True:
				topicsTfidf = commonFile.readPickle(fnameTopics)
				similarity = commonSimilarity.findSimilarityDocumentVectorAndString(docName, topicsTfidf, self.searchStr)
				self.similarityWithTopic[docName] = similarity
			else:
				self.similarityWithTopic[docName] = 0.0
#end ThreadSimilarityWithTopic

class ThreadSimilarityWithNGrams(threading.Thread):
	def __init__(self, documentsInCorpusBasename, similarityWithNGrams, searchStr):
		self.documentsInCorpusBasename = documentsInCorpusBasename
		self.similarityWithNGrams = similarityWithNGrams
		self.searchStr = searchStr
		super(ThreadSimilarityWithNGrams, self).__init__()
	
	def run(self):
		for docName in self.documentsInCorpusBasename:
			fnameNGrams = commonFile.getNGramsFilePath(docName)
			if commonFile.checkFileExists(fnameNGrams) == True:
				ngramsTfidf = commonFile.readPickle(fnameNGrams)
				similarity = commonSimilarity.findSimilarityDocumentVectorAndString(docName, ngramsTfidf, self.searchStr)
				self.similarityWithNGrams[docName] = similarity
			else:
				self.similarityWithNGrams[docName] = 0.0
#end ThreadSimilarityWithNGrams

class ThreadSimilarityWithNER(threading.Thread):
	def __init__(self, documentsInCorpusBasename, similarityWithNER, searchStr):
		self.documentsInCorpusBasename = documentsInCorpusBasename
		self.similarityWithNER = similarityWithNER
		self.searchStr = searchStr
		super(ThreadSimilarityWithNER, self).__init__()
	
	def run(self):
		for docName in self.documentsInCorpusBasename:
			try:
				nerPath = commonFile.getNERFilePath(docName)
				nerMap = commonFile.loadNERMapForFile(nerPath)
				orgs = nerMap[rbGlobals.KEY_NER_ORG]
				for org in orgs:
					if org not in rbGlobals.gIncorrectOrgSet:
						fpath = commonFile.getWikipediaFilePath(org)
						try:
							text = commonFile.readFileRaw(fpath, encode=rbGlobals.gEncoding)
							similarity = commonSimilarity.findSimilarityTwoStrings(text, self.searchStr)
							similarityWithNER[docName][org] = similarity
						except (OSError, FileNotFoundError):
							similarityWithNER[docName][org] = 0.0
			except (KeyError, FileNotFoundError):
				similarityWithNER[docName][org] = 0.0
#end ThreadSimilarityWithNER

def findSimilaritiesAndCombine(searchStr, searchWords):
	# iterate over the documents and collect the similarities
	
	searchStemmed = common.stemWordsPorter(searchWords)
	#searchStr = common.makeStringFromList(searchStemmed, " ")
	searchStr = " ".join(searchStemmed)
	count = 0
	
	similarityWithSet = dict()
	similarityWithDoc2Vec = dict()
	similarityWithTextClassify = dict()
	similarityWithWord = dict()
	similarityWithPorterStemmedWord = dict()
	similarityWithLemmatizedWord = dict()
	similarityWithTopic = dict()
	similarityWithNGrams = dict()
	similarityWithNER = dict()
	similarityAllCombined = dict()
	
	searchSet = set()
	for sw in searchWords:
		searchSet.add(sw.lower())
	
	doc2vecSimilarity = computeDoc2VecSimilarityForString(searchStr.lower())
	
	threadList = []
	
	if rbGlobals.gSimilarityWeightSet > 0:
		trSet = ThreadSimilarityWithSet(rbGlobals.gDocumentsInCorpusBasename, similarityWithSet, searchSet)
		threadList.append(trSet)
	"""else:
		for docName in rbGlobals.gDocumentsInCorpusBasename:
			similarityWithSet[docName] = 0"""
		
	if rbGlobals.gSimilarityWeightDoc2Vec > 0:
		trDoc2Vec = ThreadSimilarityWithDoc2Vec(rbGlobals.gDocumentsInCorpusBasename, doc2vecSimilarity, similarityWithDoc2Vec)
		threadList.append(trDoc2Vec)
	"""else:
		for docName in rbGlobals.gDocumentsInCorpusBasename:
			similarityWithDoc2Vec[docName] = 0"""

	if rbGlobals.gSimilarityWeightTextClassify > 0:
		trTextClassify = ThreadSimilarityWithTextClassify(rbGlobals.gDocumentsInCorpusBasename, similarityWithTextClassify, searchStr)
		threadList.append(trTextClassify)
	"""else:
		for docName in rbGlobals.gDocumentsInCorpusBasename:
			similarityWithTextClassify[docName] = 0"""
	
	if rbGlobals.gSimilarityWeightTFIDF > 0 and rbGlobals.gSimilarityWeightWord > 0:
		trWord = ThreadSimilarityWithWord(rbGlobals.gDocumentsInCorpusBasename, similarityWithWord, searchStr)
		threadList.append(trWord)
	"""else:
		for docName in rbGlobals.gDocumentsInCorpusBasename:
			similarityWithWord[docName] = 0"""
	
	if rbGlobals.gSimilarityWeightTFIDF > 0 and rbGlobals.gSimilarityWeightStemmedWord > 0:
		trPorterStemmedWord = ThreadSimilarityWithPorterStemmedWord(rbGlobals.gDocumentsInCorpusBasename, similarityWithPorterStemmedWord, rbGlobals.stemPorterSearchWords)
		threadList.append(trPorterStemmedWord)
	"""else:
		for docName in rbGlobals.gDocumentsInCorpusBasename:
			similarityWithPorterStemmedWord[docName] = 0"""
	
	if rbGlobals.gSimilarityWeightTFIDF > 0 and rbGlobals.gSimilarityWeightLemmatizedWord > 0:
		trLemmatizedWord = ThreadSimilarityWithLemmatizedWord(rbGlobals.gDocumentsInCorpusBasename, similarityWithLemmatizedWord, rbGlobals.lemmatizedSearchWords)
		threadList.append(trLemmatizedWord)
	"""else:
		for docName in rbGlobals.gDocumentsInCorpusBasename:
			similarityWithLemmatizedWord[docName] = 0"""
		
	if rbGlobals.gSimilarityWeightTFIDF > 0 and rbGlobals.gSimilarityWeightTopics > 0:
		trTopic = ThreadSimilarityWithTopic(rbGlobals.gDocumentsInCorpusBasename, similarityWithTopic, searchStr)
		threadList.append(trTopic)
	"""else:
		for docName in rbGlobals.gDocumentsInCorpusBasename:
			similarityWithTopic[docName] = 0"""
			
	if rbGlobals.gSimilarityWeightTFIDF > 0 and rbGlobals.gSimilarityWeightNGrams > 0:
		trNGrams = ThreadSimilarityWithNGrams(rbGlobals.gDocumentsInCorpusBasename, similarityWithNGrams, searchStr)
		threadList.append(trNGrams)
	"""else:
		for docName in rbGlobals.gDocumentsInCorpusBasename:
			similarityWithNGrams[docName] = 0"""
		
	if rbGlobals.gSimilarityWeightNER > 0:
		trNER = ThreadSimilarityWithNER(rbGlobals.gDocumentsInCorpusBasename, similarityWithNER, searchStr)
		threadList.append(trNGER)
	"""else:
		for docName in rbGlobals.gDocumentsInCorpusBasename:
			similarityWithNER[docName] = 0"""
	
	for thread in threadList:
		thread.start()
	for thread in threadList:
		thread.join()
	
	for docName in rbGlobals.gDocumentsInCorpusBasename:
		# combine the similarities
		try:
			sim1 = similarityWithSet[docName] * rbGlobals.gSimilarityWeightSet
		except KeyError:
			sim1 = 0.0
		try:
			sim2 = similarityWithDoc2Vec[docName] * rbGlobals.gSimilarityWeightDoc2Vec
		except KeyError:
			sim2 = 0.0
		if sim2 < 0:
			sim2 = 0.0
		try:
			sim3 = similarityWithTextClassify[docName] * rbGlobals.gSimilarityWeightTextClassify
		except KeyError:
			sim3 = 0.0
		if sim3 < 0:
			sim3 = 0.0
		
		try:
			sw = similarityWithWord[docName] * rbGlobals.gSimilarityWeightWord
		except KeyError:
			sw = 0.0
		try:
			spsw = similarityWithPorterStemmedWord[docName] * rbGlobals.gSimilarityWeightStemmedWord
		except KeyError:
			spsw = 0.0
		try:
			slw = similarityWithLemmatizedWord[docName] * rbGlobals.gSimilarityWeightLemmatizedWord
		except KeyError:
			slw = 0.0
		try:
			st = similarityWithTopic[docName] * rbGlobals.gSimilarityWeightTopics
		except KeyError:
			st = 0.0
		try:
			simobj = similarityWithNER[docName]
			rsimobj = common.sortDictionaryOnValueDescending(simobj)
			obj, sner = rsimobj[0]
		except (KeyError, IndexError) as err:
			sner = 0.0
		sner = sner * rbGlobals.gSimilarityWeightNER
		try:
			sng = similarityWithNGrams[docName] * rbGlobals.gSimilarityWeightNGrams
		except KeyError:
			sng = 0.0
			
		sim4 = sw + spsw + slw + st + sner + sng
		sim4 = sim4 * rbGlobals.gSimilarityWeightTFIDF
		simFinal = sim1 + sim2 + sim3 + sim4
		
		# store similarities for final computation
		similarityAllCombined[docName] = simFinal
	
	return similarityAllCombined
#end findSimilaritiesAndCombine

#def performSearch(df, searchStr, pStopWords, pContractionMap, pAcronymMap, pMiscExpansionsMap, pIncorrectOrgSet):
def performSearch(searchStr, pStopWords, pContractionMap, pAcronymMap, pMiscExpansionsMap, pIncorrectOrgSet):
	commonLogger.debug("performSearch start")
	
	# load information from corpus
	rbGlobals.gDocumentsInCorpusFilePath = commonFile.readPickle(commonFile.getDocumentsInCorpusFilePath())
	rbGlobals.gDocumentsInCorpusBasename = commonFile.readPickle(commonFile.getDocumentsInCorpusBasenameFilePath())
	rbGlobals.gNERToDocumentMap = commonFile.readPickle(commonFile.getNERToDocumentMapFilePath())
	rbGlobals.gDocDocWordSimilarityMap = commonFile.readPickle(commonFile.getDocDocWordSimilarityFilePath())
	rbGlobals.gDocDocPorterStemmedWordSimilarityMap = commonFile.readPickle(commonFile.getDocDocPorterStemmedWordSimilarityFilePath())
	rbGlobals.gDocDocLemmatizedWordSimilarityMap = commonFile.readPickle(commonFile.getDocDocLemmatizedWordSimilarityFilePath())
	rbGlobals.gDocDocTopicSimilarityMap = commonFile.readPickle(commonFile.getDocDocTopicSimilarityFilePath())
	rbGlobals.gDocDocNGramSimilarityMap = commonFile.readPickle(commonFile.getDocDocNGramSimilarityFilePath())
	
	#rbGlobals.gBasenameToActualFilenameMap = dict()
	filelist = commonFile.readFileIntoList(os.path.join(rbGlobals.DIR_CORPUS, "inputFileMapping.txt"))
	for f in filelist:
		f1, f2 = f.split(",")
		if f1[:1] != '#':
			rbGlobals.gBasenameToActualFilenameMap[f1] = f2
	
	#print("search string: ", searchStr)
	# perform basic text processing on search string
	searchWords = common.basicTextProcessingSearchString(searchStr, pStopWords, pContractionMap, pAcronymMap, pMiscExpansionsMap, pIncorrectOrgSet)
	#searchStr = common.stringFromTokens(searchWords, " ")
	searchStr = " ".join(searchWords)
	#print("search string after basic processing: ", searchStr)
	
	rbGlobals.stemPorterSearchWords = common.stemWordsPorter(searchWords)
	rbGlobals.stemPorterSearchCount = common.wordCount(rbGlobals.stemPorterSearchWords)
	rbGlobals.lemmatizedSearchWords = common.lemmatizeWords(searchWords)
	
	# check if related documents from same cluster are to be displayed
	if rbGlobals.gFindDocumentsFromSameCluster == True:
		# use kmeans clustering to identify other documents in same cluster
		modelKMeans = commonFile.readPickle(commonFile.getKMeansModelFilePath())
		vectorizerKMeans = commonFile.readPickle(commonFile.getKMeansVectorizerFilePath())
		# load the document to cluster map
		documentToKMeansClusterMap = commonFile.readPickle(commonFile.getDocumentToKMeansClusterFilePath())
	
	# find similarity of the search string with various elements from the corpus
	similarityCombined = findSimilaritiesAndCombine(searchStr, searchWords)
	# sort the results in reverse order of similarity
	reverseSortedSimilarityCombined = common.sortDictionaryOnValueDescending(similarityCombined)
	
	"""
	display top X number of results
	rbGlobals.gNumResults = -1 # value set to -1 to display all results
	NOTE: initially, gNumResults were being fetched. But there are some doc files that appear without consistency in the validator program
	while such files have been commented out, there is a chance of them appearing as they were included in the corpus.
	if such files appear in the results as they were present in the corpus, but are not to be considered, they will
	not be included in the count. Hence we fetch all records and perform count check separately inside the loop
	"""
	#topData = common.getTopDataSet(reverseSortedSimilarityCombined, rbGlobals.gNumResults)
	topData = common.getTopDataSet(reverseSortedSimilarityCombined, -1)
	count = 0
	for name, value in topData:
		try:
			name2 = rbGlobals.gBasenameToActualFilenameMap[name]
		except KeyError:
			continue
		
		if count == rbGlobals.gNumResults:
			break
			
		count = count + 1
		
		#print(name + " : " + str(value))
		#print(name + ".pptx -- '" + name2 + "'")
		print(name2)
		if rbGlobals.gFindRelatedDocuments == True:
			print("\tRelated documents")
			#displayDocumentsRelatedByWords(name)
			displayDocumentsRelatedByWordsCombined(name)
		
		if rbGlobals.gFindDocumentsFromSameCluster == True:
			print("\tDocuments in the same cluster")
			documentsInSameCluster = kmeansPredict.getListOfDocumentsInTheSameCluster(modelKMeans, vectorizerKMeans, rbGlobals.gDocumentsInCorpusBasename, documentToKMeansClusterMap, name, rbGlobals.gNumDocumentsFromSameCluster)
			print("\t\t", documentsInSameCluster)
	
		if rbGlobals.gFindDocumentsWithSameLocation == True:
			print("\tDocuments that mention the same location")
			locations = displayDocumentsSharingTheSameLocation(name, rbGlobals.gNumDocumentsWithSameLocation)
			print("\t\t", locations)
		
		if rbGlobals.gFindDocumentsWithSamePerson == True:
			print("\tDocuments that mention the same people")
			people = displayDocumentsSharingTheSamePeople(name, rbGlobals.gNumDocumentsWithSamePerson)
			print("\t\t", people)
	
	commonLogger.debug("performSearch end")
#end performSearch

def loadCorpus():
	commonLogger.detail("loadCorpus start")
	
	df = pd.read_pickle(os.path.join(rbGlobals.DIR_CORPUS, "recobuilder-corpus." + rbGlobals.EXT_CORPUS), 'gzip')
	
	commonLogger.detail("loadCorpus end")
	return df
#end loadCorpus

# helper function to perform search
#def searchIt(df, searchStr):
def searchIt(searchStr):
	#print("searching for --------------------------------")
	#print(searchStr)
	#print("--------------------------------")
	#performSearch(df, searchStr, rbGlobals.gStopWords, rbGlobals.gContractionMap, rbGlobals.gAcronymMap, rbGlobals.gMiscExpansionsMap, rbGlobals.gIncorrectOrgSet)
	performSearch(searchStr, rbGlobals.gStopWords, rbGlobals.gContractionMap, rbGlobals.gAcronymMap, rbGlobals.gMiscExpansionsMap, rbGlobals.gIncorrectOrgSet)
	#print("--------------------------------")

def readConfigurationValues():
	#commonLogger.detail("readConfigurationValues start")
	
	# create config reader object
	config = CommonConfig.CommonConfig()
	config.load("recobuilder.ini")
	
	level = config.getString("ProgramSettings", "LoggingLevel", "DETAIL")
	if level == "DETAIL":
		commonLogger.level = commonLogger.DETAIL
	elif level == "DEBUG":
		commonLogger.level = commonLogger.DEBUG
	elif level == "INFO":
		commonLogger.level = commonLogger.INFO
	elif level == "WARNING":
		commonLogger.level = commonLogger.WARNING
	elif level == "ERROR":
		commonLogger.level = commonLogger.ERROR
	elif level == "FATAL":
		commonLogger.level = commonLogger.FATAL
	elif level == "OFF":
		commonLogger.level = commonLogger.OFF
	else:
		commonLogger.level = commonLogger.OFF

	# read program settings from config
	rbGlobals.gLanguage = config.getString("ProgramSettings", "Language", rbGlobals.DEFAULT_LANGUAGE)
	cfname = config.getString("ProgramSettings", "ContractionsFile", rbGlobals.DEFAULT_CONTRACTIONS_FILENAME)
	rbGlobals.gContractionMap = commonFile.loadContractions(os.path.join(rbGlobals.DIR_SUPPORT, cfname))
	afname = config.getString("ProgramSettings", "AcronymsFile", rbGlobals.DEFAULT_ACRONYMS_FILENAME)
	rbGlobals.gAcronymMap = commonFile.loadAcronyms(os.path.join(rbGlobals.DIR_SUPPORT, afname))
	mefname = config.getString("ProgramSettings", "MiscExpansionsFile", rbGlobals.DEFAULT_MISC_EXPANSIONS_FILENAME)
	rbGlobals.gMiscExpansionsMap = commonFile.loadMiscExpansions(os.path.join(rbGlobals.DIR_SUPPORT, mefname))
	iolfname = config.getString("ProgramSettings", "IncorrectOrganizationsFile", rbGlobals.DEFAULT_INCORRECT_ORGANIZATIONS_FILENAME)
	rbGlobals.gIncorrectOrgSet = commonFile.loadIncorrectOrganizationSet(os.path.join(rbGlobals.DIR_SUPPORT, iolfname))
	rbGlobals.gUseThreading = config.getBoolean("ProgramSettings", "UseThreading", rbGlobals.DEFAULT_USE_THREADING)
	
	rbGlobals.gCorpusCreationFlag = config.getBoolean("ProgramExecution", "CreateCorpus", rbGlobals.DEFAULT_CORPUS_CREATION_FLAG)
	rbGlobals.gSearchFlag = config.getBoolean("ProgramExecution", "Search", rbGlobals.DEFAULT_SEARCH_FLAG)
	rbGlobals.gEncoding = config.getBoolean("ProgramExecution", "Encoding", rbGlobals.DEFAULT_ENCODING)
	
	# read corpus creation settings from config
	rbGlobals.gCreationMode = config.getString("CorpusCreation", "CreationMode", rbGlobals.CREATION_MODE_UPDATE)
	rbGlobals.gTopicCreation = config.getBoolean("CorpusCreation", "TopicCreation", rbGlobals.DEFAULT_TOPIC_CREATION)
	rbGlobals.gNERIdentification = config.getBoolean("CorpusCreation", "NERIdentification", rbGlobals.DEFAULT_NER_IDENTIFICATION)
	rbGlobals.gNEROrgDownload = config.getBoolean("CorpusCreation", "NEROrgDownload", rbGlobals.DEFAULT_NER_ORG_DOWNLOAD)
	rbGlobals.gNERIncorrectOrgIdentification = config.getBoolean("CorpusCreation", "NERIncorrectOrgIdentification", rbGlobals.DEFAULT_NER_INCORRECT_ORG_IDENTIFICATION)
	rbGlobals.gNERSkipOrgCheck = config.getBoolean("CorpusCreation", "NERSkipIncorrectOrgCheck", rbGlobals.DEFAULT_NER_SKIP_INCORRECT_ORG_CHECK)
	rbGlobals.gNGramTfidf = config.getBoolean("CorpusCreation", "NGramTfidf", rbGlobals.DEFAULT_NGRAM_TFIDF)
	rbGlobals.gLemmatizationTfidf = config.getBoolean("CorpusCreation", "LemmatizationTfidf", rbGlobals.DEFAULT_LEMMATIZATION_TFIDF)
	rbGlobals.gPorterStemmingTfidf = config.getBoolean("CorpusCreation", "PorterStemmingTfidf", rbGlobals.DEFAULT_PORTER_STEMMING_TFIDF)
	rbGlobals.gLancasterStemmingTfidf = config.getBoolean("CorpusCreation", "LancasterStemmingTfidf", rbGlobals.DEFAULT_LANCASTER_STEMMING_TFIDF)
	rbGlobals.gSnowballStemmingTfidf = config.getBoolean("CorpusCreation", "SnowballStemmingTfidf", rbGlobals.DEFAULT_SNOWBALL_STEMMING_TFIDF)
	rbGlobals.gBasicTfidf = config.getBoolean("CorpusCreation", "BasicTfidf", rbGlobals.DEFAULT_BASIC_TFIDF)
	rbGlobals.gWordSetTfidf = config.getBoolean("CorpusCreation", "WordSetTfidf", rbGlobals.DEFAULT_WORDSET_TFIDF)
	rbGlobals.gDocumentListAddToCorpus = config.getString("CorpusCreation", "DocumentListAddToCorpus", rbGlobals.DEFAULT_PATH_DOCUMENT_LIST_TO_ADD_TO_CORPUS)
	rbGlobals.gFindTopicsForAllDocuments = config.getBoolean("CorpusCreation", "FindTopicsForAllDocuments", rbGlobals.DEFAULT_FIND_TOPICS_FOR_ALL_DOCUMENTS)
	rbGlobals.gGenerateDocDocSimilarityMaps = config.getBoolean("CorpusCreation", "GenerateDocDocSimilarityMaps", rbGlobals.DEFAULT_GENERATE_DOC_DOC_SIMILARITY_MAPS)
	rbGlobals.gKMeansClustering = config.getBoolean("CorpusCreation", "KMeansClustering", rbGlobals.DEFAULT_KMEANS_CLUSTERING)
	rbGlobals.gGenerateDoc2VecModel = config.getBoolean("CorpusCreation", "GenerateDoc2VecModel", rbGlobals.DEFAULT_GENERATE_DOC2VEC_MODEL)
	rbGlobals.gGenerateTextClassifyModel = config.getBoolean("CorpusCreation", "GenerateTextClassifyModel", rbGlobals.DEFAULT_GENERATE_TEXT_CLASSIFY_MODEL)
	
	# read topic creation settings from config
	rbGlobals.gNumTopics = config.getInt("TopicCreation", "NumTopics", rbGlobals.DEFAULT_NUM_TOPICS)
	rbGlobals.gNumPasses = config.getInt("TopicCreation", "NumPasses", rbGlobals.DEFAULT_NUM_PASSES)
	rbGlobals.gNumWords = config.getInt("TopicCreation", "NumWords", rbGlobals.DEFAULT_NUM_WORDS)

	# read kmeans clustering settings from config
	rbGlobals.gKMeansNumClusters = config.getInt("KMeansClustering", "NumClusters", rbGlobals.DEFAULT_KMEANS_NUM_CLUSTERS)
	rbGlobals.gKMeansNumIterations = config.getInt("KMeansClustering", "NumIterations", rbGlobals.DEFAULT_KMEANS_NUM_ITERATIONS)
	
	# read search config parameters
	rbGlobals.gNumResults = config.getInt("Search", "NumResults", rbGlobals.DEFAULT_NUM_RESULTS)
	rbGlobals.gFindRelatedDocuments = config.getBoolean("Search", "FindRelatedDocuments", rbGlobals.DEFAULT_FIND_RELATED_DOCUMENTS)
	rbGlobals.gNumRelatedDocuments = config.getInt("Search", "NumRelatedDocuments", rbGlobals.DEFAULT_NUM_RELATED_DOCUMENTS)
	rbGlobals.gFindDocumentsFromSameCluster = config.getBoolean("Search", "FindDocumentsFromSameCluster", rbGlobals.DEFAULT_FIND_DOCUMENTS_FROM_SAME_CLUSTER)
	rbGlobals.gNumDocumentsFromSameCluster = config.getInt("Search", "NumDocumentsFromSameCluster", rbGlobals.DEFAULT_NUM_DOCUMENTS_FROM_SAME_CLUSTER)
	rbGlobals.gFindDocumentsWithSamePerson = config.getBoolean("Search", "FindDocumentsWithSamePerson", rbGlobals.DEFAULT_FIND_DOCUMENTS_WITH_SAME_PERSON)
	rbGlobals.gNumDocumentsWithSamePerson = config.getInt("Search", "NumDocumentsWithSamePerson", rbGlobals.DEFAULT_NUM_DOCUMENTS_WITH_SAME_PERSON)
	rbGlobals.gFindDocumentsWithSameLocation = config.getBoolean("Search", "FindDocumentsWithSameLocation", rbGlobals.DEFAULT_FIND_DOCUMENTS_WITH_SAME_LOCATION)
	rbGlobals.gNumDocumentsWithSameLocation = config.getInt("Search", "NumDocumentsWithSameLocation", rbGlobals.DEFAULT_NUM_DOCUMENTS_WITH_SAME_LOCATION)
	# read search weight config paramateres
	rbGlobals.gSimilarityWeightWord = config.getFloat("SearchWeight", "SimilarityWeightWord", rbGlobals.DEFAULT_WEIGHT_SIMILARITY_WORD)
	commonLogger.info("SearchWeight - SimilarityWeightWord: " + str(rbGlobals.gSimilarityWeightWord * 100) + "%")
	rbGlobals.gSimilarityWeightStemmedWord = config.getFloat("SearchWeight", "SimilarityWeightStemmedWord", rbGlobals.DEFAULT_WEIGHT_SIMILARITY_STEMMED_WORD)
	commonLogger.info("SearchWeight - SimilarityWeightStemmedWord: " + str(rbGlobals.gSimilarityWeightStemmedWord * 100) + "%")
	rbGlobals.gSimilarityWeightLemmatizedWord = config.getFloat("SearchWeight", "SimilarityWeightLemmatizedWord", rbGlobals.DEFAULT_WEIGHT_SIMILARITY_LEMMATIZED_WORD)
	commonLogger.info("SearchWeight - SimilarityWeightLemmatizedWord: " + str(rbGlobals.gSimilarityWeightLemmatizedWord * 100) + "%")
	rbGlobals.gSimilarityWeightTopics = config.getFloat("SearchWeight", "SimilarityWeightTopics", rbGlobals.DEFAULT_WEIGHT_SIMILARITY_TOPICS)
	commonLogger.info("SearchWeight - SimilarityWeightTopics: " + str(rbGlobals.gSimilarityWeightTopics * 100) + "%")
	rbGlobals.gSimilarityWeightNER = config.getFloat("SearchWeight", "SimilarityWeightNER", rbGlobals.DEFAULT_WEIGHT_SIMILARITY_NER)
	commonLogger.info("SearchWeight - SimilarityWeightNER: " + str(rbGlobals.gSimilarityWeightNER * 100) + "%")
	rbGlobals.gSimilarityWeightNGrams = config.getFloat("SearchWeight", "SimilarityWeightNGrams", rbGlobals.DEFAULT_WEIGHT_SIMILARITY_NGRAMS)
	commonLogger.info("SearchWeight - SimilarityWeightNGrams: " + str(rbGlobals.gSimilarityWeightNGrams * 100) + "%")
	rbGlobals.gSimilarityWeightSet = config.getFloat("SearchWeight", "SimilarityWeightSet", rbGlobals.DEFAULT_WEIGHT_SIMILARITY_SET)
	commonLogger.info("SearchWeight - SimilarityWeightSet: " + str(rbGlobals.gSimilarityWeightSet * 100) + "%")
	rbGlobals.gSimilarityWeightDoc2Vec = config.getFloat("SearchWeight", "SimilarityWeightDoc2Vec", rbGlobals.DEFAULT_WEIGHT_SIMILARITY_DOC2VEC)
	commonLogger.info("SearchWeight - SimilarityWeightDoc2Vec: " + str(rbGlobals.gSimilarityWeightDoc2Vec * 100) + "%")
	rbGlobals.gSimilarityWeightTFIDF = config.getFloat("SearchWeight", "SimilarityWeightTFIDF", rbGlobals.DEFAULT_WEIGHT_SIMILARITY_TFIDF)
	commonLogger.info("SearchWeight - SimilarityWeightTFIDF: " + str(rbGlobals.gSimilarityWeightTFIDF * 100) + "%")
	rbGlobals.gSimilarityWeightTextClassify = config.getFloat("SearchWeight", "SimilarityWeightTextClassify", rbGlobals.DEFAULT_WEIGHT_SIMILARITY_TEXT_CLASSIFY)
	commonLogger.info("SearchWeight - gSimilarityWeightTextClassify: " + str(rbGlobals.gSimilarityWeightTextClassify * 100) + "%")

	# initialize stop words
	rbGlobals.gStopWords = stopwords.words(rbGlobals.gLanguage) + list(punctuation)
	
	# load the file list and basename file list
	rbGlobals.gDocumentsInCorpusFilePath = commonFile.readPickle(commonFile.getDocumentsInCorpusFilePath())
	rbGlobals.gDocumentsInCorpusBasename = commonFile.readPickle(commonFile.getDocumentsInCorpusBasenameFilePath())
	
	#commonLogger.detail("readConfigurationValues end")
	return config

#
# main
#

if __name__ == '__main__':
	#commonLogger.info("RecoBuilder - single ----- start")
	#print("RecoBuilder ----- start")
	
	# read config values from ini file
	config = readConfigurationValues()
	
	"""
	# uncomment only if doc2vec corpus directory needs to be refreshed for submission. Else, this is accounted for in corpus creation
	doc2vec_v2.computeModel(rbGlobals.DIR_INPUT)
	"""
	
	"""
	# uncomment only if doc2vec corpus directory needs to be refreshed for submission. Else, this is accounted for in corpus creation
	dclasses = textClassify.loadDClasses(rbGlobals.DIR_INPUT)
	textClassify.learn(dclasses, rbGlobals.DIR_INPUT)
	#textClassify.search(dclasses, "Cost transparency and liability Continuous buildup of shared knowledge headed by an extraordinary engagement manager convinced the client")
	"""
	
	"""
	misc_gen_word_set_corpus_documents.genWordSetForCorpusDocument(rbGlobals.DIR_INPUT, rbGlobals.gStopWords, rbGlobals.gContractionMap, rbGlobals.gAcronymMap, rbGlobals.gMiscExpansionsMap, rbGlobals.gIncorrectOrgSet)
	"""
	
	# create corpus
	if rbGlobals.gCorpusCreationFlag == True:
		createCorpus.createCorpus(rbGlobals.DIR_INPUT, rbGlobals.gStopWords, rbGlobals.gContractionMap, rbGlobals.gAcronymMap, rbGlobals.gMiscExpansionsMap, rbGlobals.gIncorrectOrgSet)
	else:
		commonLogger.info("CORPUS creation flag was set to False. Saved corpus data will be used")
	
	# execute search
	if rbGlobals.gSearchFlag == True:
		if len(sys.argv) != 2:
			print("Syntax: python GDSC_recommendation_model.py \"<search string>\"")
			sys.exit(0)
		
		# load corpus
		#new_df = loadCorpus()
		
		# search the provided text
		searchText = " ".join(sys.argv[1:2])
		#searchIt(new_df, searchText)
		performSearch(searchText, rbGlobals.gStopWords, rbGlobals.gContractionMap, rbGlobals.gAcronymMap, rbGlobals.gMiscExpansionsMap, rbGlobals.gIncorrectOrgSet)
	else:
		commonLogger.info("Search flag was set to False. Search will not be executed")
	
	#commonLogger.info("RecoBuilder - single ----- end")
	#print("RecoBuilder ----- end")

#
# end of GDSC_recommendation_model.py
#
