"""
Data Science Challenge 4 - Search engine for sales team

Group Name:
	RecoBuilder

Authors:
	1. Bipin Patwardhan, bipin.patwardhan@capgemini.com
	2. Suvarna Fernandes, suvarna.fernandes@capgemini.com
	3. Geo Shanth, geo.shanth@capgemini.com
	4. Philippe Roudil, philippe.roudil@sogeti.com

File:
	createCorpus.py

Description:
	TO BE ADDED
"""

import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import pandas as pd
import sys
import os
import codecs
import pickle
import csv
import chardet

import rbGlobals
import common
import commonFile
import commonLogger
import commonSimilarity
import commonTopics
import commonNER
import ngrams
import topicModelerFile
import kmeansPredict
from stanfordNERCoreNLP import *
import doc2vec_v2
import textClassify

def vectorizeWordsAndSaveToFile(words, filePath):
	commonLogger.detail("vectorizeWordsAndSaveToFile start")
	
	# create a tf-idf vector for the words in the document
	wordStr = common.makeStringFromList(words, " ")
	vector = commonSimilarity.vectorizeAndFitTransform(wordStr)
	if vector is not None:
		# save the tf-idf vector to file
		commonLogger.debug("vectorizeWordsAndSaveToFile: vector file path: " + filePath)
		commonFile.writePickle(filePath, vector)
	
	commonLogger.detail("vectorizeWordsAndSaveToFile end")
#end vectorizeWordsAndSaveToFile

def createDocumentListSet(filepath):
	commonLogger.detail("createDocumentListSet start")
	list = commonFile.readFileIntoList(filepath)
	fileSet = set()
	for l in list:
		if l[:1] != "#":
			fileSet.add(l)
		else:
			common.detail("skipping file ", l)
	commonLogger.detail("createDocumentListSet end")
	return fileSet
#end createDocumentListSet

def createCorpus(input_dir, stopWords, contractionMap, acronymMap, miscExpansionsMap, incorrectOrgSet):
	commonLogger.detail("createCorpus start")
	
	#df = pd.DataFrame(columns=['File', 'Text', 'tokens', 'words', 'words_StemPorter', 'words_StemLancaster', 'words_StemSnowball', 'Count'])
	df = pd.DataFrame(columns=['Path', 'File'])
	
	documentListAddToCorpus = createDocumentListSet(os.path.join(rbGlobals.DIR_SUPPORT, rbGlobals.gDocumentListAddToCorpus))
	if rbGlobals.gCreationMode == rbGlobals.CREATION_MODE_FROM_LIST and len(documentListAddToCorpus) == 0:
		commonLogger.warning("List of documents to be added to corpus is empty. Corpus will NOT be modified")
		return
	
	# read each file in the input directory and add it to the corpus
	for file in os.listdir(input_dir):
		bFileAdded = False
		
		if rbGlobals.gCreationMode == rbGlobals.CREATION_MODE_APPEND:
			#commonLogger.debug("'append' creation mode is specified")
			if file in rbGlobals.gDocumentsInCorpusFilePath and commonFile.getBasename(file) in rbGlobals.gDocumentsInCorpusBasename:
				commonLogger.debug(file + " exists in the corpus. skipping it")
				continue
		elif rbGlobals.gCreationMode == rbGlobals.CREATION_MODE_UPDATE:
			commonLogger.debug("'update' creation mode is specified")
		elif rbGlobals.gCreationMode == rbGlobals.CREATION_MODE_FROM_LIST:
			if len(documentListAddToCorpus) >= 0:
				if file not in documentListAddToCorpus:
					commonLogger.debug("skipping " + file + " as it is present in corpus")
					continue
				else:
					commonLogger.debug("Adding " + os.path.splitext(file)[0] + " to the corpus")
		else:
			commonLogger.debug("Option not recognized")
			return
		
		file_path = os.path.join(input_dir, file)
		if os.path.isdir(file_path):
			commonLogger.detail("\t" + file_path + " is a directory. skipping it")
			# skip directories
			continue
		
		try:
			commonLogger.info("Processing file '%s'" % file_path)
			#fh = codecs.open(os.path.join(input_path, file), "r", "utf-8")
			#fh = codecs.open(os.path.join(input_path, file), "r", "cp1252") # using this as utf-8 was giving some error - bipin, 11 jan 2017
			fh = codecs.open(file_path, "r")
			text = fh.read()
			text = text.strip()
			fh.close()
			
			if text is None or text == '':
				commonLogger.warning("Document '" + file_path + "' does not seem to contain data. Skipping the document")
				continue
			
			# perform basic text processing on each input
			words = common.basicTextProcessingCorpusDocument(text, stopWords, contractionMap, acronymMap, miscExpansionsMap, incorrectOrgSet)
			if len(words) == 0:
				commonLogger.error("Document '" + file_path + "' does not seem to contain data after basic processing. skipping the document")
				continue
			
			if rbGlobals.gWordSetTfidf == True:
				fpath = commonFile.getWordSetFilePath(os.path.splitext(file)[0])
				if not os.path.isfile(fpath):
					# perform basic text processing on each input
					words = common.basicTextProcessingCorpusDocument(text, stopWords, contractionMap, acronymMap, miscExpansionsMap, incorrectOrgSet)
					wordSet = set()
					for w in words:
						wordSet.add(w)
					commonFile.writePickle(os.path.join(rbGlobals.DIR_WORD_SET, os.path.splitext(file)[0] + ".pickle"), wordSet)
				else:
					commonLogger.debug("word set exists. skipping creation")
			
			if rbGlobals.gBasicTfidf == True:
				fpath = commonFile.getWordFilePath(os.path.splitext(file)[0])
				#commonLogger.debug("Checking for " + fpath)
				if not os.path.isfile(fpath):
					commonLogger.debug("creating tfidf of words")
					# create a tf-idf vector for the words in the document
					vectorizeWordsAndSaveToFile(words, fpath)
					bFileAdded = True
				else:
					commonLogger.debug("word tdidf exists. skipping creation")
			
			# stem words
			if rbGlobals.gPorterStemmingTfidf == True:
				fpath = commonFile.getStemmerPorterWordFilePath(os.path.splitext(file)[0])
				if not os.path.isfile(fpath):
					commonLogger.debug("creating tfidf of porter stemmed words")
					words_StemPorter = common.stemWordsPorter(words)
					count_StemPorter = common.wordCount(words_StemPorter)
					vectorizeWordsAndSaveToFile(words_StemPorter, fpath)
					bFileAdded = True
				else:
					commonLogger.debug("porter stem tdidf exists. skipping creation")
			
			if rbGlobals.gLancasterStemmingTfidf == True:
				fpath = commonFile.getStemmerLancasterWordFilePath(os.path.splitext(file)[0])
				if not os.path.isfile(fpath):
					commonLogger.debug("creating tfidf of lancaster stemmed words")
					words_StemLancaster = common.stemWordsLancaster(words)
					vectorizeWordsAndSaveToFile(words_StemLancaster, fpath)
					bFileAdded = True
				else:
					commonLogger.debug("lancaster stem tdidf exists. skipping creation")
				
			if rbGlobals.gSnowballStemmingTfidf == True:
				fpath = commonFile.getStemmerSnowballWordFilePath(os.path.splitext(file)[0])
				if not os.path.isfile(fpath):
					commonLogger.debug("creating tfidf of snowball stemmed words")
					words_StemSnowball = common.stemWordsSnowball(words)
					vectorizeWordsAndSaveToFile(words_StemSnowball, fpath)
					bFileAdded = True
				else:
					commonLogger.debug("snowball stem tdidf exists. skipping creation")
			
			if rbGlobals.gLemmatizationTfidf == True:
				fpath = commonFile.getLemmatizedWordFilePath(os.path.splitext(file)[0])
				if not os.path.isfile(fpath):
					# lemmatization of words
					commonLogger.debug("creating tfidf of lemmatized words")
					lemmatizedWords = common.lemmatizeWords(words)
					# create a tf-idf vector for the lemmatized words in the document
					vectorizeWordsAndSaveToFile(lemmatizedWords, fpath)
					bFileAdded = True
				else:
					commonLogger.debug("lemmatized word tdidf exists. skipping creation")
			
			if rbGlobals.gNGramTfidf == True:
				fpath = commonFile.getNGramsFilePath(os.path.splitext(file)[0])
				if not os.path.isfile(fpath):
					# generate frequent ngrams and save them to file
					commonLogger.debug("creating tfidf of ngrams")
					#ngrams.getMostFrequentNGgrams(file_path, num=10, min_length=2, max_length=4)
					frequent_ngrams = ngrams.getMostFrequentNGgrams(file_path)
					ngrams_list = ngrams.makeListFromNGrams(frequent_ngrams)
					# create a tf-idf vector for the ngrams in the document
					vectorizeWordsAndSaveToFile(ngrams_list, fpath)
					bFileAdded = True
				else:
					commonLogger.debug("ngram word tdidf exists. skipping creation")
			
			if rbGlobals.gTopicCreation == True:
				fpath = commonFile.getTopicsFilePath(os.path.splitext(file)[0])
				if not os.path.isfile(fpath):
					# identify topics
					commonLogger.debug("creating tfidf of identified topics")
					topicSet = commonTopics.generateTopicSetForDocumentUsingLDA(rbGlobals.DIR_INPUT, file)
					if len(topicSet) > 0:
						topicWords = common.makeListFromSet(topicSet, " ")
						vectorizeWordsAndSaveToFile(topicWords, fpath)
						bFileAdded = True
					else:
						commonLogger.warning("Empty topic set found for '" + fpath + "'")
				else:
					commonLogger.debug("topic modeling tfidf exists. skipping creation")
			
			if rbGlobals.gNERIdentification == True:
				fpath = commonFile.getNERFilePath(os.path.splitext(file)[0])
				if not os.path.isfile(fpath):
					commonLogger.debug("identifying named entities and downloading organization information")
					# perform NER
					nerMap = commonNER.performNEROnDocument(file_path)
					commonFile.saveNERMapForFile(fpath, nerMap)
					commonNER.fetchAndSaveOrganizationWebPage(nerMap, incorrectOrgSet)
					bFileAdded = True
				else:
					commonLogger.debug("ner exists. skipping creation")
			
			if bFileAdded == True:
				commonLogger.info("'" + file_path + "' : added to corpus")
				rbGlobals.gDocumentsInCorpusFilePath.append(file)
				rbGlobals.gDocumentsInCorpusBasename.append(os.path.splitext(file)[0])
			
			"""
			# create a row object to be store in pandas data frame
			row = [file, text_lower, tokens, words, words_StemPorter, words_StemLancaster, words_StemSnowball, count_StemPorter]
			df.loc[len(df)] = row
			"""
			
			row = [file_path, os.path.splitext(file)[0]]
			#row = [file_path, commonFile.getBasename(file)]
			df.loc[len(df)] = row
			words = []
		except FileNotFoundError:
			commonLogger.error("Error processing file " + file_path)
	# end for
	
	if rbGlobals.gFindTopicsForAllDocuments == True:
		#
		# identify topics for all documents in corpus
		#
		commonLogger.debug("finding topics in all documents in corpus using LDA")
		allDocumentTopicSet = commonTopics.generateTopicsForAllDocumentsInDirectoryUsingLDA(rbGlobals.DIR_INPUT, "*.*", option="CHUNK", topics_to_find=10, words_to_find=20, passes_to_execute=20)
		filePath = commonFile.getTopicsAllDocumentsFilePath()
		commonFile.writePickle(filePath, allDocumentTopicSet)
		topicWords = common.makeListFromSet(allDocumentTopicSet, " ")
		vfilePath = commonFile.getVectorizedTopicsAllDocumentsFilePath()
		vectorizeWordsAndSaveToFile(topicWords, vfilePath)

	#
	# generate doc-doc similarity maps
	if rbGlobals.gGenerateDocDocSimilarityMaps == True:
		# ner to document map
		commonLogger.debug("Generating the NER to Document map")
		commonNER.generateNERToDocumentMapping()
		# document to document word similarity
		commonLogger.debug("Generating document to document word similarity")
		commonSimilarity.performWordSimilarityWithinCorpusDocuments()
		# document to document lemmatized word similarity
		commonLogger.debug("Generating document to document lemmatized word similarity")
		commonSimilarity.performLemmatizedWordSimilarityWithinCorpusDocuments()
		# document to document topic similarity
		commonLogger.debug("Generating document to document topic similarity")
		commonSimilarity.performTopicSimilarityWithinCorpusDocuments()
	
	#
	# kmeans clustering
	if rbGlobals.gKMeansClustering == True:
		# generate document clusters
		model, vectorizer = generateDocumentClusters(input_dir)
		commonFile.writePickle(commonFile.getKMeansModelFilePath(), model)
		commonFile.writePickle(commonFile.getKMeansVectorizerFilePath(), vectorizer)
		
	#
	# generate doc2vec model
	if rbGlobals.gGenerateDoc2VecModel == True:
		doc2vec_v2.computeModel(rbGlobals.DIR_INPUT)
	
	if rbGlobals.gGenerateTextClassifyModel == True:
		#dclasses = textClassify.loadDClasses(rbGlobals.DIR_INPUT)
		#textClassify.learn(dclasses, rbGlobals.DIR_INPUT)
		textClassify.learn(rbGlobals.gDocumentsInCorpusFilePath, rbGlobals.DIR_INPUT)
	
	commonFile.writePickle(commonFile.getDocumentsInCorpusFilePath(), rbGlobals.gDocumentsInCorpusFilePath)
	commonFile.writePickle(commonFile.getDocumentsInCorpusBasenameFilePath(), rbGlobals.gDocumentsInCorpusBasename)
	
	# save the pandas data frame
	#print(df.head())
	#save df
	df.to_pickle(os.path.join(rbGlobals.DIR_CORPUS, "recobuilder-corpus." + rbGlobals.EXT_CORPUS), 'gzip')
	
	commonLogger.debug("createCorpus end")
#end createCorpus

def identifyTopics(input_dir):
	commonLogger.detail("identifyTopics start")
	
	commonLogger.debug("Identifying topics from " + input_dir)
	
	#topics = topicModelerFile.topicModeler("text_tfidf_custom", "lda", 15, 10, [2,4], input_dir)
	#topics = topicModelerFile.topicModeler("text_tfidf_custom", "lda", 15, 10, [1,1], input_dir)
	topics = topicModelerFile.topicModeler("text_tfidf_custom", "lda", 15, 5, [1,1], input_dir)
	commonLogger.debug("topics identified are as follows")
	commonLogger.debug(topics)
	
	commonLogger.detail("identifyTopics end")
	return topics
#end identifyTopics

def generateDocumentClusters(input_dir):
	commonLogger.detail("generateDocumentClusters start")
	
	commonLogger.debug("Generating document clusters from " + input_dir)
	
	"""
	for file in os.listdir(input_dir):
		#file_path = os.path.join(input_dir + rbGlobals.DIR_SEPARATOR, file)
		file_path = os.path.join(input_dir, file)
		#commonLogger.detail("file: " + file + ", file_path " + file_path)
		if os.path.isdir(file_path):
			commonLogger.detail(file_path + " is a directory. skipping it")
			# skip directories
			continue
		fh = codecs.open(file_path, "r")
		text = fh.read()
		fh.close()
		
		text_lower = text.lower()
		rbGlobals.gDocumentsForClustering.append(text_lower)
	"""
	
	for file in os.listdir(input_dir):
		file_path = os.path.join(input_dir, file)
		#commonLogger.detail("file: " + file + ", file_path " + file_path)
		if os.path.isfile(file_path):
			fh = codecs.open(file_path, "r")
			text = fh.read()
			fh.close()
			text_lower = text.lower()
			rbGlobals.gDocumentsForClustering.append(text_lower)
	
	#model, vectorizer = performKMeans(rbGlobals.gDocumentsForClustering)
	
	commonLogger.debug("clustering the documents using kmeans")
	model, vectorizer = kmeansPredict.cluster_documents(rbGlobals.gDocumentsForClustering, num_clusters=rbGlobals.gKMeansNumClusters, num_iter=rbGlobals.gKMeansNumIterations)

	rbGlobals.gDocumentToKMeansClusterMap = dict()
	commonLogger.debug("Generating the document to cluster mapping")
	for filename in os.listdir(input_dir):
		if filename.endswith(".txt"):
			fileText = open(os.path.join(input_dir, filename)).read()
			prediction = kmeansPredict.predict_kmeans_cluster(model, vectorizer, fileText)
			rbGlobals.gDocumentToKMeansClusterMap[os.path.splitext(filename)[0]] = prediction
	
	commonFile.writePickle(commonFile.getDocumentToKMeansClusterFilePath(), rbGlobals.gDocumentToKMeansClusterMap)
	
	commonLogger.detail("generateDocumentClusters end")
	return model, vectorizer
#end generateDocumentClusters

#
# end of createCorpus.py
#
