
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import pandas as pd
import sys
import os
import codecs
import pickle
import csv
import chardet
import math
from sklearn.feature_extraction.text import TfidfVectorizer

def vectorizeAndFitTransform(str):
	doclist = [ str ]
	sklearn_tfidf = TfidfVectorizer(norm='l2',min_df=0, use_idf=True, smooth_idf=False, sublinear_tf=True, tokenizer=tokenize)
	sklearn_representation = sklearn_tfidf.fit_transform(doclist)
	return sklearn_representation
#end vectorizeAndFitTransform

def makeStringFromList(list, separator):
	return separator.join(list)
#end makeStringFromList

def vectorizeWordsAndSaveToFile(words, filePath):
	wordStr = makeStringFromList(words, " ")
	vector = vectorizeAndFitTransform(wordStr)
	return vector
#end vectorizeWordsAndSaveToFile

def tokenize(text):
	words = word_tokenize(text)
	words = [w.lower() for w in words]
	#return [w for w in words if w not in rbGlobals.gStopWords and not w.isdigit()]
	return words
#end tokenize

def readFileRaw(fname, encode="latin-1"):
	return open(fname, encoding=encode).read()
#end readFileRaw

def computeCosineSimilarity(vector1, vector2):
	dot_product = sum(p*q for p,q in zip(vector1, vector2))
	magnitude = math.sqrt(sum([val**2 for val in vector1])) * math.sqrt(sum([val**2 for val in vector2]))
	if not magnitude:
		return 0
	return dot_product/magnitude
#end computeCosineSimilarity

def findSimilarityTwoStrings(string1, string2):
	sim = 0.0
	# perform tf=idf on string 1

	doclist1 = [ string1 ]
	#print(doclist1)
	#sklearn_tfidf = TfidfVectorizer(norm='l2',min_df=0, use_idf=True, smooth_idf=False, sublinear_tf=True, tokenizer=tokenize)
	sklearn_tfidf = TfidfVectorizer(norm=None,min_df=0, use_idf=True, smooth_idf=False, sublinear_tf=True, tokenizer=tokenize)
	sklearn_representation_doc1 = sklearn_tfidf.fit_transform(doclist1)

	#sklearn_representation_doc1 = vectorizeAndFitTransform(string1)
	
	# perform tf=idf on string 2

	doclist2 = [ string2 ]
	#print("******", doclist2)
	#sklearn_tfidf_str = TfidfVectorizer(norm='l2',min_df=0, use_idf=True, smooth_idf=False, sublinear_tf=True, tokenizer=tokenize)
	sklearn_tfidf_str = TfidfVectorizer(norm=None,min_df=0, use_idf=True, smooth_idf=False, sublinear_tf=True, tokenizer=tokenize)
	sklearn_representation_doc2 = sklearn_tfidf_str.fit_transform(doclist2)

	#sklearn_representation_doc2 = vectorizeAndFitTransform(string2)
	
	for scount, d1 in enumerate(sklearn_representation_doc1.toarray()):
		for count, d2 in enumerate(sklearn_representation_doc2.toarray()):
			sim = computeCosineSimilarity(d1, d2)
		
	return sim
#end findSimilarityTwoStrings

def showSimilarity(inputFile, searchStr):
	text = readFileRaw(inputFile)
	#print(text)
	text_words = tokenize(text)
	#print(text_words)
	
	#vectorizeAndFitTransform(makeStringFromList(text_words, " "))
	
	#search_words = tokenize(searchStr)
	#print(search_words)
	
	#vectorizeAndFitTransform(searchStr)
	
	print("Similarity between '", inputFile , "' and '", searchStr, "' is ", findSimilarityTwoStrings(text, searchStr))
	

if __name__ == "__main__":
	searchStr = "ticket management"
	showSimilarity("input\\Adidas_201208_BIReportingFramework.txt", searchStr)
	showSimilarity("input\\Adidas_201507_BIReportingFramework.txt", searchStr)
	showSimilarity("input\\BMW_201609_analyticsAsAService.txt", searchStr)
	showSimilarity("input\\Deutsche_Bank_201106_Data_Replication_Improvement.txt", searchStr)
	showSimilarity("input\\ESA_20170_DataManagement.txt", searchStr)
	showSimilarity("input\\Huge Agriculture Company_201610_BISC.txt", searchStr)
	showSimilarity("input\\Maxeda_201308_SAP-to-HANA.txt", searchStr)
	showSimilarity("input\\Randstad_201512_BigData.txt", searchStr)
	showSimilarity("input\\zzz-ticket-management.txt", searchStr)
	showSimilarity("input\\zzz-no-ticket-management.txt", searchStr)
	showSimilarity("input\\zzz-no-t-m.txt", searchStr)
