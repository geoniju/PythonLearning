
import warnings
warnings.filterwarnings(action='ignore', category=UserWarning, module='gensim')

import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import pandas as pd
import sys
import os
import codecs
import pickle
import csv
import chardet

import rbGlobals
import common
import commonFile
import commonLogger
import ngrams
import topicModelerFile

input_dir="input"
fnd = dict()
for file in os.listdir(input_dir):
	file_path = os.path.join(input_dir, file)
	if os.path.isdir(file_path):
		continue
	frequent_ngrams = ngrams.getMostFrequentNGgrams(file_path)
	#print(file_path, ":", frequent_ngrams)
	
	fnd[os.path.splitext(file)[0]] = []
	for fn in frequent_ngrams:
		#print(file, ",", fn)
		str = ""
		for t in fn:
			str = str + " " + t
		str = common.removePunctuation(str).replace("  ", " ").strip()
		fnd[os.path.splitext(file)[0]].append(str)
print(fnd)

pickle.dump(fnd, open("corpus/doc-ngrams.pickle", "wb"))
